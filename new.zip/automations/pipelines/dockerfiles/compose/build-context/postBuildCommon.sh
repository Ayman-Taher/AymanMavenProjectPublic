import_certificate_from_remote () {
	remote_address=$1
	remote_port=$2
	local_filename="$1_$2.crt"
	
	echo ""
	echo "##########################################################################"
	echo "####  Trying to Download certificate from $remote_address:$remote_port"
	echo "##########################################################################"
	rm -rf /tmp/$local_filename
	openssl s_client -showcerts -connect "$remote_address:$remote_port" </dev/null 2>/dev/null|openssl x509 -outform der > /tmp/$local_filename
	
	if test -f /tmp/$local_filename; then
	    echo "Certificate successfully downloaded"
	    import_certificate_in_os $local_filename
	    import_certificate_in_cacerts $local_filename
	fi
}

import_certificate_in_os () {
	certificate_filename=$1
	certificate_path=/tmp/$certificate_filename

	echo ""
	echo "##########################################################################"
	echo "####  Checking if update-ca-certificates is available"
	echo "##########################################################################"
	if type update-ca-certificates && touch $certificate_path /usr/local/share/ca-certificates/$certificate_filename; then
		echo ""
		echo "##########################################################################"
		echo "####  Importing certificate in os"
		echo "##########################################################################"
		cp -f $certificate_path /usr/local/share/ca-certificates/$certificate_filename
		chmod 644 /usr/local/share/ca-certificates/$certificate_filename
		rm -rf /etc/ca-certificates/update.d/docker-openjdk
		update-ca-certificates
	fi
	
	echo ""
	echo "##########################################################################"
	echo "####  Checking if update-ca-trust is available"
	echo "##########################################################################"
	if type update-ca-trust && touch "$certificate_path" "/etc/pki/ca-trust/source/anchors/$certificate_filename"; then
		echo ""
		echo "##########################################################################"
		echo "####  Importing certificate $certificate_filename in os"
		echo "##########################################################################"
		cp -f "$certificate_path" "/etc/pki/ca-trust/source/anchors/$certificate_filename"
		chmod 644 "/etc/pki/ca-trust/source/anchors/$certificate_filename"
		update-ca-trust extract
	fi
}

import_certificate_in_cacerts () {
	certificate_filename=$1
	certificate_path=/tmp/$certificate_filename
			
	echo ""
	echo "##########################################################################"
	echo "####  Checking if keytool and find are available"
	echo "##########################################################################"
	if type keytool && type find; then
		echo ""
		echo "##########################################################################"
		echo "####  Importing certificate in following cacerts: $(find /usr /opt -path '*/lib/security/cacerts')"
		echo "##########################################################################"
		keytool -noprompt -importcert -alias $certificate_filename -keystore "$(find /usr /opt -path '*/lib/security/cacerts')" -storepass changeit -file $certificate_path
	fi
}

echo ""
echo "##########################################################################"
echo "####  Checking if openssl is available"
echo "##########################################################################"
if type openssl; then
	import_certificate_from_remote "cicd-tooling-ce.stc.com.sa" "443"
	import_certificate_from_remote "cicd-tooling-ee.stc.com.sa" "443"
	import_certificate_from_remote "cicd-tooling-prod.stc.com.sa" "443"
fi
echo ""