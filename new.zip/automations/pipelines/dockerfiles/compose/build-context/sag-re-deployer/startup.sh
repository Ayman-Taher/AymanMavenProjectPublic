echo "#"
echo "##########################################################################"
echo "#########  Starting Integration Server"
echo "##########################################################################"
echo "#"
sh /opt/softwareag/profiles/IS_default/bin/startup.sh
sleep 20s

check_attempts_counter=1
check_attempts_max=100
echo "#"
echo "##########################################################################"
echo "#########  Attempt $check_attempts_counter of $check_attempts_max to check if deployer is ready"
echo "##########################################################################"
echo "#"
cat /opt/softwareag/IntegrationServer/instances/default/logs/server.log | grep 'Enabling HTTP Listener on port 5555'
while [[ $? != 0 && $check_attempts_max -gt $check_attempts_counter ]]  
do
	check_attempts_counter=$((check_attempts_counter+1))
	sleep 20s
	echo "#"
	echo "##########################################################################"
	echo "#########  Attempt $check_attempts_counter of $check_attempts_max to check if deployer is ready"
	echo "##########################################################################"
	echo "#"
    cat /opt/softwareag/IntegrationServer/instances/default/logs/server.log | grep 'Enabling HTTP Listener on port 5555'
done


echo "#"
echo "##########################################################################"
echo "#########  Composing Project Automator file if IS folder is present"
echo "##########################################################################"
echo "#"
if [ -d "/opt/softwareag/build/IS" ]
then
	find /opt/softwareag/build/IS -type f -iname "*.zip" | while read line; do
	  pkg=$(basename "$line")
	  echo "<Composite displayName=\"${pkg%.*}\" name=\"${pkg%.*}\" srcAlias=\"ESB\" type=\"IS\"/>"  >> temp.file
	done
	sed -e '/{COMPOSITES}/{r temp.file' -e 'd}' /opt/softwareag/ProjectAutomatorTemplate.xml > /opt/softwareag/ProjectAutomator.xml
else
	cat /opt/softwareag/ProjectAutomatorTemplate.xml > /opt/softwareag/ProjectAutomator.xml
fi

echo "#"
echo "##########################################################################"
echo "#########  Composing Project Automator file if RULES folder is present"
echo "##########################################################################"
echo "#"
if [ -d "/opt/softwareag/build/RULES" ]
then
	find /opt/softwareag/build/RULES -type f -iname "*.jar" | while read line; do
	  pkg=$(basename "$line")
	  echo "<Composite displayName=\"${pkg%.*}\" name=\"${pkg%.*}\" srcAlias=\"build\" type=\"RULES\"/>"  >> temp.file
	done
	sed -e '/{COMPOSITES}/{r temp.file' -e 'd}' /opt/softwareag/ProjectAutomatorTemplate.xml > /opt/softwareag/ProjectAutomator.xml
else
	cat /opt/softwareag/ProjectAutomatorTemplate.xml > /opt/softwareag/ProjectAutomator.xml
fi

echo "#"
echo "##########################################################################"
echo "#########  Running Project Automator"
echo "##########################################################################"
echo "#"
./projectautomatorUnix.sh /opt/softwareag/ProjectAutomator.xml
if [[ $? != 0 ]]
then
	echo "Error Running Automator"
	exit 1
fi

echo "#"
echo "##########################################################################"
echo "#########  Running Deployer"
echo "##########################################################################"
echo "#"
./Deployer.sh --deploy -project STC_TNR_BusinessRules -dc ruleDeployment -host localhost -port 5555 -user Administrator -pwd manage
if [[ $? != 0 ]]
then
	echo "Error Running Deployer"
	exit 1
fi





