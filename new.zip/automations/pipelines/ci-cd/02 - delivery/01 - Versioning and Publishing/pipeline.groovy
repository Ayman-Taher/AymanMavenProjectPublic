/*****************************************
* Runs the pipeline
****************************************/
def start() {
	def configs = getConfigs()

	stage('Reset Workspace') {
		env.WORKSPACE_VAR = "$WORKSPACE"
		env.GIT_PROTOCOL = "https"
		sh "git clean -fdx"
	}

	stage('Generate Version') {
		if (isToUpdateVersion()) {
					
			setupOriginRWRemote(configs.versionConfigs.gitCredentials)
			sh "git tag -l | xargs git tag -d && git fetch -t origin-rw"
			env.oldVersion = makeOldVersion(configs.versionConfigs.masterVersion.gitTagPath, configs.versionConfigs.newVersion.gitTagPath)
			if (configs.versionConfigs.masterVersion.autoIncrementalMode != "customScriptToGetIncrementalMode") {
				env.version = makeVersion(configs.versionConfigs.masterVersion, configs.versionConfigs.newVersion)
			}
		}
	}
	
	stage('Reset Sonar Analysis') {
		if (isToResetSonarAnalyses()) {
			resetSonarAnalyses()
		}
	}
	
	stage('Builds, Unit Tests and Sonar') {
		env.NOTIFICATION_GIT_BRANCH = "$GIT_BRANCH"
		env.NOTIFICATION_GIT_COMMIT = "$GIT_COMMIT"
		if (configs.sonarConfigs != null) {
			env.NOTIFICATION_SONAR_PROJECT_KEY = sh(returnStdout: true, script: "echo `$configs.sonarConfigs.projectKey`").trim()
			env.NOTIFICATION_SONAR_PROJECT_NAME = sh(returnStdout: true, script: "echo `$configs.sonarConfigs.projectName`").trim()
		}
		executeBuilds("Execution of ")
	}
	
	stage('Tag Version') {
		if (isToUpdateVersion() && !hasFailedBuilds()) {
			if (configs.versionConfigs.masterVersion.autoIncrementalMode == "customScriptToGetIncrementalMode") {
				configs.versionConfigs.masterVersion.autoIncrementalMode = sh(returnStdout: true, script: configs.generateVersion.customScriptToGetIncrementalMode).trim() 
				env.version = makeVersion(configs.versionConfigs.masterVersion, configs.versionConfigs.newVersion)
			}

    		echo "Old Version: " + nullToEmpty(env.oldVersion)
    		echo "New Version: " + nullToEmpty(env.version)
    		
    		if (env.version != env.oldVersion) {
  		    	sh "git tag -d \$(git tag -l) && git fetch --tags --no-recurse-submodules origin-rw"
				env.versionTag = configs.versionConfigs.newVersion.gitTagPath + "/" + env.version
				sh "git tag -f $versionTag && git push --no-verify origin-rw $versionTag"
    		}
		}
	}
	
	stage('Publish') {
    	env.NOTIFICATION_PUBLISHED_DOCKER_IMAGES = ''
		env.NOTIFICATION_PUBLISHED_MAVEN_ARTIFACTS = ''
		env.NOTIFICATION_PUBLISHED_NPM_COMPONENTS = ''

		if (isToUpdateVersion() && !hasFailedBuilds()) {
			def version = nullToEmpty(env.version)
			env.NOTIFICATION_VERSIONS = version

			configs.publishConfigs.each{ publishConfig ->
				if (publishConfig.type == "docker-image") {
					publishDockerImage(publishConfig, version)
					env.NOTIFICATION_PUBLISHED_DOCKER_IMAGES += ' ' + sh(returnStdout: true, script: "version=$version && echo " + publishConfig.targetImage).trim()
				}
				else if (publishConfig.type == "maven-artifact") {
					publishMavenArtifact(publishConfig, version)
				}
				else if (publishConfig.type == "npm-publish") {
					publishNPM(publishConfig, version)
				}
        	}
		}
		else {
			env.NOTIFICATION_VERSIONS = ""
		}
	}
	
	stage('Trigger Deploys') {
		if (isToUpdateVersion() && !hasFailedBuilds()) {
        	if (configs.deployConfigs != null && configs.deployConfigs instanceof net.sf.json.JSONArray) {
    			def version = nullToEmpty(env.version)
    			configs.deployConfigs.each{ deployConfig ->
    				def jobName = sh(returnStdout: true, script: deployConfig.job).trim()
    				def parameters = []
    				if (deployConfig.parameters != null && deployConfig.parameters instanceof net.sf.json.JSONArray) {
						deployConfig.parameters.each { parameter ->
							parameters.add([$class: parameter.className.trim(),
							                name:   parameter.name.trim(),
							                value:  sh(returnStdout: true, script: "version=$version && echo \"$parameter.value\"" ).trim() ])
    					}
    				}
    				try {
    					echo "Calling job: '$jobName' with parameters: " + groovy.json.JsonOutput.toJson(parameters)
    					build job: jobName, wait: deployConfig.wait, parameters: parameters
    				} catch (err) {
        		        echo err.getMessage()
        		    }
            	}
        	}
    	}
	}
}

/*****************************************
* Runs in the end of a successull build
****************************************/
def postSuccess() {
	def configs = getConfigs()
	if (hasFailedBuilds()) {
		sendSuccessNotification("fail", configs)
		currentBuild.setDescription("<a href=\"${BUILD_URL}artifact/email.html\">Validations failed</a>")
	}
	else {
		sendSuccessNotification("success", configs)
		currentBuild.setDescription("<a href=\"${BUILD_URL}artifact/email.html\">Version: $NOTIFICATION_VERSIONS</a>")
	}
	archiveLogsAndEmail()
	execHouseKeeping()
}

/*****************************************
* Runs in the end of a failed build
****************************************/
def postFailure() {
	def configs = getConfigs()
	sendMaintenanceNotification(configs)
	archiveLogsAndEmail()
	execHouseKeeping()
}

/*****************************************
* Get pipeline configs
****************************************/
def getConfigs() {
	if (env.configs == null) {
		def configs = null
				
		def gitflowConfigFilePath = ""
		def hotfixConfigFilePath = ""
		def configFilePath = "automations/configs/ci-cd/04 - delivery.json"
		def deprecatedConfigFilePath = "automations/configs/ci-cd/02 - delivery/01 - Versioning and Publishing/config.json"
		
		if ("$JOB_NAME".contains("/02 - Develop/")) {
			gitflowConfigFilePath = "automations/configs/ci-cd/05 - develop - delivery.json"
		}
		else if ("$JOB_NAME".contains("/03 - Release/")) {
			gitflowConfigFilePath = "automations/configs/ci-cd/11 - release - delivery.json"
		}
		else if ("$JOB_NAME".contains("/04 - Master/")) {
			gitflowConfigFilePath = "automations/configs/ci-cd/16 - master - delivery.json"
		}
		else if ("$JOB_NAME".contains("/06 - Hotfixes")) {
			hotfixConfigFilePath = "automations/configs/ci-cd/06 - hotfixes.json"	
		}
		
		if (gitflowConfigFilePath == "" && hotfixConfigFilePath == "") {
			try {
				configs = readJSON file: configFilePath
			} catch (err) {
				echo "Pipeline configuration not found. Attempting deprecated location..."
		    }
			if (configs == null) {
				try {
					configs = readJSON file: deprecatedConfigFilePath 
				} catch (err) {
					error("Pipeline configuration not found or invalid. Please create a valid configuration in '$configFilePath'")
			    }
			}
		}
		else if (hotfixConfigFilePath != "") {
			try {
				configs = readJSON file: hotfixConfigFilePath 
			} catch (err) {
				error("Pipeline configuration not found or invalid. Please create a valid configuration in '$hotfixConfigFilePath'")
		    }
		}
		else {
			try {
				configs = readJSON file: gitflowConfigFilePath 
			} catch (err) {
				error("Pipeline configuration not found or invalid. Please create a valid configuration in '$gitflowConfigFilePath'")
		    }
		}
		
		def defaultConfigs = readJSON file: "automations/pipelines/ci-cd/02 - delivery/01 - Versioning and Publishing/config-defaults.json"
		
		def gitflowDefaultConfigs = null
		if ("$JOB_NAME".contains("/02 - Develop/")) {
			gitflowDefaultConfigs = readJSON file: "automations/pipelines/ci-cd/02 - delivery/01 - Versioning and Publishing/config-defaults-develop.json"
		}
		else if ("$JOB_NAME".contains("/03 - Release/")) {
			gitflowDefaultConfigs = readJSON file: "automations/pipelines/ci-cd/02 - delivery/01 - Versioning and Publishing/config-defaults-release.json"
		}
		else if ("$JOB_NAME".contains("/04 - Master/")) {
			gitflowDefaultConfigs = readJSON file: "automations/pipelines/ci-cd/02 - delivery/01 - Versioning and Publishing/config-defaults-master.json"
		}
		if (gitflowDefaultConfigs != null) {
			defaultConfigs = loadDefaultConfigs(gitflowDefaultConfigs, defaultConfigs)
		}
		
		echo "DEFAULT CONFIGS: " + groovy.json.JsonOutput.toJson(defaultConfigs)
		echo "CONFIGS BEFORE: " + groovy.json.JsonOutput.toJson(configs)
		configs = loadDefaultConfigs(configs, defaultConfigs)
		echo "CONFIGS AFTER: " + groovy.json.JsonOutput.toJson(configs)
			
		env.configs = groovy.json.JsonOutput.toJson(configs)
		return configs
	}
	def configs = readJSON text: env.configs
	return configs
}

/*****************************************
* Load default configs if they are 
* not set in main configs
****************************************/
def loadDefaultConfigs(net.sf.json.JSONObject configs, net.sf.json.JSONObject defaultConfigs, logContext = '') {

	if (defaultConfigs != null) {
		defaultConfigs.keys().each{ key ->
			def configValue = configs[key]
			def defaultValue = defaultConfigs[key]
			
			if (configValue == null) {
				echo "Updating config value '$logContext$key' to default '$defaultValue'"
				configs[key] = defaultValue 
			}
			else if (defaultValue != null && defaultValue instanceof net.sf.json.JSONObject) {
				if (configValue instanceof net.sf.json.JSONObject) {
					configs[key] = loadDefaultConfigs(configValue, defaultValue, logContext + key + ".")
				}
				else if (configValue instanceof net.sf.json.JSONArray) {
					net.sf.json.JSONArray newConfigValue = new net.sf.json.JSONArray()
							
					configValue.each{ configValueItem ->
						if (configValueItem instanceof net.sf.json.JSONObject) {
							newConfigValue.add(loadDefaultConfigs(configValueItem, defaultValue, logContext + key + "[" + String.valueOf(newConfigValue.size()) + "]."))
						}
						else {
							newConfigValue.add(configValueItem)
						}
					}
					
					configs[key] = newConfigValue
				}
			}
		}
	}
	return configs
}

/**************************************************
* Execute the pipeline builds based in
* buildConfigs
***************************************************/
def executeBuilds(stagePrefix = '', executionKeyPrefix = '', resetSonarExecution = false) {
	def configs = getConfigs()
	def buildConfigs = configs.buildConfigs

	if (configs.buildSynchronous == "false") {
		def stepsForParallel = buildConfigs.collectEntries {[
    	 	"$stagePrefix $it.name" : {
				if (buildConfig.enabled) {
					executeBuild(stagePrefix, executionKeyPrefix, resetSonarExecution, it)
				}
        	}
    	]}
    	parallel stepsForParallel
	}
	else {
		buildConfigs.each{ buildConfig ->
			stage(stagePrefix + buildConfig.name) {
				if (buildConfig.enabled) {
					executeBuild(stagePrefix, executionKeyPrefix, resetSonarExecution, buildConfig)
				}
		    }
		}
	}
}

/**************************************************
* Execute a build from buildConfigs
***************************************************/
def executeBuild(stagePrefix = '', executionKeyPrefix = '', resetSonarExecution = false, buildConfig) {
	if (buildConfig != null && nullToEmpty(buildConfig.job) != "") {
		executeJobBuild(stagePrefix, executionKeyPrefix, resetSonarExecution, buildConfig)
	}
	else {
		executeStandardBuild(stagePrefix, executionKeyPrefix, resetSonarExecution, buildConfig)
	}
}

/**************************************************
* Execute a job build from buildConfigs
***************************************************/
def executeJobBuild(stagePrefix = '', executionKeyPrefix = '', resetSonarExecution = false, buildConfig) {
	if (!resetSonarExecution) {
		sh "echo '<span>❌ FAILED</span>' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result'"
		try {
			def jobName = sh(returnStdout: true, script: buildConfig.job).trim()
			def parameters = []
			if (buildConfig.parameters != null && buildConfig.parameters instanceof net.sf.json.JSONArray) {
				buildConfig.parameters.each { parameter ->
					parameters.add([$class: parameter.className.trim(),
					                name:   parameter.name.trim(),
					                value:  sh(returnStdout: true, script: "version=$version && echo \"$parameter.value\"" ).trim() ])
				}
			}
						
			def timeoutMinutes = (nullToEmpty(buildConfig.timeoutMinutes) != "" ? buildConfig.timeoutMinutes : 1)
			timeout(time: timeoutMinutes, unit: 'MINUTES') { 
				def logExecution = "Calling job: '$jobName' with parameters: " + groovy.json.JsonOutput.toJson(parameters)
				sh "echo '$logExecution' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.log'"
				build job: jobName, wait: buildConfig.wait, parameters: parameters
				sh "echo '<span>✔ PASSED</span>' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result'"
			}
		} catch (err) {
	        def logErrorMessage = "Exception running job: " + nullToEmpty(err.getMessage()) 
	        sh "echo '$logErrorMessage' >> '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.log'"	        
	    }
	}
}

/**************************************************
* Execute a standard build from buildConfigs
***************************************************/
def executeStandardBuild(stagePrefix = '', executionKeyPrefix = '', resetSonarExecution = false, buildConfig) {
	def managedFiles = []
	def dockerfileConfig = buildConfig.agent.dockerfile
	def configs = getConfigs()

	if (isToResetSonarAnalyses() && buildConfig.conditionToBuildInResetSonarContext != null && nullToEmpty(buildConfig.conditionToBuildInResetSonarContext.mustHaveChangesInPaths) != "") {
		def noFilesChanged = sh(returnStdout: true, script: "git diff --name-only $configs.sonarConfigs.resetSonar.resetBranch temp-branch | grep $buildConfig.conditionToBuildInResetSonarContext.mustHaveChangesInPaths | wc -l").trim()
		echo noFilesChanged
		if (noFilesChanged == "0") {
			sh "echo '<span style=\\\"color:black;\\\">💤 SKIPPED (no files changed)</span>' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result'"
			return
		}
	}
	buildConfig.managedFiles.each{ managedFile ->
		managedFiles.add(configFile(fileId: managedFile.fileId, targetLocation: managedFile.targetLocation))
	}
	configFileProvider(managedFiles) {
		try {
			if (!resetSonarExecution || buildConfig.sonarEnabled) {
				def shell = dockerfileConfig.shell == null ? "/bin/bash" : dockerfileConfig.shell 
				
				def sonarProjectKey = ""
				def sonarProjectName = ""
				def sonarURL = ""
				def versionLocal = nullToEmpty(env.version)
				def oldVersionLocal = nullToEmpty(env.oldVersion)
				if (configs.sonarConfigs != null) {
					sonarProjectKey = configs.sonarConfigs.projectKey
					sonarProjectName = configs.sonarConfigs.projectName
					sonarURL = configs.sonarConfigs.url
				}
				
				sh "cd \"${dockerfileConfig.dir}\" && \
					docker build -f '$dockerfileConfig.filename' $dockerfileConfig.additionalBuildArgs . && \
					echo '<span>❌ FAILED</span>' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result' && \
					export SONAR_PROJECT_KEY=`$sonarProjectKey` && \
					export SONAR_PROJECT_NAME=`$sonarProjectName` && \
					export SONAR_PROJECT_KEY=\"$buildConfig.key-\$SONAR_PROJECT_KEY\" && \
					export SONAR_PROJECT_NAME=\"$buildConfig.key - \$SONAR_PROJECT_NAME\" && \
					docker run -u 0:0 --volumes-from jenkins --rm --entrypoint '' -w '$WORKSPACE' -e WORKSPACE='$WORKSPACE' -e version='$versionLocal' -e oldVersion='$oldVersionLocal' -e SONAR_URL=$sonarURL -e SONAR_PROJECT_KEY=\"\$SONAR_PROJECT_KEY\" -e SONAR_PROJECT_NAME=\"\$SONAR_PROJECT_NAME\" ${dockerfileConfig.args} \$(docker build -q -f '$dockerfileConfig.filename' $dockerfileConfig.additionalBuildArgs .) \
					$shell -c 'set -o xtrace && $buildConfig.buildCommand && echo \"<span style=\\\"color:black;\\\">✔ PASSED</span>\" > \"$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result\"' 2>&1 | tee '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.log'"

				if (!resetSonarExecution) {
					archiveFilesFromQualityChecks(buildConfig.qualityChecks)
				}
			}
			else {
				sh "echo '<span style=\\\"color:black;\\\">💤 SKIPPED</span>' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result'"
			}
		} catch (err) {
	        echo err.getMessage()
			sh "echo '<span style=\\\"color:black;\\\">❌ FAILED</span>' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result'"
	    }
	}
}

/**************************************************
* Archive files from quality checks
***************************************************/
def archiveFilesFromQualityChecks(qualityChecks = [ ]) {
	if (qualityChecks != null) {
		qualityChecks.each{ qualityCheck ->
			if (qualityCheck.fileToArchive != null) {
				archiveFiles(qualityCheck.fileToArchive)
			}
		}
	}
}

/**************************************************
* Publishes a docker images
***************************************************/
def publishDockerImage(publishConfig = [ ], version = '') {
	echo "Publishing: version $version of " + groovy.json.JsonOutput.toJson(publishConfig)
	if (publishConfig.command != null && publishConfig.command != "") {
		sh "version=$version && $publishConfig.command"
	}
	if (publishConfig.dockerCredentialId != null && publishConfig.dockerCredentialId != "") {
		withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: publishConfig.dockerCredentialId, usernameVariable: 'DOCKER_USERNAME', passwordVariable: 'DOCKER_PASSWORD']]) {
			def dockerRegistryAddress = publishConfig.targetImage.substring(0, publishConfig.targetImage.indexOf("/"))
			sh 'docker login ' + dockerRegistryAddress + ' -u "$DOCKER_USERNAME" -p "$DOCKER_PASSWORD"'
			sh "version=$version && \
				docker tag  \"" + publishConfig.sourceImage + "\" \"" + publishConfig.targetImage + "\" && \
				docker push \"" + publishConfig.targetImage + "\" && \
				docker logout $dockerRegistryAddress"
		}
	}
	else {
		sh "version=$version && \
			docker tag  \"" + publishConfig.sourceImage + "\" \"" + publishConfig.targetImage + "\" && \
			docker push \"" + publishConfig.targetImage + "\""
	}
}

/**************************************************
* Peforms an npm publish 
***************************************************/
def publishNPM(publishConfig = [ ], version = '') {
	echo "Publishing: version $version of " + groovy.json.JsonOutput.toJson(publishConfig)
	if (publishConfig.command != null && publishConfig.command != "") {
		sh "version=$version && $publishConfig.command"
	}
	
	def sourceFolder = publishConfig.sourceFolder
	if (publishConfig.npmCredentialId != null && publishConfig.npmCredentialId != "") {
		withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: publishConfig.npmCredentialId, usernameVariable: 'NPM_USERNAME', passwordVariable: 'NPM_PASSWORD']]) {
			def npmRepositoryProtocol = publishConfig.npmRepositoryURL.substring(0, publishConfig.npmRepositoryURL.indexOf("://")+3)
			def npmRepositoryURLWithoutProtocol = publishConfig.npmRepositoryURL.substring(publishConfig.npmRepositoryURL.indexOf("://") + 3)
			sh "version=$version && \
				cd \"$sourceFolder\" && \
				json -I -f package.json -e 'this.publishConfig.registry=\"$npmRepositoryProtocol$NPM_USERNAME:$NPM_PASSWORD@$npmRepositoryURLWithoutProtocol\"' && \
				npm publish"
		}
	}
	else {
		sh "version=$version && \
			cd \"$sourceFolder\" && \
			json -I -f package.json -e 'this.publishConfig.registry=\"$publishConfig.npmRepositoryURL\"' && \
			npm publish"
	}
    publishConfig.components.each{ component ->
    	env.NOTIFICATION_PUBLISHED_NPM_COMPONENTS += ' ' + sh(returnStdout: true, script: "version=$version && echo \"" + component + "@" + version + "\"").trim()
    }
}

/**************************************************
* Publishes a maven artifact
***************************************************/
def publishMavenArtifact(publishConfig = [ ], version = '') {
	echo "Publishing: version $version of " + groovy.json.JsonOutput.toJson(publishConfig)
	
	def managedFiles = []
	if (publishConfig.managedFiles != null) {
		publishConfig.managedFiles.each{ managedFile ->
			managedFiles.add(configFile(fileId: managedFile.fileId, targetLocation: managedFile.targetLocation))
		}
	}
	configFileProvider(managedFiles) {
		if (publishConfig.command != null && publishConfig.command != "") {
			sh "version=$version && $publishConfig.command"
		}
		publishConfig.packages.each{ packageConfig ->
			echo "Uploading: " + groovy.json.JsonOutput.toJson(packageConfig)
			uploadMavenArtifact(packageConfig, version)
			env.NOTIFICATION_PUBLISHED_MAVEN_ARTIFACTS += ' ' + sh(returnStdout: true, script: "version=$version && echo " + packageConfig.groupId + ':' + packageConfig.artifactId + ':' + version + ':' + packageConfig.packaging).trim()
	    }
	}
}

/*****************************************
* Uploads a package to nexus with a assumption
* that there's a tar.gz file related to artifactId
* and version provided in the workspace root folder
****************************************/
def uploadMavenArtifact(packageConfig = [ ], version = '') {
	if (packageConfig.packaging == "pom") {
		sh "version=$version && \
			mvn jar:jar org.apache.maven.plugins:maven-deploy-plugin:2.7:deploy -s .m2/settings.xml \
			-f \"" + packageConfig.file + "\" \
			-DaltDeploymentRepository=" + packageConfig.repositoryId + "::default::" + packageConfig.mavenRepositoryURL
	}
	else {
		sh "version=$version && \
			mvn deploy:deploy-file -s .m2/settings.xml \
			-Durl=\"" + packageConfig.mavenRepositoryURL + "\" \
			-DrepositoryId=\"" + packageConfig.repositoryId + "\" \
			-Dfile=\"" + packageConfig.file + "\" \
			-Dpackaging=\"" + packageConfig.packaging + "\" \
			-DgeneratePom=true \
			-DgeneratePom.description=\"Generated from ${GIT_BRANCH} at ${GIT_COMMIT}\" \
			-DgroupId=\"" + packageConfig.groupId + "\" \
			-DartifactId=\"" + packageConfig.artifactId + "\" \
			-Dversion=\"" + version + "\""
	}
}


/*****************************************
* Sends the pipeline success email notification
****************************************/
def sendSuccessNotification(result, net.sf.json.JSONObject configs) {
	def notificationtTemplates = [
		email: "",
		slack: "",
		confluence: "",
		jira: ""
	]
	if (configs.notifications.email != null && configs.notifications.email[result] != null) {
		notificationtTemplates.email = readFile(configs.notifications.email[result].templatePath)
	}
	if(configs.notifications.slack != null && configs.notifications.slack[result] != null) {
		notificationtTemplates.slack = readFile(configs.notifications.slack[result].templatePath)
	}
	if(configs.notifications.confluence != null && configs.notifications.confluence[result] != null) {
		notificationtTemplates.confluence = readFile(configs.notifications.confluence[result].templatePath)
	}
	if(configs.notifications.jira != null && configs.notifications.jira[result] != null) {
		notificationtTemplates.jira = readFile(configs.notifications.jira[result].templatePath)
	}

			
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_REPO", nullToEmpty("$GIT_URL").substring("$GIT_URL".lastIndexOf('/') + 1).replaceAll(".git", ""))
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_BRANCH", nullToEmpty(env.NOTIFICATION_GIT_BRANCH).replaceAll("origin/", ""))
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_COMMIT", nullToEmpty(env.NOTIFICATION_GIT_COMMIT))
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_VERSIONS", nullToEmpty(env.NOTIFICATION_VERSIONS))
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_RESULT", result.toUpperCase())
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_DURATION", "${currentBuild.durationString.replace(' and counting', '')}")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_URL", "$BUILD_URL")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_CURRENT_DATE", new Date().format(configs.notifications.configs.dateFormat, TimeZone.getTimeZone(configs.notifications.configs.dateTimezone)))

	groovy.lang.Closure tranformFn = null

	def dockerImagesPublished = nullToEmpty(env.NOTIFICATION_PUBLISHED_DOCKER_IMAGES).trim().split(" ")
	tranformFn = { rowTemplate, dockerImagePublished ->
		if (nullToEmpty(dockerImagePublished) == "") {
			return rowTemplate.replaceAll("PLACEHOLDER_PUBLISHED_DOCKER_IMAGE", "Not applicable")
		}
		else {
			return rowTemplate.replaceAll("PLACEHOLDER_PUBLISHED_DOCKER_IMAGE", dockerImagePublished)
		}
	}
	notificationtTemplates = replaceRowsPlaceholdersInTemplates(notificationtTemplates, "PLACEHOLDER_PUBLISHED_DOCKER_IMAGES", dockerImagesPublished, tranformFn)
					
	def mavenArtifactsPublished = nullToEmpty(env.NOTIFICATION_PUBLISHED_MAVEN_ARTIFACTS).trim().split(" ")
	tranformFn = { rowTemplate, mavenArtifactPublished ->
		if (nullToEmpty(mavenArtifactPublished) == "") {
			return rowTemplate.replaceAll("PLACEHOLDER_PUBLISHED_MAVEN_ARTIFACT", "Not applicable")
		}
		else {
			return rowTemplate.replaceAll("PLACEHOLDER_PUBLISHED_MAVEN_ARTIFACT", mavenArtifactPublished)
		}
	}
	notificationtTemplates = replaceRowsPlaceholdersInTemplates(notificationtTemplates, "PLACEHOLDER_PUBLISHED_MAVEN_ARTIFACTS", mavenArtifactsPublished, tranformFn)
	
	def npmComponentsPublished = nullToEmpty(env.NOTIFICATION_PUBLISHED_NPM_COMPONENTS).trim().split(" ")
	tranformFn = { rowTemplate, npmComponentPublished ->
		if (nullToEmpty(npmComponentPublished) == "") {
			return rowTemplate.replaceAll("PLACEHOLDER_PUBLISHED_NPM_COMPONENT", "Not applicable")
		}
		else {
			return rowTemplate.replaceAll("PLACEHOLDER_PUBLISHED_NPM_COMPONENT", npmComponentPublished)
		}
	}
	notificationtTemplates = replaceRowsPlaceholdersInTemplates(notificationtTemplates, "PLACEHOLDER_PUBLISHED_NPM_COMPONENTS", npmComponentsPublished, tranformFn)

	notificationtTemplates = replaceReleaseNotesPlaceholders(notificationtTemplates)
	notificationtTemplates = replaceJIRAPlaceholders(notificationtTemplates, result, configs)

	tranformFn = { rowTemplate, buildConfig, templateKey ->
		if (buildConfig.enabled) {
			def buildResult = sh(returnStdout: true, script: "cat '${buildConfig.key}.result'").trim()
			if (templateKey == "slack" || templateKey == "jira") {
				buildResult = buildResult.replaceAll("<.*?>", "")
			}
			rowTemplate = replaceSonarResultsPlaceholders(buildConfig, rowTemplate, templateKey)
								.replaceAll("PLACEHOLDER_BUILD_NAME", buildConfig.name)
								.replaceAll("PLACEHOLDER_BUILD_RESULT", buildResult)
								.replaceAll("PLACEHOLDER_BUILD_LOG_URL", buildResult.contains("SKIPPED") ? "" : "${BUILD_URL}artifact/${buildConfig.key}.log")
			
			def qualityCheckTemplateSpecs = findEmailRowTemplate(rowTemplate, "PLACEHOLDER_QUALITY_CHECK")
			if (qualityCheckTemplateSpecs != null) {
				def qualityCheckBuilder = "" << rowTemplate.substring(0, rowTemplate.indexOf("PLACEHOLDER_QUALITY_CHECK_START"))
				if (buildConfig.qualityChecks != null) {
					buildConfig.qualityChecks.each{ qualityCheck ->
						def qualityCheckURL = (nullToEmpty(qualityCheck.url) != "" ? qualityCheck.url : java.net.URLEncoder.encode(qualityCheck.fileToArchive, "UTF-8"))
						def qualityCheckResult = sh(returnStdout: true, script: "cat '${qualityCheck.resultFile}' || echo '<span style=\"color:black;\">💤 NOT AVAILABLE</span>'").trim()
						if (templateKey == "slack" || templateKey == "jira") {
							qualityCheckResult = qualityCheckResult.replaceAll("<.*?>", "")
						}
						qualityCheckBuilder <<= qualityCheckTemplateSpecs.rowTemplate
													.replaceAll("PLACEHOLDER_QUALITY_CHECK_URL", "${BUILD_URL}artifact/" + qualityCheckURL)
													.replaceAll("PLACEHOLDER_QUALITY_CHECK_NAME", qualityCheck.name)
													.replaceAll("PLACEHOLDER_QUALITY_CHECK_RESULT", qualityCheckResult)
					}
				}
				qualityCheckBuilder <<= rowTemplate.substring(rowTemplate.indexOf("PLACEHOLDER_QUALITY_CHECK_END") + "PLACEHOLDER_QUALITY_CHECK_END".length())
				return qualityCheckBuilder.toString()
			}
			return rowTemplate
		}
		return ""
	}	
	notificationtTemplates = replaceRowsPlaceholdersInTemplates(notificationtTemplates, "PLACEHOLDER_BUILD_SUMMARY", configs.buildConfigs, tranformFn)
	notificationtTemplates = replaceRowsPlaceholdersInTemplates(notificationtTemplates, "PLACEHOLDER_BUILD_DETAILS", configs.buildConfigs, tranformFn)

	if (configs != null && configs.notifications != null ) {
		configs.notifications.keySet().each{ notificationKey ->
			if (notificationKey != "configs") {
				if (nullToEmpty(configs.notifications[notificationKey].filePath) != "") {
					writeFile   file: configs.notifications[notificationKey].filePath, text: nullToEmpty(notificationtTemplates[notificationKey])
				}
				
				if (configs.notifications[notificationKey].ignoreWhenVersionNotIncremented != true || env.version != env.oldVersion) {
					if (notificationKey == "email" && configs.notifications.email[result] != null) {
						try {
						    emailext 	subject: configs.notifications.email[result].subject + " - " + nullToEmpty(env.NOTIFICATION_GIT_BRANCH).replaceAll("origin/", "") + " #$BUILD_NUMBER",
						    			to: nullToEmpty(env.NOTIFICATION_GIT_BRANCH).replaceAll("origin/", "").equals("feature/setup_automations") ? configs.notifications.email.maintenance.mailingList : configs.notifications.email[result].mailingList,
						    			body: notificationtTemplates.email
						} catch (err) {
					        echo err.getMessage()
					    }
					}
					else if (notificationKey == "slack" && configs.notifications.slack[result] != null) {
						try {
							slackSend	teamDomain: configs.notifications.slack[result].teamDomain,
										tokenCredentialId: configs.notifications.slack[result].tokenCredentialId,
										channel: configs.notifications.slack[result].channel,
										color: result.equals("success") ? "good" : "danger",
										message: notificationtTemplates.slack					
						} catch (err) {
					        echo err.getMessage()
					    }
					}
					else if (notificationKey == "confluence" && configs.notifications.confluence[result]) {
						try {
							publishConfluence 	siteName: configs.notifications.confluence[result].siteName,
												spaceName: configs.notifications.confluence[result].spaceName,
												pageName: configs.notifications.confluence[result].pageName,
												parentId: configs.notifications.confluence[result].parentId,
												editorList: [ confluencePrependPage(confluenceText(notificationtTemplates.confluence)) ]
						} catch (err) {
					        echo err.getMessage()
					    }
					}
					else if (notificationKey == "jira" && configs.notifications.jira[result] != null && env.jiraKeys != null) {
						try {
							def jiraVersions = [:]
							def jiraKeysObj = readJSON text: env.jiraKeys
							
							jiraKeysObj.keySet().each{ jiraKey ->
								def jiraProject = jiraKey.substring(0, jiraKey.indexOf("-"))
								
								jiraAddComment  idOrKey: jiraKey,
												site: configs.jiraConfigs.jiraSite, 
												auditLog: false,
												failOnError: false,
												input: [ body: notificationtTemplates.jira ]
								
								if (nullToEmpty(configs.jiraConfigs.fixVersionName) != "") {
									if (jiraVersions[jiraProject] == null) {
										jiraVersions[jiraProject] = jiraCreateVersion(jiraProject, sh(returnStdout: true, script: "echo $configs.jiraConfigs.fixVersionName").trim(), configs)
									}
															
									if (result.toUpperCase() == "SUCCESS") {
										if (jiraVersions[jiraProject] != null) {
											def jiraIssue = jiraGetIssue idOrKey: jiraKey,
																		 site: configs.jiraConfigs.jiraSite,
																		 failOnError: false
										    def fixVersions = jiraIssue.data.fields.fixVersions << jiraVersions[jiraProject].data
											jiraEditIssue   idOrKey: jiraKey, 
															site: configs.jiraConfigs.jiraSite,
															auditLog: false,
															failOnError: false,
															issue: [ fields: [ fixVersions: fixVersions ] ]

										}
									}
								}
							}
						} catch (err) {
					        echo err.getMessage()
					    }
					}
				}
			}
		}
	}
}

/*****************************************
* Sends the pipeline maintenance email notification
****************************************/
def sendMaintenanceNotification(net.sf.json.JSONObject configs) {
	def notificationtTemplates = [
  		email: "",
  		slack: "",
  		confluence: ""
  	]
  	if(configs.notifications.email != null && configs.notifications.email.maintenance != null) {
  		notificationtTemplates.email = readFile(configs.notifications.email.maintenance.templatePath)
  	}
  	if(configs.notifications.slack != null && configs.notifications.slack.maintenance != null) {
  		notificationtTemplates.slack = readFile(configs.notifications.slack.maintenance.templatePath)
  	}
  	if(configs.notifications.confluence != null && configs.notifications.confluence.maintenance != null) {
  		notificationtTemplates.confluence = readFile(configs.notifications.confluence.maintenance.templatePath)
  	}
    		
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_REPO", nullToEmpty("$GIT_URL").substring("$GIT_URL".lastIndexOf('/') + 1).replaceAll(".git", ""))
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_BRANCH", "$GIT_BRANCH")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_COMMIT", "$GIT_COMMIT")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_RESULT", "UNSTABLE")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_DURATION", "${currentBuild.durationString.replace(' and counting', '')}")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_URL", "$BUILD_URL")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_CURRENT_DATE", new Date().format(configs.notifications.configs.dateFormat, TimeZone.getTimeZone(configs.notifications.configs.dateTimezone)))


	if (configs != null && configs.notifications != null ) {
		configs.notifications.keySet().each{ notificationKey ->
			if (notificationKey != "configs") {
				if (nullToEmpty(configs.notifications[notificationKey].filePath) != "") {
					writeFile   file: configs.notifications[notificationKey].filePath, 
								text: notificationtTemplates[notificationKey]
				}
				
				if (notificationKey == "email" && configs.notifications.email.maintenance != null) {
					try {
					    emailext 	subject: configs.notifications.email.maintenance.subject,
					    			to: configs.notifications.email.maintenance.mailingList,
					    			body: notificationtTemplates.email
					} catch (err) {
				        echo err.getMessage()
				    }
				}
				else if (notificationKey == "slack" && configs.notifications.slack.maintenance != null) {
					try {
						slackSend	teamDomain: configs.notifications.slack.maintenance.teamDomain,
									tokenCredentialId: configs.notifications.slack.maintenance.tokenCredentialId,
									channel: configs.notifications.slack.maintenance.channel,
									color: "danger",
									message: notificationtTemplates.slack					
					} catch (err) {
				        echo err.getMessage()
				    }
				}
				else if (notificationKey == "confluence" && configs.notifications.confluence.maintenance != null) {
					try {
						publishConfluence 	siteName: configs.notifications.confluence.maintenance.siteName,
											spaceName: configs.notifications.confluence.maintenance.spaceName,
											pageName: configs.notifications.confluence.maintenance.pageName,
											parentId: configs.notifications.confluence.maintenance.parentId,
											editorList: [ confluencePrependPage(confluenceText(notificationtTemplates.confluence)) ]
					} catch (err) {
				        echo err.getMessage()
				    }
				}
			}
		}
	}
}

/*****************************************
* Replace a placeholder by a value in a 
* map of templates
****************************************/
def replacePlaceholderInTemplates(java.util.LinkedHashMap templates, placeholder = '', value = '') {
	templates.keySet().each{ templateKey ->
		templates[templateKey] = templates[templateKey].replaceAll(placeholder, value)
	}
	return templates
}

/*****************************************
* Replace row placeholders in a 
* map of templates
****************************************/
def replaceRowsPlaceholdersInTemplates(templates, rowPlaceholder, rowsData, transformClosure) {
	templates.keySet().each{ templateKey ->
		def originalTemplate = templates[templateKey]
		def rowTemplateSpecs = findEmailRowTemplate(originalTemplate, rowPlaceholder)
		
		if (rowTemplateSpecs != null) {
			def contentBuilder = ""<< originalTemplate.substring(0, originalTemplate.indexOf(rowPlaceholder + "_START"))
			def rowContextAdded = false
					
			if (rowsData != null && (rowsData instanceof Collection || rowsData.getClass().isArray())) {
				rowsData.each { rowData ->
					def rowContent = transformClosure(rowTemplateSpecs.rowTemplate, rowData, templateKey)
					if (rowContent != null) {
						contentBuilder <<= rowContent
						rowContextAdded = true
					}
				}
			}
			
			if (!rowContextAdded) {
				contentBuilder <<= transformClosure(rowTemplateSpecs.rowTemplate, null, templateKey)
			}
			
			contentBuilder <<= originalTemplate.substring(originalTemplate.indexOf(rowPlaceholder + "_END") + (rowPlaceholder + "_END").length())
			templates[templateKey] = contentBuilder.toString()
		}
	}
	return templates
}


/*****************************************
* Searched in the email template for a
* specific row template delimmited by the
* placeholder provided as input
****************************************/
def findEmailRowTemplate(emailTemplate = '', placeholder = '') {
	if (emailTemplate == null || placeholder == null) {
		return null
	}

	def indexOfPlaceholderStart = emailTemplate.indexOf(placeholder + "_START")
	def indexOfPlaceholderEnd = emailTemplate.indexOf(placeholder + "_END")

	if (indexOfPlaceholderStart == -1 || indexOfPlaceholderEnd == -1) {
		return null
	}

	def placeholderStartLength = (placeholder + "_START").length()
	def placeholderEndLength = (placeholder + "_END").length()
	return [
		rowsPlaceholder : emailTemplate.substring(indexOfPlaceholderStart, indexOfPlaceholderEnd + placeholderEndLength),
		rowTemplate : emailTemplate.substring(indexOfPlaceholderStart + placeholderStartLength, indexOfPlaceholderEnd)
	]
}


/*****************************************
* Returns an empty string if a null
* value is passed as input
****************************************/
def nullToEmpty(value = '') {
	return value ? value : ""
}

/*****************************************
* Archive in job result all log
* files in root path
****************************************/
def archiveLogsAndEmail() {
	def configs = getConfigs()

	archiveFiles("*.log")
	if (configs != null && configs.notifications != null ) {
		configs.notifications.keySet().each{ notificationKey ->
			if (notificationKey != "configs" && nullToEmpty(configs.notifications[notificationKey].filePath) != "") {
				archiveFiles(configs.notifications[notificationKey].filePath)
			}
		}
	}
}

/*****************************************
* Archive in job result files that 
* match pattern
****************************************/
def archiveFiles(pattern = '') {
	try {
		echo "Archiving files matching $pattern"
		archiveArtifacts artifacts: pattern, fingerprint: false
	} catch (err) {
        echo err.getMessage()
    }
}

/*****************************************
* Identifies if sonar reset should be done
****************************************/
def isToResetSonarAnalyses() {
	def configs = getConfigs()
	return 	configs.sonarConfigs != null && 
			configs.sonarConfigs.url != null &&
			!configs.sonarConfigs.resetSonar.skipBranches.contains("$GIT_BRANCH".replaceAll("origin/", "")) 
}

/*****************************************
* Setup origin-rw remote
****************************************/
def setupOriginRWRemote(def gitCredentials = '') {
	def configs = getConfigs()
	//Logic to add no-password remote
	def gitURLWithoutProtocol = sh(returnStdout: true, script: 'git config remote.origin.url').trim().replaceFirst('^(http[s]?://www\\.|http[s]?://|www\\.)','').replaceFirst('([/]?)$','')
	sh 'git remote rm origin-rw | true'
	sh "git remote add origin-rw ${GIT_PROTOCOL}://${gitURLWithoutProtocol}"
	withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: gitCredentials, usernameVariable: 'SONAR_RESET_GIT_CREDENTIALS_USR', passwordVariable: 'SONAR_RESET_GIT_CREDENTIALS_PSW']]) {
		sh 'echo "' + env.GIT_PROTOCOL + '://' + java.net.URLEncoder.encode("${SONAR_RESET_GIT_CREDENTIALS_USR}", "UTF-8") + ':${SONAR_RESET_GIT_CREDENTIALS_PSW}@' + gitURLWithoutProtocol + '" > "' + env.WORKSPACE + '/.git/.git-credentials"'
	}
	sh "git config credential.helper \"store --file='$WORKSPACE/.git/.git-credentials'\""
}

/*****************************************
* Logic reset sonar analysis
****************************************/
def resetSonarAnalyses() {
	def configs = getConfigs()
	def buildConfigs = configs.buildConfigs

	//Remove sonar project to recreate it based in $configs.sonarConfigs.resetSonar.resetBranch
	buildConfigs.each{ buildConfig ->
		if (buildConfig.enabled && buildConfig.sonarEnabled) {
			def projectKeyToDelete = "${buildConfig.key}-" + sh(returnStdout: true, script: "echo `$configs.sonarConfigs.projectKey`").trim()
			withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: configs.sonarConfigs.resetSonar.adminCredentials, usernameVariable: 'SONAR_RESET_SONAR_ADMIN_CREDENTIALS_USR', passwordVariable: 'SONAR_RESET_SONAR_ADMIN_CREDENTIALS_PSW']]) {
				def curlArguments = "--insecure -s -X POST '$configs.sonarConfigs.url/api/projects/delete?project=$projectKeyToDelete'"
				sh 'curl -u ${SONAR_RESET_SONAR_ADMIN_CREDENTIALS_USR}:${SONAR_RESET_SONAR_ADMIN_CREDENTIALS_PSW} ' + curlArguments 
			}
		}
	}

    setupOriginRWRemote(configs.sonarConfigs.resetSonar.gitCredentials)

	//Store current commit in temp-branch
	sh "rm -Rf .git/hooks && \
		git branch -D temp-branch | true && \
		git checkout -b temp-branch"

	retry(3) {
		sh "git fetch origin-rw $configs.sonarConfigs.resetSonar.resetBranch:$configs.sonarConfigs.resetSonar.resetBranch && \
			git checkout -f $configs.sonarConfigs.resetSonar.resetBranch"
	}
	
	//Run base analysis
	executeBuilds("Reset Sonar for ", "sonar-reset-", true)

	//Wait for base analysis to end
	buildConfigs.each{ buildConfig ->
		if (buildConfig.enabled && buildConfig.sonarEnabled) {
			if (sh(returnStdout: true, script: "cat 'sonar-reset-${buildConfig.key}.result'").contains("PASSED")) {
				waitForSonarAnalysis(sh(returnStdout: true, script: buildConfig.sonarTaskUrl))
		    }
		}
	}

	//Return to original branch
	sh "rm -Rf .git/hooks && \
		git checkout . && \
		git checkout -f temp-branch"
}

/*****************************************
* Waits for Sonar analysis to end
****************************************/
def waitForSonarAnalysis(ceTaskUrl = '') {
	if (ceTaskUrl == null || ceTaskUrl == "") {
		return ""
	}

	int maxFailedAttempts = 120;
	int secondsBetweenAttempts = 10

	int failedAttempts = 0;
	echo "Waiting for sonar task results..."

	while (failedAttempts < maxFailedAttempts) {
		def ceTaskResult = null
		try {
			sh "curl --insecure -o ./ceTaskResult.json $ceTaskUrl"
			ceTaskResult = readJSON file: "./ceTaskResult.json"
		} catch (err) {
		    echo err.getMessage()
		}
		if (ceTaskResult != null && ceTaskResult.task != null && ceTaskResult.task.status != "IN_PROGRESS" && ceTaskResult.task.status != "PENDING") {
			if (ceTaskResult.task.status != "SUCCESS") {
				echo ceTaskResult.toString()
				sh "echo 'Error processing sonar analysis.' && exit 1"
			}
			return ceTaskResult.task.analysisId
		}
		else {
		    failedAttempts += 1
		    if (failedAttempts < maxFailedAttempts) {
				echo "Sonar task is still in progress. Retry #" + failedAttempts.toString() + " in " + secondsBetweenAttempts.toString() + " seconds..."
		    	sh "sleep " + secondsBetweenAttempts.toString()
		    }
		}
	}
	sh "echo 'Error trying to get sonar quality gate results.' && exit 1"
}

/*****************************************
* Gathers the release notes and place
* them in email body
****************************************/
def replaceReleaseNotesPlaceholders(java.util.LinkedHashMap templates) {
	def compareHeadTo = ""
	def compareMethod = ".."
	def configs = getConfigs()
	if (isToResetSonarAnalyses()) {
		compareHeadTo = "$configs.sonarConfigs.resetSonar.resetBranch"
		templates = replacePlaceholderInTemplates(templates, "PLACEHOLDER_NEW_COMMITS_MESSAGE", "not yet in $configs.sonarConfigs.resetSonar.resetBranch")
	}
	else if (isToUpdateVersion()) {
		def commitOfPreviousVersion = findCommitOfPreviousVersion(configs.versionConfigs.masterVersion.gitTagPath, configs.versionConfigs.newVersion.gitTagPath)
		if (commitOfPreviousVersion != null) {
			compareHeadTo = commitOfPreviousVersion.commitId
			compareMethod = "..."
			templates = replacePlaceholderInTemplates(templates, "PLACEHOLDER_NEW_COMMITS_MESSAGE", "since version $commitOfPreviousVersion.previousVersion")
		}
		else {
			templates = replacePlaceholderInTemplates(templates, "PLACEHOLDER_NEW_COMMITS_MESSAGE", "")
		}
	}
	else {
		def gitBranch = nullToEmpty(env.NOTIFICATION_GIT_BRANCH).replaceAll("origin/", "")
		try {
			def previousExecutionCommit = sh(returnStdout: true, script: "git rev-list -n 1 refs/tags/$configs.executionControl.tagPath/$gitBranch").trim()
			if (nullToEmpty(previousExecutionCommit) != "") {
				compareHeadTo = previousExecutionCommit
			}
		} catch (err) {
	    }
		
		setupOriginRWRemote(configs.executionControl.gitCredentials)
		sh "git tag -d \$(git tag -l) && git fetch --tags --no-recurse-submodules origin-rw"
		try {
			sh "git push --no-verify -f --delete origin-rw tag $configs.executionControl.tagPath/$gitBranch"
		} catch (err) {
	    }
		try {
			sh "git tag -f $configs.executionControl.tagPath/$gitBranch && git push --no-verify origin-rw $configs.executionControl.tagPath/$gitBranch"
		} catch (err) {
	    }
		
		compareMethod = "..."
		templates = replacePlaceholderInTemplates(templates, "PLACEHOLDER_NEW_COMMITS_MESSAGE", "since previous review")
	}

	sh "rm -rf ./newCommits.json && touch ./newCommits.json"
	if (compareHeadTo != "") {
		//Format "hash #@# author #@# date #@# message"
		sh "git log --no-merges --pretty=format:\"%h #@# %cn #@# %ci #@# %s ##@@##\" ${compareHeadTo}${compareMethod}HEAD >> ./newCommits.json || true"
	}
	def gitCommits = readFile("newCommits.json").trim()
	def gitCommitsArray
	
	def includeMergeRequest = (compareHeadTo != "" && nullToEmpty(gitCommits) == "")
	if (includeMergeRequest) {
		sh "rm -rf ./newCommits.json && touch ./newCommits.json"
		sh "git log --pretty=format:\"%h #@# %cn #@# %ci #@# %s ##@@##\" ${compareHeadTo}${compareMethod}HEAD >> ./newCommits.json || true"
		gitCommits = readFile("newCommits.json").trim()
		gitCommitsArray = gitCommits.split("##@@##")
	}
	else {
		gitCommitsArray = gitCommits.split("##@@##")
	}
	
	templates = replaceRowsPlaceholdersInTemplates(templates, "PLACEHOLDER_NEW_COMMITS_ROW", gitCommitsArray, { rowTemplate, gitCommit, templateKey ->
		if (nullToEmpty(gitCommit).trim() != "") {
			def gitCommitDetails = gitCommit.split(" #@# ")
			if (gitCommitDetails.size() > 3) {
				def commitMessage = java.util.regex.Matcher.quoteReplacement(gitCommitDetails[3])
				if (templateKey == "email") {
					env.commitMessages = nullToEmpty(env.commitMessages) + "##@@##" + java.util.regex.Matcher.quoteReplacement(gitCommitDetails[0]) + " #@# " + commitMessage
				}
				return rowTemplate.replaceAll('PLACEHOLDER_NEW_COMMITS_ROW_SUMMARY', commitMessage)
								  .replaceAll('PLACEHOLDER_NEW_COMMITS_ROW_AUTHOR', java.util.regex.Matcher.quoteReplacement(gitCommitDetails[1]))
			}
		}
		return rowTemplate.replaceAll('PLACEHOLDER_NEW_COMMITS_ROW_SUMMARY', "")
				  		  .replaceAll('PLACEHOLDER_NEW_COMMITS_ROW_AUTHOR', "")
	});
	if (!includeMergeRequest && configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages != null && configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages.includeMergeCommits == true) {
		sh "git log --merges --pretty=format:\"%h #@# %cn #@# %ci #@# %s ##@@##\" ${compareHeadTo}${compareMethod}HEAD >> ./newMergeCommits.json || true"
		def gitMergeCommits = readFile("newMergeCommits.json").trim()
		gitMergeCommits.split("##@@##").each{ gitMergeCommit ->
			if (nullToEmpty(gitMergeCommit).trim() != "") {
				def gitMergeCommitDetails = gitMergeCommit.split(" #@# ")
				if (gitMergeCommitDetails.size() > 3) {
					env.commitMessages = nullToEmpty(env.commitMessages) + "##@@##" + java.util.regex.Matcher.quoteReplacement(gitMergeCommitDetails[0]) + " #@# " + java.util.regex.Matcher.quoteReplacement(gitMergeCommitDetails[3])
				}
			}
		}
	}
	
	return templates
}

/*****************************************
* Gathers the JIRA keys and place
* them in email body
****************************************/
def replaceJIRAPlaceholders(java.util.LinkedHashMap templates, result, net.sf.json.JSONObject configs) {
	def jiraKeys = [:]
	def transitionsConfigsPerInitStatus = configs.jiraConfigs[result.toLowerCase()] != null ? configs.jiraConfigs[result.toLowerCase()].transitionsConfigsPerInitStatus : null 

	//Condition to try to find jiras
	if (configs.jiraConfigs != null && configs.jiraConfigs.lookForJiraKeysConfig != null && configs.jiraConfigs.jiraKeyRegex != null) {
		//Condition to try to find jiras in branch name
		if (configs.jiraConfigs.lookForJiraKeysConfig.lookInBranchName != null && configs.jiraConfigs.lookForJiraKeysConfig.lookInBranchName.enabled == true) {
			//Condition to filter branches
			if (nullToEmpty(configs.jiraConfigs.lookForJiraKeysConfig.lookInBranchName.filterRegex) == "" || "$GIT_BRANCH".find(configs.jiraConfigs.lookForJiraKeysConfig.lookInBranchName.filterRegex) != null) {
				"$GIT_BRANCH".findAll(configs.jiraConfigs.jiraKeyRegex).each{ jiraKey ->
					jiraKeys = putJiraInMapIfValid(jiraKeys, jiraKey, "source branch name", transitionsConfigsPerInitStatus, configs)
				}
			}
		}
		//Condition to try to find jiras in commit messages
		if (configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages != null && configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages.enabled == true) {
			//Condition to filter commit messages
			if (nullToEmpty(configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages.filterRegex) == "" || "$GIT_BRANCH".find(configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages.filterRegex) != null) {
				nullToEmpty(env.commitMessages).split("##@@##").each{ commitDetails ->
					def commitDetailsAux = commitDetails.split(" #@# ")
					if (commitDetailsAux.size() == 2) {
						def commitHash = commitDetailsAux[0]
						def commitMessage = commitDetailsAux[1]
						commitMessage.findAll(configs.jiraConfigs.jiraKeyRegex).each{ jiraKey ->
							jiraKeys = putJiraInMapIfValid(jiraKeys, jiraKey, "commit message of " + commitHash, transitionsConfigsPerInitStatus, configs)
						}
					}
				}
			}
		}
	}
	echo "JIRA Details: " + groovy.json.JsonOutput.toJson(jiraKeys)
	env.jiraKeys = groovy.json.JsonOutput.toJson(jiraKeys)
	return replaceRowsPlaceholdersInTemplates(templates, "PLACEHOLDER_JIRA_LIST", jiraKeys.keySet(), { rowTemplate, jiraKey ->
		if (jiraKey == null) {
			return ""
		}
		def jiraData = jiraKeys[jiraKey]
		def jiraURL = ""
		def jiraFoundIn = ""
		def transitionsTitle = "No transitions performed"
		def transitionsError = "No error performing transitions"
		def jiraTransitions = []
				
		if (jiraData != null) {
			jiraURL = jiraData.url
			jiraFoundIn = jiraData.foundIn
			if (jiraData.transitionApplied != null) {
				transitionsTitle = (jiraData.transitionApplied.error ? "❌ " : "✔ ") + jiraData.transitionApplied.name
				transitionsError = jiraData.transitionApplied.errorMessage
				jiraTransitions = jiraData.transitionApplied.transitions
			}
		}
		
		rowTemplate = rowTemplate.replaceAll('PLACEHOLDER_JIRA_KEY', jiraKey)
	  			   	 			 .replaceAll('PLACEHOLDER_JIRA_URL', jiraURL)
	  			   	 			 .replaceAll('PLACEHOLDER_JIRA_FOUND_IN', jiraFoundIn)
	  			   	 			 .replaceAll('PLACEHOLDER_JIRA_TRANSITIONS_TITLE', transitionsTitle)
	  			   	 			 .replaceAll('PLACEHOLDER_JIRA_TRANSITIONS_ERROR', transitionsError)

  		def foundError = false
		return replaceRowsPlaceholdersInTemplates([ template: rowTemplate ], "PLACEHOLDER_JIRA_TRANSITIONS", jiraTransitions, { rowSubTemplate, transitionName ->
			if (transitionName != null) {
				foundError = foundError || transitionName.equals(jiraData.transitionApplied.errorIn)
				return rowSubTemplate.replaceAll('PLACEHOLDER_JIRA_TRANSITION_NAME', (foundError ? "❌ " : "✔ ") + transitionName)
			}
			return ""
		}).template
	});
}


/*****************************************
* Returns the commit id of the
* previous version
****************************************/
def putJiraInMapIfValid(jiraKeys, jiraKey, foundIn, transitionsConfigsPerInitStatus, net.sf.json.JSONObject configs) {
	if (jiraKeys[jiraKey] == null) {
		try {
			def jiraIssue = jiraGetIssue idOrKey: jiraKey,
							site: configs.jiraConfigs.jiraSite,
							failOnError: false
			if (jiraIssue != null && jiraIssue.data != null) {
				jiraKeys.put(jiraKey, [
				    foundIn: foundIn,
                    url: nullToEmpty(configs.jiraConfigs.jiraSite) + "/browse/" + jiraKey,
                    transitionApplied: jiraTryToApplyTransitions(jiraKey, jiraIssue.data, transitionsConfigsPerInitStatus, configs) 
                ])
			}
		} catch (err) {
	        echo err.getMessage()
	    }
	}
	return jiraKeys
}


/*****************************************
* Returns the commit id of the
* previous version
****************************************/
def jiraTryToApplyTransitions(jiraKey, jiraData, transitionsConfigsPerInitStatus, net.sf.json.JSONObject configs) {
	def output = null
	def jiraIssueStatus = jiraData.fields.status.id 

	if (jiraIssueStatus != null && transitionsConfigsPerInitStatus != null && transitionsConfigsPerInitStatus[jiraIssueStatus] != null) {
		output = [
            name: transitionsConfigsPerInitStatus[jiraIssueStatus].name,
            error: false,
            errorIn: "",
            errorMessage: "No error performing transitions",
            transitions: transitionsConfigsPerInitStatus[jiraIssueStatus].transitions.collect{ it -> it.name }
        ]
		transitionsConfigsPerInitStatus[jiraIssueStatus].transitions.each{ transitionData ->
			try {
				if (!output.error) {
					echo "Trying to apply transition: " + groovy.json.JsonOutput.toJson(transitionData)
					jiraTransitionIssue idOrKey: jiraKey,
										site: configs.jiraConfigs.jiraSite,
										auditLog: true,
										failOnError: true,
										input: transitionData.data
				}
			} catch (err) {
				output.error = true
				output.errorIn = transitionData.name
				output.errorMessage = err.getMessage() 
			}
		}
	}
	
	return output
}


/*****************************************
* Returns the commit id of the
* previous version
****************************************/
def jiraCreateVersion(jiraProject, jiraVersion, net.sf.json.JSONObject configs) {
	try {
		return jiraNewVersion([
            site: configs.jiraConfigs.jiraSite,
            auditLog: false,
			failOnError: true,
			version: [ name: jiraVersion, project: jiraProject ]
		])
	} catch (err) {
	}
	return null
}

/*****************************************
* Returns the commit id of the
* previous version
****************************************/
def findCommitOfPreviousVersion(gitMasterVersionTagPath = '', gitNewVersionTagPath = '') {
	def previousVersion = env.oldVersion

	if (previousVersion == env.version) {
		previousVersion = sh(returnStdout: true, script: "git for-each-ref --merged=$GIT_COMMIT --no-contains=$GIT_COMMIT --sort=creatordate --format '%(refname)' refs/tags/$gitMasterVersionTagPath refs/tags/$gitNewVersionTagPath | tail -n 1").trim()
		if (previousVersion != null) {
			previousVersion = previousVersion.substring(previousVersion.lastIndexOf("/") + 1)
		}
	}

	if (nullToEmpty(previousVersion) == "" || previousVersion == "null") {
		return [
	        commitId : sh(returnStdout: true, script: "git log --pretty=format:\"%H\" | tail -n 1").trim(),
	        previousVersion : "0.0.0"
	    ]
	}

	if (previousVersion != env.version) {
		def commitId = ""
		try {
			commitId = sh(returnStdout: true, script: "git rev-list -n 1 refs/tags/$gitMasterVersionTagPath/$previousVersion")
		} catch (err) {
			try {
				commitId = sh(returnStdout: true, script: "git rev-list -n 1 refs/tags/$gitNewVersionTagPath/$previousVersion")
			} catch (err2) {
				return null
		    }
	    }
		return [
	        commitId : commitId.trim(),
	        previousVersion : previousVersion
	    ]
	}
	return null
}

/*****************************************
* Returns the commit id of the
* last success build
****************************************/
def findCommitOfLastSuccessBuild() {
	def commitId = ""
	def buildNumber = ""
	def build = currentBuild
	def firstBuild = true

	while(build != null && commitId == "") {
		if (!firstBuild && build.result == 'SUCCESS') {
			build.changeSets.each { changeLog ->
			    if (changeLog.items != null) {
			    	changeLog.items.each { changeLogItem ->
			    		echo changeLogItem.getCommitId()
			    		if (changeLogItem.getCommitId() != null) {
			    			commitId = changeLogItem.getCommitId()
			    			buildNumber = build.number.toString()
			    		}
			    	}
			    }
			}
		}
		firstBuild = false
		build = build.previousBuild
	}
	return [
        commitId : commitId,
        buildNumber : buildNumber
    ]
}

/*****************************************
* Gathers the sonar results and place
* them in email body
****************************************/
def replaceSonarResultsPlaceholders(buildConfig, notificationBody = '', templateKey) {
	def configs = getConfigs()
	def sonarQualityGateResult = "<span style=\\\"color:black;\\\">💤 NOT AVAILABLE</span>"
	def sonarProjectKey = ""
	def forceNotAvailable = false
	try {
		if (buildConfig.sonarEnabled) {
			sonarProjectKey = sh(returnStdout: true, script: buildConfig.sonarProjectKey)
		}
	} catch (err) {
		forceNotAvailable = true
        echo err.getMessage()
    }

	if (buildConfig.sonarEnabled && nullToEmpty(sonarProjectKey) != "" && sh(returnStdout: true, script: "cat '${buildConfig.key}.result'").contains("PASSED")) {
		notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_URL_TEXT", "full analysis report")
		notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_URL", (nullToEmpty(configs.notifications.configs.sonarBaselineURL) + nullToEmpty(sonarProjectKey)).trim())

		def analysisId = waitForSonarAnalysis(sh(returnStdout: true, script: buildConfig.sonarTaskUrl))

		sh "curl --insecure -s -o ./qualityGateResult.json $configs.sonarConfigs.url/api/qualitygates/project_status?analysisId=$analysisId"
		def qualityGateResult = readJSON file: "./qualityGateResult.json"
		if (qualityGateResult == null || qualityGateResult.projectStatus == null || qualityGateResult.projectStatus.status != "OK") {
			sh "echo 'Sonar quality gate FAILED.'" // && exit 1"
		}
		else {
			echo "Sonar quality gate results are OK."
		}

		def sonarMetrics = getSonarProjectMetrics(	sonarProjectKey,
				        							"new_violations,new_blocker_violations,new_critical_violations,new_technical_debt,new_code_smells,new_coverage,new_duplicated_lines_density,violations,blocker_violations,critical_violations,sqale_index,code_smells,coverage,tests,duplicated_lines_density,duplicated_blocks")
		//Sonar mettrics
		if (sonarMetrics != null) {
			sonarMetrics.each { sonarMetric ->
				notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_" + sonarMetric.metricKey.toUpperCase() + "_SUFFIX", sonarMetric.value)
				if (sonarMetric.metricKey == "QUALITY_GATE") {
					sonarQualityGateResult = sonarMetric.value
				}
			}
		}
		
		def qualityCheckTemplateSpecs = findEmailRowTemplate(notificationBody, "PLACEHOLDER_QUALITY_CHECK")
		if (qualityCheckTemplateSpecs != null) {
			if (templateKey == "slack" || templateKey == "jira") {
				sonarQualityGateResult = sonarQualityGateResult.replaceAll("<.*?>", "")
			}
			def qualityCheckBuilder = qualityCheckTemplateSpecs.rowTemplate
												.replaceAll("PLACEHOLDER_QUALITY_CHECK_URL", (nullToEmpty(configs.notifications.configs.sonarBaselineURL) + nullToEmpty(sonarProjectKey)).trim())
												.replaceAll("PLACEHOLDER_QUALITY_CHECK_NAME", "Sonar Analysis")
												.replaceAll("PLACEHOLDER_QUALITY_CHECK_RESULT", sonarQualityGateResult)
			def notificationBodyAux = ""<<""
			notificationBodyAux <<= notificationBody.substring(0, notificationBody.indexOf("PLACEHOLDER_QUALITY_CHECK_START"))
			notificationBodyAux <<= qualityCheckBuilder.toString() + "PLACEHOLDER_QUALITY_CHECK_START" + qualityCheckTemplateSpecs.rowTemplate + "PLACEHOLDER_QUALITY_CHECK_END"
			notificationBodyAux <<= notificationBody.substring(notificationBody.indexOf("PLACEHOLDER_QUALITY_CHECK_END") + "PLACEHOLDER_QUALITY_CHECK_END".length())
			
			notificationBody = notificationBodyAux.toString()
		}
	}
	else {
		if (buildConfig.sonarEnabled) {
			def qualityCheckTemplateSpecs = findEmailRowTemplate(notificationBody, "PLACEHOLDER_QUALITY_CHECK")
			if (qualityCheckTemplateSpecs != null) {
				if (templateKey == "slack" || templateKey == "jira") {
					sonarQualityGateResult = sonarQualityGateResult.replaceAll("<.*?>", "")
				}
				def qualityCheckBuilder = qualityCheckTemplateSpecs.rowTemplate
						.replaceAll("PLACEHOLDER_QUALITY_CHECK_URL", nullToEmpty(configs.notifications.configs.sonarBaselineURL))
						.replaceAll("PLACEHOLDER_QUALITY_CHECK_NAME", "Sonar Analysis")
						.replaceAll("PLACEHOLDER_QUALITY_CHECK_RESULT", sonarQualityGateResult)
				def notificationBodyAux = ""<<""
				notificationBodyAux <<= notificationBody.substring(0, notificationBody.indexOf("PLACEHOLDER_QUALITY_CHECK_START"))
				notificationBodyAux <<= qualityCheckBuilder.toString() + "PLACEHOLDER_QUALITY_CHECK_START" + qualityCheckTemplateSpecs.rowTemplate + "PLACEHOLDER_QUALITY_CHECK_END"
				notificationBodyAux <<= notificationBody.substring(notificationBody.indexOf("PLACEHOLDER_QUALITY_CHECK_END") + "PLACEHOLDER_QUALITY_CHECK_END".length())
				notificationBody = notificationBodyAux.toString()
			}
		}
		
		notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_URL_TEXT", "")
		notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_URL", nullToEmpty(configs.notifications.configs.sonarBaselineURL))
		if (!buildConfig.sonarEnabled) {
			notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_QUALITY_GATE_SUFFIX", "<span style=\\\"color:black;\\\">💤 NOT APPLICABLE</span>")
		}
		else if (forceNotAvailable) {
			notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_QUALITY_GATE_SUFFIX", "<span style=\\\"color:black;\\\">💤 NOT AVAILABLE</span>")
		}
		else {
			notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_QUALITY_GATE_SUFFIX", "<span style=\\\"color:black;\\\">💤 SKIPPED</span>")
		}
	}
	notificationBody = notificationBody.replaceAll(/PLACEHOLDER_SONAR_(.*?)_SUFFIX/, "-")

	return notificationBody
}


/*****************************************
* Get sonar project metricks
****************************************/
def getSonarProjectMetrics(projectKey = '', metricKeys = '') {
	def output = []
	def configs = getConfigs()
			
	sh "curl --insecure -s -o ./projectMetrics.json $configs.sonarConfigs.url/api/measures/component?metricKeys=$metricKeys\\&component=$projectKey"
	def projectMetrics = readJSON file: "./projectMetrics.json"
	echo projectMetrics.toString()
	if (projectMetrics != null && projectMetrics.component != null && projectMetrics.component.measures != null) {
		java.text.DecimalFormat df = new java.text.DecimalFormat("#.##")
		projectMetrics.component.measures.each { measure ->
			def value = "-"
			if (measure.value != null) {
				output << [metricKey: measure.metric, value: measure.value]
			}
			else if(measure.periods != null) {
				double totalValue = 0
				measure.periods.each { period ->
					if (period.value.isNumber()) {
				    	totalValue += (period.value as Double)
				    }
				}
				output << [metricKey: measure.metric, value: df.format(totalValue)]
			}
		}
	}

	def qualityGateResult = readJSON file: "./qualityGateResult.json"
	if (qualityGateResult != null) {
		echo qualityGateResult.toString()
	}

	if (qualityGateResult == null || qualityGateResult.projectStatus == null || qualityGateResult.projectStatus.status != "OK") {
		output << [metricKey: "QUALITY_GATE", value: "<span style='color:black;'>❌ FAILED</span>"]
	}
	else {
		output << [metricKey: "QUALITY_GATE", value: "<span style='color:black;'>✔ PASSED</span>"]
	}

	return output
}

/*****************************************
* Executes the pipeline house keeping
****************************************/
def execHouseKeeping() {
	sh "docker ps --filter status=dead --filter status=exited -aq | xargs docker rm -v | true"
	sh "docker images --no-trunc | grep '<none>' | awk '{ print \$3 }' | xargs -r docker rmi | true"
}

/*****************************************
* Identifies if a new version reset 
* should generated
****************************************/
def isToUpdateVersion() {
	def configs = getConfigs()
	return 	configs.versionConfigs != null && configs.versionConfigs.autoIncrement
}

/*****************************************
* Make version for current build
****************************************/
def makeOldVersion(gitMasterVersionTagPath = '', gitNewVersionTagPath = '') {
	def version = sh(returnStdout: true, script: "git for-each-ref --merged=$GIT_COMMIT --sort=creatordate --format '%(refname)' refs/tags/$gitMasterVersionTagPath refs/tags/$gitNewVersionTagPath | tail -n 1").trim()
	if (version != null) {
		return version.substring(version.lastIndexOf("/") + 1)
	}
	return null
}

/*****************************************
* Make version for current build
****************************************/
def makeVersion(masterVersionConfigs, newVersionConfigs) {
	def masterVersion = makeMasterVersion(masterVersionConfigs, newVersionConfigs)
		
	if (!masterVersion.incremented) {
		return env.oldVersion
	}
	else if (newVersionConfigs.mode == "master") {
		return masterVersion.version
	}
	else if (newVersionConfigs.mode == "beta" || newVersionConfigs.mode == "release-candidate") {
		def newVersion = makeNewLowerVersion(masterVersion.version, newVersionConfigs)
		if (!newVersion.incremented) {
			return env.oldVersion
		}
		else  {
			return newVersion.version
		}				
	}
	else {
		error("Unsupported new version mode.")
	}
}

/*****************************************
* Make lower version (beta or rc) for current build
****************************************/
def makeNewLowerVersion(masterVersion, newVersionConfigs) {
	def versionSeparator = newVersionConfigs.mode == "beta" ? "-BETA-" : "-RC-"
	def version = sh(returnStdout: true, script: "git for-each-ref --merged=$GIT_COMMIT --sort=creatordate --format '%(refname)' refs/tags/$newVersionConfigs.gitTagPath | grep $masterVersion$versionSeparator | tail -n 1").trim()
	if (nullToEmpty(version) != "") {
		version = version.substring(version.lastIndexOf("/") + 1)
		env.previousVersionCommit = sh(returnStdout: true, script: "git rev-list -n 1 refs/tags/$newVersionConfigs.gitTagPath/$version").trim()
		if (env.previousVersionCommit == "$GIT_COMMIT") {
			return [
		        version : version,
		        incremented : false
		    ]
		}
		return [
	        version : masterVersion + versionSeparator + (version.substring(version.lastIndexOf(versionSeparator) + versionSeparator.length()).toInteger() + 1).toString(),
	        incremented : true
	    ]
	}
	return [
        version : masterVersion + versionSeparator + "1",
        incremented : true
    ]
}
	
/*****************************************
* Make master version for current build
****************************************/
def makeMasterVersion(masterVersionConfigs, newVersionConfigs) {
	def version = sh(returnStdout: true, script: "git for-each-ref --merged=$GIT_COMMIT --sort=creatordate --format '%(refname)' refs/tags/$masterVersionConfigs.gitTagPath | tail -n 1").trim()
	if (nullToEmpty(version) != "") {
		version = version.substring(version.lastIndexOf("/") + 1)
		env.previousVersionCommit = sh(returnStdout: true, script: "git rev-list -n 1 refs/tags/$masterVersionConfigs.gitTagPath/$version").trim()
		if (env.previousVersionCommit == "$GIT_COMMIT") {
			return [
		        version : version,
		        incremented : false
		    ]
		}
		version = sh(returnStdout: true, script: "git for-each-ref --merged=$GIT_COMMIT --sort=creatordate --format '%(refname)' refs/tags/$masterVersionConfigs.gitTagPath | grep -v - | tail -n 1").trim()
		version = version.substring(version.lastIndexOf("/") + 1)
		
		def versionDecomposed = version.split("\\.")
		def majorVersion = versionDecomposed[0]
		def minorVersion = versionDecomposed[1]
		def incrementalVersion = versionDecomposed[2]
		def qualifier = ""
				
		if (masterVersionConfigs.autoIncrementalMode == "major") {
			majorVersion = (majorVersion.toInteger() + 1).toString()
			minorVersion = masterVersionConfigs.initMinorVersion
			incrementalVersion = masterVersionConfigs.initPatchVersion
		}
		else if (masterVersionConfigs.autoIncrementalMode == "patch") {
			incrementalVersion = (incrementalVersion.toInteger() + 1).toString()
		}
		else if (masterVersionConfigs.autoIncrementalMode == "numericQualifier") {
			def lastQualifierNumber = sh(returnStdout: true, script: "git for-each-ref --sort=creatordate --format '%(refname)' refs/tags/$masterVersionConfigs.gitTagPath/$version-* | tail -n 1").replaceAll(/.*-/, "").trim()
			echo "$lastQualifierNumber"
			if (nullToEmpty(lastQualifierNumber) == "") {
				qualifier = "-1"
			}
			else {
				qualifier = "-" + (lastQualifierNumber.toInteger() + 1).toString()
			}
		}
		else {
			minorVersion = (minorVersion.toInteger() + 1).toString()
			incrementalVersion = masterVersionConfigs.initPatchVersion
		}				
		return [
	        version : majorVersion + "." + minorVersion + "." + incrementalVersion + qualifier,
	        incremented : true
	    ] 
	}
	return [
        version : masterVersionConfigs.firstVersion,
        incremented : true
    ] 
}

/*****************************************
* Identifies if a new version reset 
* should generated
****************************************/
def hasFailedBuilds() {
	if (env.hasFailedBuilds != null) {
		return (env.hasFailedBuilds == "true") 
	}
	
	def buildConfigs = getConfigs().buildConfigs
	def hasFailedBuilds = false
	buildConfigs.each{ buildConfig ->
		if (buildConfig.enabled) {
			def buildResult = sh(returnStdout: true, script: "grep -iL 'PASSED' ./${buildConfig.key}.result || true").trim()
			if (buildResult != "") {
				hasFailedBuilds = true
			}
			if (buildConfig.qualityChecks != null && buildConfig.qualityChecks instanceof net.sf.json.JSONArray) {
				buildConfig.qualityChecks.each{ qualityCheck ->
					if (qualityCheck.blocksPublish == true) {
						buildResult = sh(returnStdout: true, script: "grep -iL 'PASSED' ./${qualityCheck.resultFile} || true").trim()
						if (buildResult != "") {
							hasFailedBuilds = true
						}
					}
				}
			}
		}
	}
	env.hasFailedBuilds = hasFailedBuilds 
	return hasFailedBuilds
}

/*****************************************
* To enable load in other pipelines
****************************************/
return this;