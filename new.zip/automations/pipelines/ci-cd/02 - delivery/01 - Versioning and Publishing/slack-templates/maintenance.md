There was a problem in the delivery pipeline of `PLACEHOLDER_GIT_REPO`.


*Source details:*
🔹 Git branch: PLACEHOLDER_GIT_BRANCH
🔹 Git commit: PLACEHOLDER_GIT_COMMIT


*Execution details:*
🔹 Result: PLACEHOLDER_EXECUTION_RESULT
🔹 Duration: PLACEHOLDER_EXECUTION_DURATION
🔹 <PLACEHOLDER_EXECUTION_URL|Automation log>