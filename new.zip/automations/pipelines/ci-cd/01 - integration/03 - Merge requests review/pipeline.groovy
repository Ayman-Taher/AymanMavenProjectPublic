/*****************************************
* Runs the pipeline
****************************************/
def start() {
	withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'docker-readonly', usernameVariable: 'DOCKER_USERNAME', passwordVariable: 'DOCKER_PASSWORD']]) {
		sh 'docker login -u ' + "$DOCKER_USERNAME" + ' -p ' + "$DOCKER_PASSWORD" + ' cicd-tooling-ee.stc.com.sa'
	}

	stage('Prepare') {
		env.GIT_PROTOCOL = "https"
		sh "git clean -fd"
		try {
			sh '[ ! -d "automations/pipelines" ] && ln -s "$(pwd)" automations/pipelines'
		} catch (err) {
	    }
		unapproveMergeRequest()
	}
	
	def configs = getConfigs()
	stage('Check Merge Request Source and Target') {
		env.FAILURE_REASONS = "[]"

		def valid = false
		def acceptedPatterns = configs.mergeRequestValidations.sourceTargetPatterns.allowedPatterns.trim().split(' ')
		acceptedPatterns.each { acceptedPattern ->
			def acceptedSourcePattern = acceptedPattern.trim().split(':')[0]
			def acceptedTargetPattern = acceptedPattern.trim().split(':')[1]

			if ("$CHANGE_BRANCH" ==~ "$acceptedSourcePattern" && "$CHANGE_TARGET" ==~ "$acceptedTargetPattern") {
				valid = true
			}
	    }
		if (!valid) {
			logFailure("Merge requests from <b>'$CHANGE_BRANCH'</b> to <b>'$CHANGE_TARGET'</b> are <b>not allowed</b>", configs.mergeRequestValidations.sourceTargetPatterns.blocksMerge)
		}
	}
	stage('Check Remove Source Branch Flag') {
		loadAdditionalChangeEnv()
		
		if (nullToEmpty(env.CHANGE_REMOVE_SOURCE_BRANCH) != "true") {
			def valid = false
			def removeSourceBranchExclusions = configs.mergeRequestValidations.removeSourceBranch.exclusions.trim().split(' ')
			removeSourceBranchExclusions.each { removeSourceBranchExclusion ->
				if ("$CHANGE_BRANCH" ==~ "$removeSourceBranchExclusion") {
					valid = true
				}
			}
			if (!valid) {
				logFailure("The option to <b>remove source branch</b> should be enabled", configs.mergeRequestValidations.removeSourceBranch.blocksMerge)
			}
		}
	}
	stage('Reset Sonar Analysis') {
		resetSonarAnalyses()
	}
	stage('Check Build & Sonar') {
		loadAdditionalChangeEnv()
		executeBuilds("Check Build & Sonar for ")
		def buildConfigs = configs.buildConfigs

		buildConfigs.each{ buildConfig ->
			if (buildConfig.enabled) {
				def buildResult = sh(returnStdout: true, script: "grep -iL 'PASSED' ./${buildConfig.key}.result || true").trim()
				if (buildResult != "") {
					logFailure("<b>Build failed</b> for <b>$buildConfig.name</b> (Additional detail in logs at <a href='${BUILD_URL}artifact/${buildConfig.key}.log'>link</a>)", configs.mergeRequestValidations.buildFailedBlocksMerge)
				}

				if (buildConfig.sonarEnabled) {
					def resetSonarResult = sh(returnStdout: true, script: "grep -iL 'PASSED' ./sonar-reset-${buildConfig.key}.result || true").trim()
					if (resetSonarResult != "") {
						logFailure("There was a problem preparing a valid <b>sonar report</b> of <b>$buildConfig.name</b> (Additional detail in logs at <a href='${BUILD_URL}artifact/sonar-reset-${buildConfig.key}.log'>link</a>)", configs.mergeRequestValidations.errorBuildingSonarBlocksMerge)
					}
					else {
						def ceTaskUrl
						try {
							ceTaskUrl = sh(returnStdout: true, script: buildConfig.sonarTaskUrl)
						}
						catch (err) {
							ceTaskUrl = null
					    }
						if (ceTaskUrl != null) {
							waitForSonarAnalysis(ceTaskUrl)
							def analysisId = waitForSonarAnalysis(ceTaskUrl)
							sh "curl --insecure -s -o ./qualityGateResult.json $configs.sonarConfigs.url/api/qualitygates/project_status?analysisId=$analysisId"
							def qualityGateResult = readJSON file: "./qualityGateResult.json"
							if (qualityGateResult == null || qualityGateResult.projectStatus == null || qualityGateResult.projectStatus.status != "OK") {
								def projectKey = "${buildConfig.key}-" + sh(returnStdout: true, script: "echo `$configs.sonarConfigs.projectKey`").trim()
								logFailure("Sonar <b>quality gate failed</b> for <b>$buildConfig.name</b>. Additional detail in  <a href='$CHANGE_URL'>Merge Request</a> comments and <a href='$configs.notifications.configs.sonarBaselineURL$projectKey'>Sonar Dashboard</a>", configs.mergeRequestValidations.sonarQualityGateBlocksMerge)
							}
						}
						else {
							echo "ERROR: Invalid config for sonarTaskUrl in $buildConfig.name or sonar report is not available"
							logFailure("There was an error checking <b>sonar quality gate</b> for <b>$buildConfig.name</b>. Additional detail in <a href='${BUILD_URL}/console'>automation log</a>", configs.mergeRequestValidations.sonarQualityGateBlocksMerge)
						}
					}
				}
				if (buildConfig.qualityChecks != null) {
					buildConfig.qualityChecks.each{ qualityCheck ->
						def qualityCheckResult = sh(returnStdout: true, script: "grep -iL 'PASSED' ./${qualityCheck.resultFile} || true").trim()
						if (qualityCheckResult != "") {
							def archivedFileURL = "${BUILD_URL}artifact/" + java.net.URLEncoder.encode(qualityCheck.fileToArchive, "UTF-8")
							logFailure("<b>${qualityCheck.name} failed</b> (Additional detail in <a href='${archivedFileURL}'>link</a>)", qualityCheck.blocksMerge)
						}
					}
				}
			}
		}
	}
	stage('Process Validation Failures') {
		def resultTemplates = [
    		gitlab: "",
    		bitbucket: ""
    	]    			
    	if (configs.notifications.gitlab != null && configs.notifications.gitlab.templatePath != null) {
    		resultTemplates.gitlab = readFile(configs.notifications.gitlab.templatePath)
    	}
    	if (configs.notifications.bitbucket != null && configs.notifications.bitbucket.templatePath != null) {
    		resultTemplates.bitbucket = readFile(configs.notifications.bitbucket.templatePath)
    	}
    	
    	def resultTemplatesAux = replaceResultsInTemplates(resultTemplates,configs)
    	
		if (nullToEmpty(configs.notifications.gitlab.filePath) != "") {
			writeFile   file: configs.notifications.gitlab.filePath, text: nullToEmpty(resultTemplatesAux.resultTemplates.gitlab)
		}
		if (nullToEmpty(configs.notifications.bitbucket.filePath) != "") {
			writeFile   file: configs.notifications.bitbucket.filePath, text: nullToEmpty(resultTemplatesAux.resultTemplates.bitbucket)
		}

		addCommentToMergeRequest(resultTemplatesAux.resultTemplates)
		
		if (resultTemplatesAux.hasBlockerFailures) {
			error("Merge request not accepted (â�Œ) due to <b>blocker failed validations</b>.")
		}
		else {
			approveMergeRequest()
			if (configs.continuousIntegrationEnabled.toString() == "true") {
				mergeMergeRequest()
			}
		}
	}
}

/*****************************************
* Runs in the end of a successull build
****************************************/
def postSuccess() {
	def configs = getConfigs()
	sendSuccessNotifications(configs)
	archiveLogsAndEmail()
}

/*****************************************
* Runs in the end of a failed build
****************************************/
def postFailure() {
	def configs = getConfigs()
	sendFailNotifications(configs)
	archiveLogsAndEmail()
}

/*****************************************
* Get pipeline configs
****************************************/
def getConfigs() {
	if (env.configs == null) {
		def configs = null
				
		def gitflowConfigFilePath = ""
		def configFilePath = "automations/configs/ci-cd/03 - integration - merge request review.json"
		def deprecatedConfigFilePath = "automations/configs/ci-cd/01 - integration/03 - Merge requests review/config.json"
		
		if ("$JOB_NAME".contains("/02 - Develop/")) {
			gitflowConfigFilePath = "automations/configs/ci-cd/03 - develop - integration - feature merge request review.json"
		}
		else if ("$JOB_NAME".contains("/03 - Release/")) {
			gitflowConfigFilePath = "automations/configs/ci-cd/09 - release - integration - bugfix merge request review.json"
		}
		else if ("$JOB_NAME".contains("/04 - Master/")) {
			gitflowConfigFilePath = "automations/configs/ci-cd/15 - master - integration - hotfix merge request review.json"
		}
		
		if (gitflowConfigFilePath == "") {
			try {
				configs = readJSON file: configFilePath
			} catch (err) {
				echo "Pipeline configuration not found. Attempting deprecated location..."
		    }
			if (configs == null) {
				try {
					configs = readJSON file: deprecatedConfigFilePath 
				} catch (err) {
					error("Pipeline configuration not found or invalid. Please create a valid configuration in '$configFilePath'")
			    }
			}
		}
		else {
			try {
				configs = readJSON file: gitflowConfigFilePath 
			} catch (err) {
				error("Pipeline configuration not found or invalid. Please create a valid configuration in '$gitflowConfigFilePath'")
		    }
		}

		def defaultConfigs = readJSON file: "automations/pipelines/ci-cd/01 - integration/03 - Merge requests review/config-defaults.json"

		def gitflowDefaultConfigs = null
		if ("$JOB_NAME".contains("/02 - Develop/")) {
			gitflowDefaultConfigs = readJSON file: "automations/pipelines/ci-cd/01 - integration/03 - Merge requests review/config-defaults-develop.json"
		}
		else if ("$JOB_NAME".contains("/03 - Release/")) {
			gitflowDefaultConfigs = readJSON file: "automations/pipelines/ci-cd/01 - integration/03 - Merge requests review/config-defaults-release.json"
		}
		else if ("$JOB_NAME".contains("/04 - Master/")) {
			gitflowDefaultConfigs = readJSON file: "automations/pipelines/ci-cd/01 - integration/03 - Merge requests review/config-defaults-master.json"
		}
		if (gitflowDefaultConfigs != null) {
			defaultConfigs = loadDefaultConfigs(gitflowDefaultConfigs, defaultConfigs)
		}
			
		echo "DEFAULT CONFIGS: " + groovy.json.JsonOutput.toJson(defaultConfigs)
		echo "CONFIGS BEFORE: " + groovy.json.JsonOutput.toJson(configs)
		configs = loadDefaultConfigs(configs, defaultConfigs)
		echo "CONFIGS AFTER: " + groovy.json.JsonOutput.toJson(configs)
			
		env.configs = groovy.json.JsonOutput.toJson(configs)
		return configs
	}
	def configs = readJSON text: env.configs
	return configs
}

/*****************************************
* Load default configs if they are 
* not set in main configs
****************************************/
def loadDefaultConfigs(net.sf.json.JSONObject configs, net.sf.json.JSONObject defaultConfigs, logContext = '') {

	if (defaultConfigs != null) {
		defaultConfigs.keys().each{ key ->
			def configValue = configs[key]
			def defaultValue = defaultConfigs[key]
			
			if (configValue == null) {
				echo "Updating config value '$logContext$key' to default '$defaultValue'"
				configs[key] = defaultValue 
			}
			else if (defaultValue != null && defaultValue instanceof net.sf.json.JSONObject) {
				if (configValue instanceof net.sf.json.JSONObject) {
					configs[key] = loadDefaultConfigs(configValue, defaultValue, logContext + key + ".")
				}
				else if (configValue instanceof net.sf.json.JSONArray) {
					net.sf.json.JSONArray newConfigValue = new net.sf.json.JSONArray()
							
					configValue.each{ configValueItem ->
						if (configValueItem instanceof net.sf.json.JSONObject) {
							newConfigValue.add(loadDefaultConfigs(configValueItem, defaultValue, logContext + key + "[" + String.valueOf(newConfigValue.size()) + "]."))
						}
						else {
							newConfigValue.add(configValueItem)
						}
					}
					
					configs[key] = newConfigValue
				}
			}
		}
	}
	return configs
}

/*****************************************
* Sends the pipeline success email notification
****************************************/
def sendSuccessNotifications(net.sf.json.JSONObject configs) {
	def notificationtTemplates = [
  		email: "",
  		slack: "",
  		jira: ""
  	]
  			
  	if (configs.notifications.email != null && configs.notifications.email.success != null) {
  		notificationtTemplates.email = readFile(configs.notifications.email.success.templatePath)
  	}
  	if (configs.notifications.slack != null && configs.notifications.slack.success != null) {
  		notificationtTemplates.slack = readFile(configs.notifications.slack.success.templatePath)
  	}
  	if (configs.notifications.jira != null && configs.notifications.jira.success != null) {
  		notificationtTemplates.jira = readFile(configs.notifications.jira.success.templatePath)
  	}
			
	def gitURL = ""
	if (nullToEmpty(env.GIT_URL) != "") {
		gitURL = env.GIT_URL
	}
	else if (nullToEmpty(env.GIT_URL_2) != "") {
		gitURL = env.GIT_URL_2
	}
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_REPO", nullToEmpty(gitURL).substring(gitURL.lastIndexOf('/') + 1).replaceAll(".git", ""))
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_RESULT", "SUCCESS")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_DURATION", "${currentBuild.durationString.replace(' and counting', '')}")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_URL", "$BUILD_URL")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_MR_ID", "$CHANGE_ID")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_MR_URL", "$CHANGE_URL")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_MR_AUTHOR", "$CHANGE_AUTHOR_DISPLAY_NAME")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_MR_SOURCE", "$CHANGE_BRANCH")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_MR_TARGET", "$CHANGE_TARGET")
	notificationtTemplates = replaceResultsInTemplates(notificationtTemplates,configs).resultTemplates
	notificationtTemplates = replaceSonarAndQualityChecksInTemplates(notificationtTemplates, configs)
	notificationtTemplates = replaceReleaseNotesInTemplates(notificationtTemplates, configs)
	notificationtTemplates = replaceJIRAPlaceholders(notificationtTemplates, "success", configs)

	if (configs != null && configs.notifications != null ) {
		configs.notifications.keySet().each{ notificationKey ->
			if (notificationKey != "configs") {
				if (nullToEmpty(configs.notifications[notificationKey].filePath) != "" && nullToEmpty(notificationtTemplates[notificationKey]) != "") {
					writeFile   file: configs.notifications[notificationKey].filePath, text: nullToEmpty(notificationtTemplates[notificationKey])
				}
				
				if (notificationKey == "email" && configs.notifications.email.success != null) {
					try {
					    emailext 	subject: configs.notifications.email.success.subject,
					    			to: configs.notifications.email.success.mailingList,
					    			body: notificationtTemplates.email
					} catch (err) {
				        echo err.getMessage()
				    }
				}
				else if (notificationKey == "slack" && configs.notifications.slack.success != null) {
					try {
						slackSend	teamDomain: configs.notifications.slack.success.teamDomain,
									tokenCredentialId: configs.notifications.slack.success.tokenCredentialId,
									channel: configs.notifications.slack.success.channel,
									color: "good",
									message: notificationtTemplates.slack					
					} catch (err) {
				        echo err.getMessage()
				    }
				}
				else if (notificationKey == "jira" && configs.notifications.jira.success != null && env.jiraKeys != null) {
					def jiraKeysObj = readJSON text: env.jiraKeys
					jiraKeysObj.keySet().each{ jiraKey ->
						try {
							jiraAddComment  idOrKey: jiraKey,
											site: configs.jiraConfigs.jiraSite, 
											auditLog: false,
											input: [ body: notificationtTemplates.jira ]					
						} catch (err) {
					        echo err.getMessage()
					    }
					}
				}
			}
		}
	}
}

/*****************************************
* Sends the pipeline fail email notification
****************************************/
def sendFailNotifications(net.sf.json.JSONObject configs) {
	def notificationtTemplates = [
		email: "",
		slack: "",
		jira: ""
	]
			
	if (configs.notifications.email != null && configs.notifications.email.fail != null) {
		notificationtTemplates.email = readFile(configs.notifications.email.fail.templatePath)
	}
	if (configs.notifications.slack != null && configs.notifications.slack.fail != null) {
		notificationtTemplates.slack = readFile(configs.notifications.slack.fail.templatePath)
	}
	if (configs.notifications.jira != null && configs.notifications.jira.fail != null) {
		notificationtTemplates.jira = readFile(configs.notifications.jira.fail.templatePath)
	}

	def gitURL = ""
	if (nullToEmpty(env.GIT_URL) != "") {
		gitURL = env.GIT_URL
	}
	else if (nullToEmpty(env.GIT_URL_2) != "") {
		gitURL = env.GIT_URL_2
	}
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_REPO", nullToEmpty(gitURL).substring(gitURL.lastIndexOf('/') + 1).replaceAll(".git", ""))
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_RESULT", "FAILED")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_DURATION", "${currentBuild.durationString.replace(' and counting', '')}")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_URL", "$BUILD_URL")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_MR_ID", "$CHANGE_ID")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_MR_URL", "$CHANGE_URL")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_MR_AUTHOR", "$CHANGE_AUTHOR_DISPLAY_NAME")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_MR_SOURCE", "$CHANGE_BRANCH")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_MR_TARGET", "$CHANGE_TARGET")
	notificationtTemplates = replaceResultsInTemplates(notificationtTemplates,configs).resultTemplates
	notificationtTemplates = replaceSonarAndQualityChecksInTemplates(notificationtTemplates, configs)
	notificationtTemplates = replaceReleaseNotesInTemplates(notificationtTemplates, configs)
	notificationtTemplates = replaceJIRAPlaceholders(notificationtTemplates, "fail", configs)

	echo env.FAILURE_REASONS

	if (configs != null && configs.notifications != null ) {
		configs.notifications.keySet().each{ notificationKey ->
			if (notificationKey != "configs") {
				if (nullToEmpty(configs.notifications[notificationKey].filePath) != "" && nullToEmpty(notificationtTemplates[notificationKey]) != "") {
					writeFile   file: configs.notifications[notificationKey].filePath, text: nullToEmpty(notificationtTemplates[notificationKey])
				}
				
				if (notificationKey == "email" && configs.notifications.email.fail != null) {
					try {
					    emailext 	subject: configs.notifications.email.fail.subject,
					    			to: configs.notifications.email.fail.mailingList,
					    			body: notificationtTemplates.email
					} catch (err) {
				        echo err.getMessage()
				    }
				}
				else if (notificationKey == "slack" && configs.notifications.slack.fail != null) {
					try {
						slackSend	teamDomain: configs.notifications.slack.fail.teamDomain,
									tokenCredentialId: configs.notifications.slack.fail.tokenCredentialId,
									channel: configs.notifications.slack.fail.channel,
									color: "danger",
									message: notificationtTemplates.slack					
					} catch (err) {
				        echo err.getMessage()
				    }
				}
				else if (notificationKey == "jira" && configs.notifications.jira.fail != null && env.jiraKeys != null) {
					try {
						def jiraKeysObj = readJSON text: env.jiraKeys
						jiraKeysObj.keySet().each{ jiraKey ->
							jiraAddComment  idOrKey: jiraKey,
											site: configs.jiraConfigs.jiraSite, 
											auditLog: false,
											input: [ body: notificationtTemplates.jira ]					
						}
					} catch (err) {
				        echo err.getMessage()
				    }
				}
			}
		}
	}
}


/*****************************************
* Replace a placeholder by a value in a 
* map of templates
****************************************/
def replacePlaceholderInTemplates(java.util.LinkedHashMap templates, placeholder = '', value = '') {
	templates.keySet().each{ templateKey ->
		templates[templateKey] = templates[templateKey].replaceAll(placeholder, value)
	}
	return templates
}

/*****************************************
* Replace row placeholders in a 
* map of templates
****************************************/
def replaceRowsPlaceholdersInTemplates(templates, rowPlaceholder, rowsData, transformClosure) {
	templates.keySet().each{ templateKey ->
		def originalTemplate = templates[templateKey]
		def rowTemplateSpecs = findEmailRowTemplate(originalTemplate, rowPlaceholder)
		
		if (rowTemplateSpecs != null) {
			def contentBuilder = ""<< originalTemplate.substring(0, originalTemplate.indexOf(rowPlaceholder + "_START"))
			def rowContextAdded = false
					
			if (rowsData != null && (rowsData instanceof Collection || rowsData.getClass().isArray())) {
				rowsData.each { rowData ->
					def rowContent = transformClosure(rowTemplateSpecs.rowTemplate, rowData, templateKey)
					if (rowContent != null) {
						contentBuilder <<= rowContent
						rowContextAdded = true
					}
				}
			}
			
			if (!rowContextAdded) {
				contentBuilder <<= transformClosure(rowTemplateSpecs.rowTemplate, null, templateKey)
			}
			
			contentBuilder <<= originalTemplate.substring(originalTemplate.indexOf(rowPlaceholder + "_END") + (rowPlaceholder + "_END").length())
			templates[templateKey] = contentBuilder.toString()
		}
	}
	return templates
}

/*****************************************
* Replace Sonar and Quality Checks 
* in email body 
****************************************/
def replaceResultsInTemplates(java.util.LinkedHashMap resultTemplates, net.sf.json.JSONObject configs) {
	def hasBlockerFailures = false
	def failureReasons = null
	if (nullToEmpty(env.FAILURE_REASONS).trim() != "") {
		failureReasons = readJSON text: env.FAILURE_REASONS
	}
	resultTemplates = replacePlaceholderInTemplates(resultTemplates, "PLACEHOLDER_HEADER_TEXT", "Results from Merge Request review:")
	resultTemplates = replaceRowsPlaceholdersInTemplates(resultTemplates, "PLACEHOLDER_ROW", failureReasons, { rowTemplate, failureReason, templateKey ->
		if (failureReason == null) {
			return rowTemplate.replaceAll("PLACEHOLDER_ROW_TEXT", "ℹ No relevant issues found")
		}

		def icon = "⚠ "
		if (failureReason.blocker != false) {
			icon = "🚫 "
			hasBlockerFailures = true
		}
		
		if (templateKey.startsWith("bitbucket")) {
			if(configs.gitProvider == "bitbucket-cloud") {
				return rowTemplate.replaceAll("PLACEHOLDER_ROW_TEXT", icon + failureReason.msg.replaceAll("<b>|</b>", "**"))
			}
			else {
				return rowTemplate.replaceAll("PLACEHOLDER_ROW_TEXT", icon + failureReason.msg.replaceAll("<b>|</b>", "**").replaceAll(">.*?</a>", ")").replaceAll("<a href=", "[link](").replaceAll(">", ")"))
			}
		}
		if (templateKey == "jira") {
			return rowTemplate.replaceAll("PLACEHOLDER_ROW_TEXT", icon + failureReason.msg.replaceAll("<b>|</b>", "*").replaceAll("<.*?>", ""))
		}
		if (templateKey == "slack") {
			return rowTemplate.replaceAll("PLACEHOLDER_ROW_TEXT", icon + failureReason.msg.replaceAll("<b>|</b>", "*").replaceAll("<a href='", "<").replaceAll("<a href='", "<").replaceAll(">", "|").replaceAll("</a\\|", ">"))
		}
		return rowTemplate.replaceAll("PLACEHOLDER_ROW_TEXT", icon + failureReason.msg)
	})
			
	if (configs.continuousIntegrationEnabled.toString() != "true" && hasBlockerFailures) {
		resultTemplates.keySet().each{ templateKey ->
			if (templateKey.startsWith("bitbucket")) {
				resultTemplates[templateKey] = resultTemplates[templateKey].replaceAll("PLACEHOLDER_FOOTER_TEXT", "Merge request **not accepted** ❌ due to **blocker failed validations** and **continuous integration is disabled**.")
			}
			else if (templateKey == "slack" || templateKey == "jira") {
				resultTemplates[templateKey] = resultTemplates[templateKey].replaceAll("PLACEHOLDER_FOOTER_TEXT", "Merge request *not accepted* ❌ due to *blocker failed validations* and *continuous integration is disabled*.")
			}
			else {
				resultTemplates[templateKey] = resultTemplates[templateKey].replaceAll("PLACEHOLDER_FOOTER_TEXT", "Merge request <b>not accepted</b> ❌ due to <b>blocker failed validations</b> and <b>continuous integration is disabled</b>.")
			}
		}
	}
	else if (hasBlockerFailures) {
		resultTemplates.keySet().each{ templateKey ->
			if (templateKey.startsWith("bitbucket")) {
				resultTemplates[templateKey] = resultTemplates[templateKey].replaceAll("PLACEHOLDER_FOOTER_TEXT", "Merge request **not accepted** ❌ due to **blocker failed validations**.")
			}
			else if (templateKey == "slack" || templateKey == "jira") {
				resultTemplates[templateKey] = resultTemplates[templateKey].replaceAll("PLACEHOLDER_FOOTER_TEXT", "Merge request *not accepted* ❌ due to *blocker failed validations*.")
			}
			else {
				resultTemplates[templateKey] = resultTemplates[templateKey].replaceAll("PLACEHOLDER_FOOTER_TEXT", "Merge request <b>not accepted</b> ❌ due to <b>blocker failed validations</b>.")
			}
		}
	}
	else if (configs.continuousIntegrationEnabled.toString() != "true") {
		resultTemplates.keySet().each{ templateKey ->
			if (templateKey.startsWith("bitbucket")) {
				resultTemplates[templateKey] = resultTemplates[templateKey].replaceAll("PLACEHOLDER_FOOTER_TEXT", "Merge request **accepted** ✔ but not merged because **continuous integration is disabled**.")
			}
			else if (templateKey == "slack" || templateKey == "jira") {
				resultTemplates[templateKey] = resultTemplates[templateKey].replaceAll("PLACEHOLDER_FOOTER_TEXT", "Merge request *accepted* ✔ but not merged because *continuous integration is disabled*.")
			}
			else {
				resultTemplates[templateKey] = resultTemplates[templateKey].replaceAll("PLACEHOLDER_FOOTER_TEXT", "Merge request <b>accepted</b> ✔ but not merged because <b>continuous integration is disabled</b>.")
			}
		}
	}
	else {
		resultTemplates.keySet().each{ templateKey ->
			if (templateKey.startsWith("bitbucket")) {
				resultTemplates[templateKey] = resultTemplates[templateKey].replaceAll("PLACEHOLDER_FOOTER_TEXT", "Merge request **accepted** ✔ and **merged**.")
			}
			else if (templateKey == "slack" || templateKey == "jira") {
				resultTemplates[templateKey] = resultTemplates[templateKey].replaceAll("PLACEHOLDER_FOOTER_TEXT", "Merge request *accepted* ✔ and *merged*.")
			}
			else {
				resultTemplates[templateKey] = resultTemplates[templateKey].replaceAll("PLACEHOLDER_FOOTER_TEXT", "Merge request <b>accepted</b> ✔ and <b>merged</b>.")
			}
		}
	}
	return [
        resultTemplates: resultTemplates,
        hasBlockerFailures: hasBlockerFailures
    ]
}
	
/*****************************************
* Replace Sonar and Quality Checks 
* in email body 
****************************************/
def replaceReleaseNotesInTemplates(java.util.LinkedHashMap templates, net.sf.json.JSONObject configs) {
	//Find commits not yet in $configs.sonarConfigs.resetSonar.resetBranch
	sh "rm -rf ./newCommits.json && touch ./newCommits.json"
	sh "git log --no-merges --pretty=format:\"%h #@# %cn #@# %ci #@# %s ##@@##\" ${configs.sonarConfigs.resetSonar.resetBranch}..HEAD >> ./newCommits.json || true"
	def gitCommits = readFile("newCommits.json")
	return replaceRowsPlaceholdersInTemplates(templates, "PLACEHOLDER_NEW_COMMITS_ROW", gitCommits.split("##@@##"), { rowTemplate, gitCommit, templateKey ->
		if (nullToEmpty(gitCommit).trim() != "") {
			def gitCommitDetails = gitCommit.split(" #@# ")
			if (gitCommitDetails.size() > 3) {
				def commitMessage = java.util.regex.Matcher.quoteReplacement(gitCommitDetails[3])
				if (templateKey == "email") {
					env.commitMessages = nullToEmpty(env.commitMessages) + "##@@##" + java.util.regex.Matcher.quoteReplacement(gitCommitDetails[0]) + " #@# " + commitMessage
				}
				return rowTemplate.replaceAll('PLACEHOLDER_NEW_COMMITS_ROW_SUMMARY', commitMessage)
								  .replaceAll('PLACEHOLDER_NEW_COMMITS_ROW_AUTHOR', java.util.regex.Matcher.quoteReplacement(gitCommitDetails[1]))
			}
		}
		return null
	})
}

/*****************************************
* Gathers the JIRA keys and place
* them in email body
****************************************/
def replaceJIRAPlaceholders(java.util.LinkedHashMap templates, result, net.sf.json.JSONObject configs) {
	def jiraKeys = [:]
	def transitionsConfigsPerInitStatus = configs.jiraConfigs[result.toLowerCase()] != null ? configs.jiraConfigs[result.toLowerCase()].transitionsConfigsPerInitStatus : null 

	//Condition to try to find jiras
	if (configs.jiraConfigs != null && configs.jiraConfigs.lookForJiraKeysConfig != null && configs.jiraConfigs.jiraKeyRegex != null) {
		//Condition to try to find jiras in branch name
		if (configs.jiraConfigs.lookForJiraKeysConfig.lookInBranchName != null && configs.jiraConfigs.lookForJiraKeysConfig.lookInBranchName.enabled == true) {
			//Condition to filter branches
			if (nullToEmpty(configs.jiraConfigs.lookForJiraKeysConfig.lookInBranchName.filterRegex) == "" || "$GIT_BRANCH".find(configs.jiraConfigs.lookForJiraKeysConfig.lookInBranchName.filterRegex) != null) {
				"$CHANGE_BRANCH".findAll(configs.jiraConfigs.jiraKeyRegex).each{ jiraKey ->
					jiraKeys = putJiraInMapIfValid(jiraKeys, jiraKey, "source branch name", transitionsConfigsPerInitStatus, configs)
				}
			}
		}
		//Condition to try to find jiras in commit messages
		if (configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages != null && configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages.enabled == true) {
			//Condition to filter commit messages
			if (nullToEmpty(configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages.filterRegex) == "" || "$GIT_BRANCH".find(configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages.filterRegex) != null) {
				nullToEmpty(env.commitMessages).split("##@@##").each{ commitDetails ->
					def commitDetailsAux = commitDetails.split(" #@# ")
					if (commitDetailsAux.size() == 2) {
						def commitHash = commitDetailsAux[0]
						def commitMessage = commitDetailsAux[1]
						commitMessage.findAll(configs.jiraConfigs.jiraKeyRegex).each{ jiraKey ->
							jiraKeys = putJiraInMapIfValid(jiraKeys, jiraKey, "commit message of " + commitHash, transitionsConfigsPerInitStatus, configs)
						}
					}
				}
			}
		}
	}
	echo "JIRA Details: " + groovy.json.JsonOutput.toJson(jiraKeys)
	env.jiraKeys = groovy.json.JsonOutput.toJson(jiraKeys)
	return replaceRowsPlaceholdersInTemplates(templates, "PLACEHOLDER_JIRA_LIST", jiraKeys.keySet(), { rowTemplate, jiraKey ->
		if (jiraKey == null) {
			return ""
		}
		def jiraData = jiraKeys[jiraKey]
		def jiraURL = ""
		def jiraFoundIn = ""
		def transitionsTitle = "No transitions performed"
		def transitionsError = "No error performing transitions"
		def jiraTransitions = []
				
		if (jiraData != null) {
			jiraURL = jiraData.url
			jiraFoundIn = jiraData.foundIn
			if (jiraData.transitionApplied != null) {
				transitionsTitle = (jiraData.transitionApplied.error ? "❌ " : "✔ ") + jiraData.transitionApplied.name
				transitionsError = jiraData.transitionApplied.errorMessage
				jiraTransitions = jiraData.transitionApplied.transitions
			}
		}
		
		rowTemplate = rowTemplate.replaceAll('PLACEHOLDER_JIRA_KEY', jiraKey)
	  			   	 			 .replaceAll('PLACEHOLDER_JIRA_URL', jiraURL)
	  			   	 			 .replaceAll('PLACEHOLDER_JIRA_FOUND_IN', jiraFoundIn)
	  			   	 			 .replaceAll('PLACEHOLDER_JIRA_TRANSITIONS_TITLE', transitionsTitle)
	  			   	 			 .replaceAll('PLACEHOLDER_JIRA_TRANSITIONS_ERROR', transitionsError)

  		def foundError = false
		return replaceRowsPlaceholdersInTemplates([ template: rowTemplate ], "PLACEHOLDER_JIRA_TRANSITIONS", jiraTransitions, { rowSubTemplate, transitionName ->
			if (transitionName != null) {
				foundError = foundError || transitionName.equals(jiraData.transitionApplied.errorIn)
				return rowSubTemplate.replaceAll('PLACEHOLDER_JIRA_TRANSITION_NAME', (foundError ? "❌ " : "✔ ") + transitionName)
			}
			return ""
		}).template
	});
}


/*****************************************
* Returns the commit id of the
* previous version
****************************************/
def putJiraInMapIfValid(jiraKeys, jiraKey, foundIn, transitionsConfigsPerInitStatus, net.sf.json.JSONObject configs) {
	if (jiraKeys[jiraKey] == null) {
		try {
			def jiraIssue = jiraGetIssue idOrKey: jiraKey,
							site: configs.jiraConfigs.jiraSite,
							failOnError: false
			if (jiraIssue != null && jiraIssue.data != null) {
				jiraKeys.put(jiraKey, [
				    foundIn: foundIn,
                    url: nullToEmpty(configs.jiraConfigs.jiraSite) + "/browse/" + jiraKey,
                    transitionApplied: jiraTryToApplyTransitions(jiraKey, jiraIssue.data, transitionsConfigsPerInitStatus, configs) 
                ])
			}
		} catch (err) {
	        echo err.getMessage()
	    }
	}
	return jiraKeys
}


/*****************************************
* Returns the commit id of the
* previous version
****************************************/
def jiraTryToApplyTransitions(jiraKey, jiraData, transitionsConfigsPerInitStatus, net.sf.json.JSONObject configs) {
	def output = null
	def jiraIssueStatus = jiraData.fields.status.id 

	if (jiraIssueStatus != null && transitionsConfigsPerInitStatus != null && transitionsConfigsPerInitStatus[jiraIssueStatus] != null) {
		output = [
            name: transitionsConfigsPerInitStatus[jiraIssueStatus].name,
            error: false,
            errorIn: "",
            errorMessage: "No error performing transitions",
            transitions: transitionsConfigsPerInitStatus[jiraIssueStatus].transitions.collect{ it -> it.name }
        ]
		transitionsConfigsPerInitStatus[jiraIssueStatus].transitions.each{ transitionData ->
			try {
				if (!output.error) {
					echo "Trying to apply transition: " + groovy.json.JsonOutput.toJson(transitionData)
					jiraTransitionIssue idOrKey: jiraKey,
										site: configs.jiraConfigs.jiraSite,
										auditLog: true,
										failOnError: true,
										input: transitionData.data
				}
			} catch (err) {
				output.error = true
				output.errorIn = transitionData.name
				output.errorMessage = err.getMessage() 
			}
		}
	}
	
	return output
}


/*****************************************
* Replace Sonar and Quality Checks 
* in email body 
****************************************/
def replaceSonarAndQualityChecksInTemplates(java.util.LinkedHashMap templates, net.sf.json.JSONObject configs) {
	return replaceRowsPlaceholdersInTemplates(templates, "PLACEHOLDER_QUALITY_CHECK", configs.buildConfigs, { rowTemplate, buildConfig ->
		def rowTemplateBuilder = ""<<""
		if (buildConfig.enabled) {
			rowTemplateBuilder <<= rowTemplate.replaceAll("PLACEHOLDER_QUALITY_CHECK_URL", "${BUILD_URL}artifact/${buildConfig.key}.log")
							  				  .replaceAll("PLACEHOLDER_QUALITY_CHECK_NAME", "${buildConfig.name}")
							  				  .replaceAll("PLACEHOLDER_QUALITY_CHECK_RESULT", sh(returnStdout: true, script: "cat '${buildConfig.key}.result'").trim().replaceAll("<.*?>", ""))
			if (buildConfig.sonarEnabled) {
				def ceTaskUrl
				try {
					ceTaskUrl = sh(returnStdout: true, script: buildConfig.sonarTaskUrl)
				}
				catch (err) {
					ceTaskUrl = null
			    }
				if (ceTaskUrl != null) {
					def analysisId = waitForSonarAnalysis(ceTaskUrl)
					sh "curl --insecure -s -o ./qualityGateResult.json $configs.sonarConfigs.url/api/qualitygates/project_status?analysisId=$analysisId"
					def qualityGateResult = readJSON file: "./qualityGateResult.json"
					def sonarPassed = (qualityGateResult != null && qualityGateResult.projectStatus != null && qualityGateResult.projectStatus.status == "OK")
					def projectKey = "${buildConfig.key}-" + sh(returnStdout: true, script: "echo `$configs.sonarConfigs.projectKey`").trim()
					rowTemplateBuilder <<= rowTemplate.replaceAll("PLACEHOLDER_QUALITY_CHECK_URL", "$configs.notifications.configs.sonarBaselineURL$projectKey")
									  				  .replaceAll("PLACEHOLDER_QUALITY_CHECK_NAME", "Sonar Analysis")
									  				  .replaceAll("PLACEHOLDER_QUALITY_CHECK_RESULT", (sonarPassed ? "✔ PASSED" : "❌ FAILED"))
				}
				else {
					rowTemplateBuilder <<= rowTemplate.replaceAll("PLACEHOLDER_QUALITY_CHECK_URL", "$configs.notifications.configs.sonarBaselineURL$projectKey")
			  				  .replaceAll("PLACEHOLDER_QUALITY_CHECK_NAME", "Sonar Analysis")
			  				  .replaceAll("PLACEHOLDER_QUALITY_CHECK_RESULT", "💤 NOT AVAILABLE")
				}
			}
			if (buildConfig.qualityChecks != null) {
				buildConfig.qualityChecks.each{ qualityCheck ->
					def qualityCheckURL = (nullToEmpty(qualityCheck.url) != "" ? qualityCheck.url : java.net.URLEncoder.encode(qualityCheck.fileToArchive, "UTF-8"))
					rowTemplateBuilder <<= rowTemplate.replaceAll("PLACEHOLDER_QUALITY_CHECK_URL", "${BUILD_URL}artifact/" + qualityCheckURL)
													  .replaceAll("PLACEHOLDER_QUALITY_CHECK_NAME", qualityCheck.name)
													  .replaceAll("PLACEHOLDER_QUALITY_CHECK_RESULT", sh(returnStdout: true, script: "cat '${qualityCheck.resultFile}.result'").trim().replaceAll("<.*?>", ""))
				}
			}
		}
		return rowTemplateBuilder.toString()
	});
}

/*****************************************
* Searched in the email template for a
* specific row template delimmited by the
* placeholder provided as input
****************************************/
def findEmailRowTemplate(emailTemplate = '', placeholder = '') {
	if (emailTemplate == null || placeholder == null) {
		return null
	}

	def indexOfPlaceholderStart = emailTemplate.indexOf(placeholder + "_START")
	def indexOfPlaceholderEnd = emailTemplate.indexOf(placeholder + "_END")

	if (indexOfPlaceholderStart == -1 || indexOfPlaceholderEnd == -1) {
		return null
	}

	def placeholderStartLength = (placeholder + "_START").length()
	def placeholderEndLength = (placeholder + "_END").length()
	return [
		rowsPlaceholder : emailTemplate.substring(indexOfPlaceholderStart, indexOfPlaceholderEnd + placeholderEndLength),
		rowTemplate : emailTemplate.substring(indexOfPlaceholderStart + placeholderStartLength, indexOfPlaceholderEnd)
	]
}

/*****************************************
* Archive in job result all log
* files in root path
****************************************/
def archiveLogsAndEmail() {
	def configs = getConfigs()

	archiveFiles("*.log")
	if (configs != null && configs.notifications != null ) {
		configs.notifications.keySet().each{ notificationKey ->
			if (notificationKey != "configs" && nullToEmpty(configs.notifications[notificationKey].filePath) != "") {
				archiveFiles(configs.notifications[notificationKey].filePath)
			}
		}
	}
}

/*****************************************
* Archive in job result files that 
* match pattern
****************************************/
def archiveFiles(pattern = '') {
	try {
		echo "Archiving files matching $pattern"
		archiveArtifacts artifacts: pattern, fingerprint: false
	} catch (err) {
        echo err.getMessage()
    }
}

/*****************************************
* Logs a validation failure
****************************************/
def logFailure(failureReason = '', blocker = false) {
	if (blocker == null || blocker == "") {
		blocker = false
	}
	def failureReasons = readJSON text: env.FAILURE_REASONS
	failureReasons.add([
        msg: failureReason.toString(),
        blocker: blocker
    ])
	env.FAILURE_REASONS = groovy.json.JsonOutput.toJson(failureReasons)
}

/*****************************************
* Adds a comment to the merge request
* being analysed
****************************************/
def addCommentToMergeRequest(java.util.LinkedHashMap commentTemplates) {
	if (commentTemplates != null) {
		def configs = getConfigs()
		loadAdditionalChangeEnv()

		if (configs.gitProvider == "gitlab" && nullToEmpty(commentTemplates.gitlab) != "") {
			withCredentials([string(credentialsId: configs.gitlabConfigs.authToken, variable: 'GITLAB_AUTH_TOKEN')]) {
				retry(3) {
					sh "curl --insecure --max-time 20 --request POST --header \"PRIVATE-TOKEN: $GITLAB_AUTH_TOKEN\" ${configs.gitlabConfigs.apiURL}/projects/$CHANGE_SOURCE_PROJECT_ID/merge_requests/$CHANGE_ID/notes?body=" + java.net.URLEncoder.encode(commentTemplates.gitlab, "UTF-8")
				}
			}
		}
		else if (configs.gitProvider == "bitbucket-cloud" && nullToEmpty(commentTemplates.bitbucket) != "") {
			withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: configs.bitbucketConfigs.credentialsId, usernameVariable: 'BITBUCKET_CREDENTIALS_USR', passwordVariable: 'BITBUCKET_CREDENTIALS_PSW']]) {
				def pullRequestURL = "$CHANGE_URL".replace("/pull-requests/", "/pullrequests/")
				while (pullRequestURL.count("/") > 3) {
					pullRequestURL = pullRequestURL.substring(pullRequestURL.indexOf("/") + 1)
				}
				try {
					def curlArguments = "--insecure --max-time 20 --request POST --header 'Content-Type: application/json' -d '{\"content\": { \"raw\": \"$commentTemplates.bitbucket\" }}' $configs.bitbucketConfigs.apiURL/repositories/$pullRequestURL/comments"
					sh 'curl -u $BITBUCKET_CREDENTIALS_USR:$BITBUCKET_CREDENTIALS_PSW ' + curlArguments 
				}
				catch (err) {
			    }
			}
		}
		else if (configs.gitProvider == "bitbucket-server" && nullToEmpty(commentTemplates.bitbucket) != "") {
			withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: configs.bitbucketConfigs.credentialsId, usernameVariable: 'BITBUCKET_CREDENTIALS_USR', passwordVariable: 'BITBUCKET_CREDENTIALS_PSW']]) {
				def pullRequestURL = "$CHANGE_URL".replaceAll("/overview\$", "")
				while (pullRequestURL.count("/") > 5) {
					pullRequestURL = pullRequestURL.substring(pullRequestURL.indexOf("/") + 1)
				}
				try {
					def curlArguments = "--insecure --max-time 20 --request POST --header 'Content-Type: application/json' -d '{\"text\": \"$commentTemplates.bitbucket\" }' $configs.bitbucketConfigs.apiURL/$pullRequestURL/comments"
					sh 'curl -u $BITBUCKET_CREDENTIALS_USR:$BITBUCKET_CREDENTIALS_PSW ' + curlArguments
				}
				catch (err) {
			    }
			}
		}
	}
}

/*****************************************
* Approves the merge request
* being analysed
****************************************/
def approveMergeRequest() {
	def configs = getConfigs()
	loadAdditionalChangeEnv()
	
	if (configs.gitProvider == "gitlab") {
		withCredentials([string(credentialsId: configs.gitlabConfigs.authToken, variable: 'GITLAB_AUTH_TOKEN')]) {
			retry(3) {
				sh "curl --insecure --max-time 20 --request POST --header \"PRIVATE-TOKEN: $GITLAB_AUTH_TOKEN\" ${configs.gitlabConfigs.apiURL}/projects/$CHANGE_SOURCE_PROJECT_ID/merge_requests/$CHANGE_ID/approve?sha=$CHANGE_COMMIT"
			}
		}
	}
	else if (configs.gitProvider == "bitbucket-cloud") {
		withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: configs.bitbucketConfigs.credentialsId, usernameVariable: 'BITBUCKET_CREDENTIALS_USR', passwordVariable: 'BITBUCKET_CREDENTIALS_PSW']]) {
			def pullRequestURL = "$CHANGE_URL".replace("/pull-requests/", "/pullrequests/")
			while (pullRequestURL.count("/") > 3) {
				pullRequestURL = pullRequestURL.substring(pullRequestURL.indexOf("/") + 1)
			}
			try {
				def curlArguments = "--insecure --max-time 20 --request POST -d '{}' --header 'Content-Type: application/json' $configs.bitbucketConfigs.apiURL/repositories/$pullRequestURL/approve"
				sh 'curl -u $BITBUCKET_CREDENTIALS_USR:$BITBUCKET_CREDENTIALS_PSW ' + curlArguments
			}
			catch (err) {
		    }
		}
	}
}

/*****************************************
* Unapproves the merge request
* being analysed
****************************************/
def unapproveMergeRequest() {
	def configs = getConfigs()
	loadAdditionalChangeEnv()

	if (configs.gitProvider == "gitlab") {
		withCredentials([string(credentialsId: configs.gitlabConfigs.authToken, variable: 'GITLAB_AUTH_TOKEN')]) {
			retry(3) {
				sh "curl --insecure --max-time 20 --request POST --header \"PRIVATE-TOKEN: $GITLAB_AUTH_TOKEN\" ${configs.gitlabConfigs.apiURL}/projects/$CHANGE_SOURCE_PROJECT_ID/merge_requests/$CHANGE_ID/unapprove"
			}
		}
	}
	else if (configs.gitProvider == "bitbucket-cloud") {
		withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: configs.bitbucketConfigs.credentialsId, usernameVariable: 'BITBUCKET_CREDENTIALS_USR', passwordVariable: 'BITBUCKET_CREDENTIALS_PSW']]) {
			def pullRequestURL = "$CHANGE_URL".replace("/pull-requests/", "/pullrequests/")
			while (pullRequestURL.count("/") > 3) {
				pullRequestURL = pullRequestURL.substring(pullRequestURL.indexOf("/") + 1)
			}
			try {
				def curlArguments = "--insecure --max-time 20 --request DELETE -d '{ }' --header 'Content-Type: application/json' $configs.bitbucketConfigs.apiURL/repositories/$pullRequestURL/approve"
				sh 'curl -u $BITBUCKET_CREDENTIALS_USR:$BITBUCKET_CREDENTIALS_PSW ' + curlArguments
			}
			catch (err) {
		    }
		}
	}
}

/*****************************************
* Unapproves the merge request
* being analysed
****************************************/
def mergeMergeRequest() {
	def configs = getConfigs()
	loadAdditionalChangeEnv()

	if (configs.gitProvider == "gitlab") {
		withCredentials([string(credentialsId: configs.gitlabConfigs.authToken, variable: 'GITLAB_AUTH_TOKEN')]) {
			retry(3) {
				sh "curl --insecure --max-time 20 --request PUT --header \"PRIVATE-TOKEN: $GITLAB_AUTH_TOKEN\" ${configs.gitlabConfigs.apiURL}/projects/$CHANGE_SOURCE_PROJECT_ID/merge_requests/$CHANGE_ID/merge?should_remove_source_branch=true\\&sha=$CHANGE_COMMIT"
			}
		}
	}
	else if (configs.gitProvider.startsWith("bitbucket")) {
		withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: configs.bitbucketConfigs.credentialsId, usernameVariable: 'BITBUCKET_CREDENTIALS_USR', passwordVariable: 'BITBUCKET_CREDENTIALS_PSW']]) {
			def pullRequestURL = "$CHANGE_URL".replace("/pull-requests/", "/pullrequests/")
			while (pullRequestURL.count("/") > 3) {
				pullRequestURL = pullRequestURL.substring(pullRequestURL.indexOf("/") + 1)
			}
			try {
				def curlArguments = "--insecure --max-time 20 --request POST -d '{ \"close_source_branch\": true }' --header 'Content-Type: application/json' $configs.bitbucketConfigs.apiURL/repositories/$pullRequestURL/merge"
				sh 'curl -u $BITBUCKET_CREDENTIALS_USR:$BITBUCKET_CREDENTIALS_PSW ' + curlArguments
			}
			catch (err) {
		    }
		}
	}
}

/*****************************************
* Load env.CHANGE_REAL_ID
****************************************/
def loadAdditionalChangeEnv() {
	def configs = getConfigs()
	if (configs.gitProvider == "gitlab") {
		loadAdditionalGitlabChangeEnv(configs)	
	}
	else if (configs.gitProvider == "bitbucket-cloud") {
		loadAdditionalBitbucketCloudChangeEnv(configs)
	}
	else if (configs.gitProvider == "bitbucket-server") {
		loadAdditionalBitbucketServerChangeEnv(configs)
	}
}

/*****************************************
* Load env.CHANGE_REAL_ID
****************************************/
def loadAdditionalGitlabChangeEnv(net.sf.json.JSONObject configs) {
	if (!env.CHANGE_REAL_ID || !env.CHANGE_SOURCE_PROJECT_ID || !env.CHANGE_REMOVE_SOURCE_BRANCH) {
		
		def projectName = "$CHANGE_URL".substring(0, "$CHANGE_URL".lastIndexOf("/merge_requests"))
		projectName = projectName.substring(projectName.lastIndexOf("/") + 1)			

		env.CHANGE_SOURCE_PROJECT_ID = getGitlabProjectId(configs.gitlabConfigs.apiURL, configs.gitlabConfigs.authToken, projectName)

		withCredentials([string(credentialsId: configs.gitlabConfigs.authToken, variable: 'GITLAB_AUTH_TOKEN')]) {
			retry(3) {
				sh "curl --insecure --max-time 20 --request GET --header 'PRIVATE-TOKEN: $GITLAB_AUTH_TOKEN' -o merge-request-details.json ${configs.gitlabConfigs.apiURL}/projects/$CHANGE_SOURCE_PROJECT_ID/merge_requests/$CHANGE_ID"
			}
		}
		def mergeRequestDetails = readJSON file: 'merge-request-details.json'
		env.CHANGE_REAL_ID = mergeRequestDetails.id.toString()
		env.CHANGE_REMOVE_SOURCE_BRANCH = mergeRequestDetails.force_remove_source_branch.toString()
	}
	if (!env.CHANGE_COMMIT) {
		env.CHANGE_COMMIT = sh(returnStdout: true, script: "git rev-parse refs/remotes/origin/$BRANCH_NAME").trim()
	}
}

/*****************************************
* Load env.CHANGE_REAL_ID
****************************************/
def loadAdditionalBitbucketCloudChangeEnv(net.sf.json.JSONObject configs) {
	if (!env.CHANGE_REMOVE_SOURCE_BRANCH) {
		withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: configs.bitbucketConfigs.credentialsId, usernameVariable: 'BITBUCKET_CREDENTIALS_USR', passwordVariable: 'BITBUCKET_CREDENTIALS_PSW']]) {
			def pullRequestURL = "$CHANGE_URL".replace("/pull-requests/", "/pullrequests/")
			while (pullRequestURL.count("/") > 3) {
				pullRequestURL = pullRequestURL.substring(pullRequestURL.indexOf("/") + 1)
			}
			try {
				def curlArguments = "--insecure --max-time 20 --request GET -o merge-request-details.json --header 'Content-Type: application/json' $configs.bitbucketConfigs.apiURL/repositories/$pullRequestURL"
				sh 'curl -u $BITBUCKET_CREDENTIALS_USR:$BITBUCKET_CREDENTIALS_PSW ' + curlArguments
			}
			catch (err) {
		    }
		}
		def mergeRequestDetails = readJSON file: 'merge-request-details.json'
		env.CHANGE_REMOVE_SOURCE_BRANCH = mergeRequestDetails.close_source_branch.toString()
	}
	if (!env.CHANGE_COMMIT) {
		env.CHANGE_COMMIT = sh(returnStdout: true, script: "git rev-parse refs/remotes/origin/$BRANCH_NAME").trim()
	}
}

/*****************************************
* Load env.CHANGE_REAL_ID
****************************************/
def loadAdditionalBitbucketServerChangeEnv(net.sf.json.JSONObject configs) {
	env.CHANGE_REMOVE_SOURCE_BRANCH = "true"
	if (!env.CHANGE_COMMIT) {
		env.CHANGE_COMMIT = sh(returnStdout: true, script: "git rev-parse refs/remotes/origin/$BRANCH_NAME").trim()
	}
}

/*****************************************
* Get gitlab project Id from projectName
****************************************/
def getGitlabProjectId(gitlabAPIURL = '', gitlabAuthToken = '', projectName = '') {
    withCredentials([string(credentialsId: gitlabAuthToken, variable: 'GITLAB_AUTH_TOKEN')]) {
        retry(3) {
            sh "curl --insecure --max-time 20 -o gitlab-project-search.json --request GET --header \"Content-Type: application/json\" --header \"PRIVATE-TOKEN: $GITLAB_AUTH_TOKEN\" ${gitlabAPIURL}/projects?search=" + java.net.URLEncoder.encode(projectName, "UTF-8")
        }
    }
    def gitlabProjectSearch = readJSON file: "gitlab-project-search.json"
    def projectId = ""
    gitlabProjectSearch.each { searchResult ->
        if (searchResult.name == projectName) {
            projectId = searchResult.id
        }
    }
    if (projectId != "") {
        return projectId
    }
    error("Gitlab project '$projectName' not found")
}

/*****************************************
* Logic reset sonar analysis
****************************************/
def resetSonarAnalyses() {
	def configs = getConfigs()
	def buildConfigs = configs.buildConfigs

	//Remove sonar project to recreate it based in $configs.sonarConfigs.resetSonar.resetBranch
	buildConfigs.each{ buildConfig ->
		if (buildConfig.enabled && buildConfig.sonarEnabled) {
			def projectKeyToDelete = "${buildConfig.key}-" + sh(returnStdout: true, script: "echo `$configs.sonarConfigs.projectKey`").trim()
			withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: configs.sonarConfigs.resetSonar.adminCredentials, usernameVariable: 'SONAR_RESET_SONAR_ADMIN_CREDENTIALS_USR', passwordVariable: 'SONAR_RESET_SONAR_ADMIN_CREDENTIALS_PSW']]) {
				sh 'curl --insecure -s -u ${SONAR_RESET_SONAR_ADMIN_CREDENTIALS_USR}:${SONAR_RESET_SONAR_ADMIN_CREDENTIALS_PSW} -X POST ' + configs.sonarConfigs.url + '/api/projects/delete?project=' + projectKeyToDelete
			}
		}
	}

	//Logic to add no-password remote
	def gitURLWithoutProtocol = sh(returnStdout: true, script: 'git config remote.origin.url').trim().replaceFirst('^(http[s]?://www\\.|http[s]?://|www\\.)','').replaceFirst('([/]?)$','')
	sh 'if [[ $(git remote | grep ^origin-repo$) ]]; then git remote rm origin-repo; fi'
	sh "git remote add origin-repo ${GIT_PROTOCOL}://${gitURLWithoutProtocol}"
	withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: configs.sonarConfigs.resetSonar.gitCredentials, usernameVariable: 'SONAR_RESET_GIT_CREDENTIALS_USR', passwordVariable: 'SONAR_RESET_GIT_CREDENTIALS_PSW']]) {
		sh 'echo "' + env.GIT_PROTOCOL + '://' + java.net.URLEncoder.encode("${SONAR_RESET_GIT_CREDENTIALS_USR}", "UTF-8") + ':${SONAR_RESET_GIT_CREDENTIALS_PSW}@' + gitURLWithoutProtocol + '" > "' + env.WORKSPACE + '/.git/.git-credentials"'
	}
	sh "git config credential.helper \"store --file='$WORKSPACE/.git/.git-credentials'\""

	//Store current commit in temp-branch
	sh "rm -Rf .git/hooks && \
		git branch -D temp-branch | true && \
		git checkout -b temp-branch"

	retry(3) {
		sh "git fetch origin-repo $configs.sonarConfigs.resetSonar.resetBranch:$configs.sonarConfigs.resetSonar.resetBranch && \
			git checkout -f $configs.sonarConfigs.resetSonar.resetBranch"
	}

	//Run base analysis
	executeBuilds("Reset Sonar for ", "sonar-reset-", true, "buildCommandOnSonarReset")

	//Wait for base analysis to end
	buildConfigs.each{ buildConfig ->
		if (buildConfig.enabled && buildConfig.sonarEnabled) {
			if (sh(returnStdout: true, script: "cat 'sonar-reset-${buildConfig.key}.result'").contains("PASSED")) {
				def ceTaskUrl
				try {
					ceTaskUrl = sh(returnStdout: true, script: buildConfig.sonarTaskUrl)
				}
				catch (err) {
					ceTaskUrl = null
			    }
				if (ceTaskUrl != null) {
					waitForSonarAnalysis(ceTaskUrl)
				}
		    }
		}
	}

	//Return to original branch
	sh "rm -Rf .git/hooks && \
		git checkout . && \
		git checkout -f temp-branch"
}

/*****************************************
* Waits for Sonar analysis to end
****************************************/
def waitForSonarAnalysis(ceTaskUrl = '') {
	if (ceTaskUrl == null || ceTaskUrl == "") {
		return ""
	}

	int maxFailedAttempts = 120;
	int secondsBetweenAttempts = 10

	int failedAttempts = 0;
	echo "Waiting for sonar task results..."

	while (failedAttempts < maxFailedAttempts) {
		sh "curl --insecure -s -o ./ceTaskResult.json $ceTaskUrl"
		def ceTaskResult = readJSON file: "./ceTaskResult.json"
		if (ceTaskResult != null && ceTaskResult.task != null && ceTaskResult.task.status != "IN_PROGRESS" && ceTaskResult.task.status != "PENDING") {
			if (ceTaskResult.task.status != "SUCCESS") {
				echo ceTaskResult.toString()
				sh "echo 'Error processing sonar analysis.' && exit 1"
			}
			return ceTaskResult.task.analysisId
		}
		else {
		    failedAttempts += 1
		    if (failedAttempts < maxFailedAttempts) {
				echo "Sonar task is still in progress. Retry #" + failedAttempts.toString() + " in " + secondsBetweenAttempts.toString() + " seconds..."
		    	sh "sleep " + secondsBetweenAttempts.toString()
		    }
		}
	}
	sh "echo 'Error trying to get sonar quality gate results.' && exit 1"
}

/**************************************************
* Execute the pipeline builds based in
* buildConfigs
***************************************************/
def executeBuilds(stagePrefix = '', executionKeyPrefix = '', resetSonarExecution = false, propertyOfBuildCommand = 'buildCommand') {
	def configs = getConfigs()
	def buildConfigs = configs.buildConfigs

	if (configs.buildSynchronous == "false") {
		def stepsForParallel = buildConfigs.collectEntries {[
    	 	"$stagePrefix $it.name" : {
				if (buildConfig.enabled) {
					executeBuild(stagePrefix, executionKeyPrefix, resetSonarExecution, propertyOfBuildCommand, it)
				}
        	}
    	]}
    	parallel stepsForParallel
	}
	else {
		buildConfigs.each{ buildConfig ->
			stage(stagePrefix + buildConfig.name) {
				if (buildConfig.enabled) {
					executeBuild(stagePrefix, executionKeyPrefix, resetSonarExecution, propertyOfBuildCommand, buildConfig)
				}
			}
		}
	}
}

/**************************************************
* Execute a build from buildConfigs
***************************************************/
def executeBuild(stagePrefix = '', executionKeyPrefix = '', resetSonarExecution = false, propertyOfBuildCommand = 'buildCommand', buildConfig) {
	def configs = getConfigs()
	def managedFiles = []
	def dockerfileConfig = buildConfig.agent.dockerfile
	buildConfig.managedFiles.each{ managedFile ->
		managedFiles.add(configFile(fileId: managedFile.fileId, targetLocation: managedFile.targetLocation))
	}
	configFileProvider(managedFiles) {
		try {
			if (!resetSonarExecution || buildConfig.sonarEnabled) {
				def buildCommand = buildConfig[propertyOfBuildCommand]
				if (buildCommand == null || buildCommand == "") {
					buildCommand = buildConfig.buildCommand
				}
						
				def shell = dockerfileConfig.shell == null ? "/bin/bash" : dockerfileConfig.shell 
				def GITLAB_AUTH_TOKEN = configs.gitProvider == "gitlab" ? credentials(configs.gitlabConfigs.authToken) : ""
				sh "cd \"${dockerfileConfig.dir}\" && \
					docker build -f '$dockerfileConfig.filename' $dockerfileConfig.additionalBuildArgs . && \
					echo '<span>❌ FAILED</span>' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result' && \
					export SONAR_PROJECT_KEY=`$configs.sonarConfigs.projectKey` && \
					export SONAR_PROJECT_NAME=`$configs.sonarConfigs.projectName` && \
					export SONAR_PROJECT_KEY=\"$buildConfig.key-\$SONAR_PROJECT_KEY\" && \
					export SONAR_PROJECT_NAME=\"$buildConfig.key - \$SONAR_PROJECT_NAME\" && \
					docker run -u 0:0 --volumes-from jenkins --rm --entrypoint '' -w '$WORKSPACE' -e WORKSPACE='$WORKSPACE' -e SONAR_URL=$configs.sonarConfigs.url -e SONAR_PROJECT_KEY=\"\$SONAR_PROJECT_KEY\" -e SONAR_PROJECT_NAME=\"\$SONAR_PROJECT_NAME\" ${dockerfileConfig.args} \$(docker build -q -f '$dockerfileConfig.filename' $dockerfileConfig.additionalBuildArgs .) \
					$shell -c 'set -o xtrace && $buildConfig.buildCommand && echo \"<span style=\\\"color:black;\\\">✔ PASSED</span>\" > \"$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result\"' 2>&1 | tee '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.log'"
				if (!resetSonarExecution) {
					archiveFilesFromQualityChecks(buildConfig.qualityChecks)
				}
			}
			else {
				sh "echo '<span style=\"background:#99cc33;\"> SKIPPED </span>' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result'"
			}
		} catch (err) {
	        echo err.getMessage()
			sh "echo '<span style=\"background:#ff9966;\"> FAILED </span>' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result'"
	    }
	}
}

/**************************************************
* Archive files from quality checks
***************************************************/
def archiveFilesFromQualityChecks(qualityChecks = [ ]) {
	if (qualityChecks != null) {
		qualityChecks.each{ qualityCheck ->
			if (qualityCheck.fileToArchive != null) {
				archiveFiles(qualityCheck.fileToArchive)
			}
		}
	}
}

/*****************************************
* Returns an empty string if a null
* value is passed as input
****************************************/
def nullToEmpty(value = '') {
	return value ? value : ""
}

/*****************************************
* To enable load in other pipelines
****************************************/
return this;