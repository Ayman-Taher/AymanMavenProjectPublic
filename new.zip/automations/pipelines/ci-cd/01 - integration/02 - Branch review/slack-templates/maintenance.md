Failed review of `PLACEHOLDER_GIT_BRANCH` branch in `PLACEHOLDER_GIT_REPO` repository.  


*Source details:*
🔹 Git branch: PLACEHOLDER_GIT_BRANCH
🔹 Git commit: PLACEHOLDER_GIT_COMMIT


*Execution details:*
🔹 Result: PLACEHOLDER_EXECUTION_RESULT
🔹 Duration: PLACEHOLDER_EXECUTION_DURATION
🔹 <PLACEHOLDER_EXECUTION_URL|Automation log>