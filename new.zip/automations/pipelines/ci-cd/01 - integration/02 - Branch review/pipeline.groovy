/*****************************************
* Runs the pipeline
****************************************/
def start() {
	withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'docker-readonly', usernameVariable: 'DOCKER_USERNAME', passwordVariable: 'DOCKER_PASSWORD']]) {
		sh 'docker login -u ' + "$DOCKER_USERNAME" + ' -p ' + "$DOCKER_PASSWORD" + ' cicd-tooling-ee.stc.com.sa'
	}
	
	stage('Prepare') {
		env.GIT_PROTOCOL = "https"
		sh "git clean -fd"
		try {
			sh '[ ! -d "automations/pipelines" ] && ln -s "$(pwd)" automations/pipelines'
		} catch (err) {
	    }
	}

	def configs = getConfigs()
	stage('Reset Sonar Analysis') {
		if (isToResetSonarAnalyses()) {
			resetSonarAnalyses()
		}
	}
	stage('Builds, Unit Tests and Sonar') {
		env.NOTIFICATION_GIT_BRANCH = "$GIT_BRANCH"
		env.NOTIFICATION_GIT_COMMIT = "$GIT_COMMIT"
		env.NOTIFICATION_SONAR_PROJECT_KEY = sh(returnStdout: true, script: "echo `$configs.sonarConfigs.projectKey`").trim()
		env.NOTIFICATION_SONAR_PROJECT_NAME = sh(returnStdout: true, script: "echo `$configs.sonarConfigs.projectName`").trim()
		executeBuilds("Execution of ")
	}
	stage('Publish') {
    	def versionsToPublish = versionsToPublish()

    	env.NOTIFICATION_PUBLISHED_DOCKER_IMAGES = ''
		env.NOTIFICATION_PUBLISHED_MAVEN_ARTIFACTS = ''
		env.NOTIFICATION_VERSIONS = nullToEmpty(groovy.json.JsonOutput.toJson(versionsToPublish)).replaceAll("\\[|\\]|\"","").replaceAll(",", ", ")
		versionsToPublish.each{ version ->
			configs.publishConfigs.each{ publishConfig ->
				if (publishConfig.type == "docker-image") {
					publishDockerImage(publishConfig, version)
					env.NOTIFICATION_PUBLISHED_DOCKER_IMAGES += ' ' + sh(returnStdout: true, script: "version=$version && PUBLISH_GENERIC_DOCKER_REGISTRY_URL=$PUBLISH_GENERIC_DOCKER_REGISTRY_URL && echo " + publishConfig.targetImage).trim()
				}
				else if (publishConfig.type == "maven-artifact") {
					publishMavenArtifact(publishConfig, version)
				}
        	}
		}
    }
}

/*****************************************
* Runs in the end of a successull build
****************************************/
def postSuccess() {
	def configs = getConfigs()
	sendSuccessNotification(configs)
	archiveLogsAndEmail()
	execHouseKeeping()
}

/*****************************************
* Runs in the end of a failed build
****************************************/
def postFailure() {
	def configs = getConfigs()
	sendMaintenanceNotification(configs)
	archiveLogsAndEmail()
	execHouseKeeping()
}

/*****************************************
* Get pipeline configs
****************************************/
def getConfigs() {
	if (env.configs == null) {
		def configs = null
				
		def gitflowConfigFilePath = ""
		def configFilePath = "automations/configs/ci-cd/02 - integration - branch review.json"
		def deprecatedConfigFilePath = "automations/configs/ci-cd/01 - integration/02 - Branch review/config.json"
		
		if ("$JOB_NAME".contains("/02 - Develop/")) {
			gitflowConfigFilePath = "automations/configs/ci-cd/02 - develop - integration - feature review.json"
		}
		else if ("$JOB_NAME".contains("/03 - Release/")) {
			gitflowConfigFilePath = "automations/configs/ci-cd/08 - release - integration - bugfix review.json"
		}
		else if ("$JOB_NAME".contains("/04 - Master/")) {
			gitflowConfigFilePath = "automations/configs/ci-cd/14 - master - integration - hotfix review.json"
		}
		
		if (gitflowConfigFilePath == "") {
			try {
				configs = readJSON file: configFilePath
			} catch (err) {
				echo "Pipeline configuration not found. Attempting deprecated location..."
		    }
			if (nullToEmpty(configs) == "") {
				try {
					configs = readJSON file: deprecatedConfigFilePath 
				} catch (err) {
					error("Pipeline configuration not found or invalid. Please create a valid configuration in '$configFilePath'")
			    }
			}			
		}
		else {
			try {
				configs = readJSON file: gitflowConfigFilePath 
			} catch (err) {
				error("Pipeline configuration not found or invalid. Please create a valid configuration in '$gitflowConfigFilePath'")
		    }
		}
		
		
		def defaultConfigs = readJSON file: "automations/pipelines/ci-cd/01 - integration/02 - Branch review/config-defaults.json"
			
		def gitflowDefaultConfigs = null
		if ("$JOB_NAME".contains("/02 - Develop/")) {
			gitflowDefaultConfigs = readJSON file: "automations/pipelines/ci-cd/01 - integration/02 - Branch review/config-defaults-develop.json"
		}
		else if ("$JOB_NAME".contains("/03 - Release/")) {
			gitflowDefaultConfigs = readJSON file: "automations/pipelines/ci-cd/01 - integration/02 - Branch review/config-defaults-release.json"
		}
		else if ("$JOB_NAME".contains("/04 - Master/")) {
			gitflowDefaultConfigs = readJSON file: "automations/pipelines/ci-cd/01 - integration/02 - Branch review/config-defaults-master.json"
		}
		if (gitflowDefaultConfigs != null) {
			defaultConfigs = loadDefaultConfigs(gitflowDefaultConfigs, defaultConfigs)
		}
		
		echo "DEFAULT CONFIGS: " + groovy.json.JsonOutput.toJson(defaultConfigs)
		echo "CONFIGS BEFORE: " + groovy.json.JsonOutput.toJson(configs)
		configs = loadDefaultConfigs(configs, defaultConfigs)
		echo "CONFIGS AFTER: " + groovy.json.JsonOutput.toJson(configs)
			
		env.configs = groovy.json.JsonOutput.toJson(configs)
		return configs
	}
	def configs = readJSON text: env.configs
	return configs
}

/*****************************************
* Load default configs if they are 
* not set in main configs
****************************************/
def loadDefaultConfigs(net.sf.json.JSONObject configs, net.sf.json.JSONObject defaultConfigs, logContext = '') {

	if (defaultConfigs != null) {
		defaultConfigs.keys().each{ key ->
			def configValue = configs[key]
			def defaultValue = defaultConfigs[key]
			
			if (configValue == null) {
				echo "Updating config value '$logContext$key' to default '$defaultValue'"
				configs[key] = defaultValue 
			}
			else if (defaultValue != null && defaultValue instanceof net.sf.json.JSONObject) {
				if (configValue instanceof net.sf.json.JSONObject) {
					configs[key] = loadDefaultConfigs(configValue, defaultValue, logContext + key + ".")
				}
				else if (configValue instanceof net.sf.json.JSONArray) {
					net.sf.json.JSONArray newConfigValue = new net.sf.json.JSONArray()
							
					configValue.each{ configValueItem ->
						if (configValueItem instanceof net.sf.json.JSONObject) {
							newConfigValue.add(loadDefaultConfigs(configValueItem, defaultValue, logContext + key + "[" + String.valueOf(newConfigValue.size()) + "]."))
						}
						else {
							newConfigValue.add(configValueItem)
						}
					}
					
					configs[key] = newConfigValue
				}
			}
		}
	}
	return configs
}

/**************************************************
* Identify versions to publish based in GIT tags
***************************************************/
def versionsToPublish() {
	def configs = getConfigs()
	def publishTagsInCurrentCommit = sh(returnStdout: true, script: "git show-ref --tags | grep $GIT_COMMIT | grep refs/tags/$configs.publishTagPath | sed -En \"s/.*\\/(.*)/\\1/p\" || echo ''").trim()
	if (publishTagsInCurrentCommit != null && publishTagsInCurrentCommit != "") {
		return publishTagsInCurrentCommit.split('\n')
	}
	return []
}

/**************************************************
* Execute the pipeline builds based in
* buildConfigs
***************************************************/
def executeBuilds(stagePrefix = '', executionKeyPrefix = '', resetSonarExecution = false) {
	def configs = getConfigs()
	def buildConfigs = configs.buildConfigs

	if (configs.buildSynchronous == "false") {
		def stepsForParallel = buildConfigs.collectEntries {[
    	 	"$stagePrefix $it.name" : {
				if (buildConfig.enabled) {
					executeBuild(stagePrefix, executionKeyPrefix, resetSonarExecution, it)
				}
        	}
    	]}
    	parallel stepsForParallel
	}
	else {
		buildConfigs.each{ buildConfig ->
			stage(stagePrefix + buildConfig.name) {
				if (buildConfig.enabled) {
					executeBuild(stagePrefix, executionKeyPrefix, resetSonarExecution, buildConfig)
				}
		    }
		}
	}
}

/**************************************************
* Execute a build from buildConfigs
***************************************************/
def executeBuild(stagePrefix = '', executionKeyPrefix = '', resetSonarExecution = false, buildConfig) {
	def managedFiles = []
	def dockerfileConfig = buildConfig.agent.dockerfile
	def configs = getConfigs()

	if (isToResetSonarAnalyses() && buildConfig.conditionToBuildInResetSonarContext != null && nullToEmpty(buildConfig.conditionToBuildInResetSonarContext.mustHaveChangesInPaths) != "") {
		def noFilesChanged = sh(returnStdout: true, script: "git diff --name-only $configs.sonarConfigs.resetSonar.resetBranch temp-branch | grep $buildConfig.conditionToBuildInResetSonarContext.mustHaveChangesInPaths | wc -l").trim()
		echo noFilesChanged
		if (noFilesChanged == "0") {
			sh "echo '<span style=\\\"color:black;\\\">💤 SKIPPED (no files changed)</span>' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result'"
			return
		}
	}
	buildConfig.managedFiles.each{ managedFile ->
		managedFiles.add(configFile(fileId: managedFile.fileId, targetLocation: managedFile.targetLocation))
	}
	configFileProvider(managedFiles) {
		try {
			if (!resetSonarExecution || buildConfig.sonarEnabled) {
				def shell = dockerfileConfig.shell == null ? "/bin/bash" : dockerfileConfig.shell 
				
				def sonarProjectKey = ""
				def sonarProjectName = ""
				def sonarURL = ""
				def versionLocal = nullToEmpty(env.version)
				if (configs.sonarConfigs != null) {
					sonarProjectKey = configs.sonarConfigs.projectKey
					sonarProjectName = configs.sonarConfigs.projectName
					sonarURL = configs.sonarConfigs.url
				}
						
				sh "cd \"${dockerfileConfig.dir}\" && \
					docker build -f '$dockerfileConfig.filename' $dockerfileConfig.additionalBuildArgs . && \
					echo '<span>❌ FAILED</span>' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result' && \
					export SONAR_PROJECT_KEY=`$sonarProjectKey` && \
					export SONAR_PROJECT_NAME=`$sonarProjectName` && \
					export SONAR_PROJECT_KEY=\"$buildConfig.key-\$SONAR_PROJECT_KEY\" && \
					export SONAR_PROJECT_NAME=\"$buildConfig.key - \$SONAR_PROJECT_NAME\" && \
					docker run -u 0:0 --volumes-from jenkins --rm --entrypoint '' -w '$WORKSPACE' -e WORKSPACE='$WORKSPACE' -e version='$versionLocal' -e SONAR_URL=$sonarURL -e SONAR_PROJECT_KEY=\"\$SONAR_PROJECT_KEY\" -e SONAR_PROJECT_NAME=\"\$SONAR_PROJECT_NAME\" ${dockerfileConfig.args} \$(docker build -q -f '$dockerfileConfig.filename' $dockerfileConfig.additionalBuildArgs .) \
					$shell -c 'set -o xtrace && $buildConfig.buildCommand && echo \"<span style=\\\"color:black;\\\">✔ PASSED</span>\" > \"$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result\"' 2>&1 | tee '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.log'"

				if (!resetSonarExecution) {
					archiveFilesFromQualityChecks(buildConfig.qualityChecks)
				}
			}
			else {
				sh "echo '<span style=\\\"color:black;\\\">💤 SKIPPED</span>' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result'"
			}
		} catch (err) {
	        echo err.getMessage()
			sh "echo '<span style=\\\"color:black;\\\">❌ FAILED</span>' > '$WORKSPACE/${executionKeyPrefix}${buildConfig.key}.result'"
	    }
	}
}

/**************************************************
* Archive files from quality checks
***************************************************/
def archiveFilesFromQualityChecks(qualityChecks = [ ]) {
	if (qualityChecks != null) {
		qualityChecks.each{ qualityCheck ->
			if (qualityCheck.fileToArchive != null) {
				archiveFiles(qualityCheck.fileToArchive)
			}
		}
	}
}

/**************************************************
* Publishes a docker images
***************************************************/
def publishDockerImage(publishConfig = [ ], version = '') {
	echo "Publishing: version $version of " + groovy.json.JsonOutput.toJson(publishConfig)
	if (publishConfig.command != null && publishConfig.command != "") {
		sh "version=$version && $publishConfig.command"
	}
	if (publishConfig.dockerCredentialId != null && publishConfig.dockerCredentialId != "") {
		withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: publishConfig.dockerCredentialId, usernameVariable: 'DOCKER_USERNAME', passwordVariable: 'DOCKER_PASSWORD']]) {
			def dockerRegistryAddress = publishConfig.targetImage.substring(0, publishConfig.targetImage.indexOf("/"))
			sh "docker login $dockerRegistryAddress -u $DOCKER_USERNAME -p $DOCKER_PASSWORD && \
				version=$version && \
				docker tag  \"" + publishConfig.sourceImage + "\" \"" + publishConfig.targetImage + "\" && \
				docker push \"" + publishConfig.targetImage + "\" && \
				docker logout $dockerRegistryAddress"
		}
	}
	else {
		sh "version=$version && \
			docker tag  \"" + publishConfig.sourceImage + "\" \"" + publishConfig.targetImage + "\" && \
			docker push \"" + publishConfig.targetImage + "\""
	}
}

/**************************************************
* Peforms an npm publish 
***************************************************/
def publishNPM(publishConfig = [ ], version = '') {
	echo "Publishing: version $version of " + groovy.json.JsonOutput.toJson(publishConfig)
	if (publishConfig.command != null && publishConfig.command != "") {
		sh "version=$version && $publishConfig.command"
	}
	
	def sourceFolder = publishConfig.sourceFolder
	if (publishConfig.dockerCredentialId != null && publishConfig.dockerCredentialId != "") {
		withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: publishConfig.dockerCredentialId, usernameVariable: 'NPM_USERNAME', passwordVariable: 'NPM_PASSWORD']]) {
			def npmRepositoryProtocol = publishConfig.npmRepositoryURL.substring(0, publishConfig.npmRepositoryURL.indexOf("://")+3)
			def npmRepositoryURLWithoutProtocol = publishConfig.npmRepositoryURL.substring(publishConfig.npmRepositoryURL.indexOf("://") + 3)
			sh "version=$version && \
				cd \"$sourceFolder\" && \
				json -I -f package.json -e 'this.publishConfig.registry=\"$npmRepositoryProtocol$NPM_USERNAME:$NPM_PASSWORD@$npmRepositoryURLWithoutProtocol\"' && \
				npm publish"
		}
	}
	else {
		sh "version=$version && \
			cd \"$sourceFolder\" && \
			json -I -f package.json -e 'this.publishConfig.registry=\"$publishConfig.npmRepositoryURL\"' && \
			npm publish"
	}
    publishConfig.components.each{ component ->
    	env.NOTIFICATION_PUBLISHED_NPM_COMPONENTS += ' ' + sh(returnStdout: true, script: "version=$version && echo \"" + component + "@" + version + "\"").trim()
    }
}

/**************************************************
* Publishes a maven artifact
***************************************************/
def publishMavenArtifact(publishConfig = [ ], version = '') {
	echo "Publishing: version $version of " + groovy.json.JsonOutput.toJson(publishConfig)
	
	def managedFiles = []
	if (publishConfig.managedFiles != null) {
		publishConfig.managedFiles.each{ managedFile ->
			managedFiles.add(configFile(fileId: managedFile.fileId, targetLocation: managedFile.targetLocation))
		}
	}
	configFileProvider(managedFiles) {
		if (publishConfig.command != null && publishConfig.command != "") {
			sh "version=$version && $publishConfig.command"
		}
		publishConfig.packages.each{ packageConfig ->
			echo "Uploading: " + groovy.json.JsonOutput.toJson(packageConfig)
			uploadMavenArtifact(packageConfig, version)
			env.NOTIFICATION_PUBLISHED_MAVEN_ARTIFACTS += ' ' + sh(returnStdout: true, script: "version=$version && echo " + packageConfig.groupId + ':' + packageConfig.artifactId + ':' + version + ':' + packageConfig.packaging).trim()
	    }
	}
}

/*****************************************
* Uploads a package to nexus with a assumption
* that there's a tar.gz file related to artifactId
* and version provided in the workspace root folder
****************************************/
def uploadMavenArtifact(packageConfig = [ ], version = '') {
	if (packageConfig.packaging == "pom") {
		sh "version=$version && \
			mvn jar:jar org.apache.maven.plugins:maven-deploy-plugin:2.7:deploy -s .m2/settings.xml \
			-f \"" + packageConfig.file + "\" \
			-DaltDeploymentRepository=" + packageConfig.repositoryId + "::default::" + packageConfig.mavenRepositoryURL
	}
	else {
		sh "version=$version && \
			mvn deploy:deploy-file -s .m2/settings.xml \
			-Durl=\"" + packageConfig.mavenRepositoryURL + "\" \
			-DrepositoryId=\"" + packageConfig.repositoryId + "\" \
			-Dfile=\"" + packageConfig.file + "\" \
			-Dpackaging=\"" + packageConfig.packaging + "\" \
			-DgeneratePom=true \
			-DgeneratePom.description=\"Generated from ${GIT_BRANCH} at ${GIT_COMMIT}\" \
			-DgroupId=\"" + packageConfig.groupId + "\" \
			-DartifactId=\"" + packageConfig.artifactId + "\" \
			-Dversion=\"" + version + "\""
	}
}


/*****************************************
* Sends the pipeline success email notification
****************************************/
def sendSuccessNotification(net.sf.json.JSONObject configs) {
	def notificationtTemplates = [
		email: "",
		slack: "",
		jira: ""
	]
			
	if (configs.notifications.email != null && configs.notifications.email.success != null) {
		notificationtTemplates.email = readFile(configs.notifications.email.success.templatePath)
	}
	if (configs.notifications.slack != null && configs.notifications.slack.success != null) {
		notificationtTemplates.slack = readFile(configs.notifications.slack.success.templatePath)
	}
	if (configs.notifications.jira != null && configs.notifications.jira.success != null) {
		notificationtTemplates.jira = readFile(configs.notifications.jira.success.templatePath)
	}
			
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_REPO", nullToEmpty("$GIT_URL").substring("$GIT_URL".lastIndexOf('/') + 1).replaceAll(".git", ""))
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_BRANCH", nullToEmpty(env.NOTIFICATION_GIT_BRANCH).replaceAll("origin/", ""))
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_COMMIT", nullToEmpty(env.NOTIFICATION_GIT_COMMIT))
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_VERSIONS", nullToEmpty(env.NOTIFICATION_VERSIONS))
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_RESULT", "SUCCESS")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_DURATION", "${currentBuild.durationString.replace(' and counting', '')}")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_URL", "$BUILD_URL")

	groovy.lang.Closure tranformFn = null

	def dockerImagesPublished = nullToEmpty(env.NOTIFICATION_PUBLISHED_DOCKER_IMAGES).trim().split(" ")
	tranformFn = { rowTemplate, dockerImagePublished ->
		if (dockerImagePublished == null) {
			return rowTemplate.replaceAll("PLACEHOLDER_PUBLISHED_DOCKER_IMAGE", "Not applicable")
		}
		else {
			return rowTemplate.replaceAll("PLACEHOLDER_PUBLISHED_DOCKER_IMAGE", dockerImagePublished)
		}
	}
	notificationtTemplates = replaceRowsPlaceholdersInTemplates(notificationtTemplates, "PLACEHOLDER_PUBLISHED_DOCKER_IMAGES", dockerImagesPublished, tranformFn)
					
	def mavenArtifactsPublished = nullToEmpty(env.NOTIFICATION_PUBLISHED_MAVEN_ARTIFACTS).trim().split(" ")
	tranformFn = { rowTemplate, mavenArtifactPublished ->
		if (mavenArtifactPublished == null) {
			return rowTemplate.replaceAll("PLACEHOLDER_PUBLISHED_MAVEN_ARTIFACT", "Not applicable")
		}
		else {
			return rowTemplate.replaceAll("PLACEHOLDER_PUBLISHED_MAVEN_ARTIFACT", mavenArtifactPublished)
		}
	}
	notificationtTemplates = replaceRowsPlaceholdersInTemplates(notificationtTemplates, "PLACEHOLDER_PUBLISHED_MAVEN_ARTIFACTS", mavenArtifactsPublished, tranformFn)
	
	def npmComponentsPublished = nullToEmpty(env.NOTIFICATION_PUBLISHED_NPM_COMPONENTS).trim().split(" ")
	tranformFn = { rowTemplate, rowData ->
		if (rowData == null) {
			return rowTemplate.replaceAll("PLACEHOLDER_PUBLISHED_NPM_COMPONENT", "Not applicable")
		}
		else {
			return rowTemplate.replaceAll("PLACEHOLDER_PUBLISHED_NPM_COMPONENT", rowData)
		}
	}
	notificationtTemplates = replaceRowsPlaceholdersInTemplates(notificationtTemplates, "PLACEHOLDER_PUBLISHED_NPM_COMPONENTS", npmComponentsPublished, tranformFn)

	notificationtTemplates = replaceReleaseNotesPlaceholders(notificationtTemplates)
	notificationtTemplates = replaceJIRAPlaceholders(notificationtTemplates, "success", configs)

	tranformFn = { rowTemplate, buildConfig, templateKey ->
		if (buildConfig.enabled) {
			def buildResult = sh(returnStdout: true, script: "cat '${buildConfig.key}.result'").trim()
			if (templateKey == "slack" || templateKey == "jira") {
				buildResult = buildResult.replaceAll("<.*?>", "")
			}
			rowTemplate = replaceSonarResultsPlaceholders(buildConfig, rowTemplate, templateKey)
								.replaceAll("PLACEHOLDER_BUILD_NAME", buildConfig.name)
								.replaceAll("PLACEHOLDER_BUILD_RESULT", buildResult)
								.replaceAll("PLACEHOLDER_BUILD_LOG_URL", buildResult.contains("SKIPPED") ? "" : "${BUILD_URL}artifact/${buildConfig.key}.log")
			
			def qualityCheckTemplateSpecs = findEmailRowTemplate(rowTemplate, "PLACEHOLDER_QUALITY_CHECK")
			if (qualityCheckTemplateSpecs != null) {
				def qualityCheckBuilder = "" << rowTemplate.substring(0, rowTemplate.indexOf("PLACEHOLDER_QUALITY_CHECK_START"))
				if (buildConfig.qualityChecks != null) {
					buildConfig.qualityChecks.each{ qualityCheck ->
						def qualityCheckURL = (nullToEmpty(qualityCheck.url) != "" ? qualityCheck.url : java.net.URLEncoder.encode(qualityCheck.fileToArchive, "UTF-8"))
						def qualityCheckResult = sh(returnStdout: true, script: "cat '${qualityCheck.resultFile}' || echo '<span style=\"color:black;\">💤 NOT AVAILABLE</span>'").trim()
						if (templateKey == "slack" || templateKey == "jira") {
							qualityCheckResult = qualityCheckResult.replaceAll("<.*?>", "")
						}
						qualityCheckBuilder <<= qualityCheckTemplateSpecs.rowTemplate
													.replaceAll("PLACEHOLDER_QUALITY_CHECK_URL", "${BUILD_URL}artifact/" + qualityCheckURL)
													.replaceAll("PLACEHOLDER_QUALITY_CHECK_NAME", qualityCheck.name)
													.replaceAll("PLACEHOLDER_QUALITY_CHECK_RESULT", qualityCheckResult)
					}
				}
				qualityCheckBuilder <<= rowTemplate.substring(rowTemplate.indexOf("PLACEHOLDER_QUALITY_CHECK_END") + "PLACEHOLDER_QUALITY_CHECK_END".length())
				return qualityCheckBuilder.toString()
			}
			return rowTemplate
		}
		return null
	}	
	notificationtTemplates = replaceRowsPlaceholdersInTemplates(notificationtTemplates, "PLACEHOLDER_BUILD_SUMMARY", configs.buildConfigs, tranformFn)
	notificationtTemplates = replaceRowsPlaceholdersInTemplates(notificationtTemplates, "PLACEHOLDER_BUILD_DETAILS", configs.buildConfigs, tranformFn)

	if (configs != null && configs.notifications != null ) {
		configs.notifications.keySet().each{ notificationKey ->
			if (notificationKey != "configs") {
				if (nullToEmpty(configs.notifications[notificationKey].filePath) != "") {
					writeFile   file: configs.notifications[notificationKey].filePath, text: nullToEmpty(notificationtTemplates[notificationKey])
				}
				
				if (notificationKey == "email" && configs.notifications.email.success != null) {
					try {
					    emailext 	subject: "$configs.notifications.email.success.subject - " + nullToEmpty(env.NOTIFICATION_GIT_BRANCH).replaceAll("origin/", "") + " #$BUILD_NUMBER",
					    			to: nullToEmpty(env.NOTIFICATION_GIT_BRANCH).replaceAll("origin/", "").equals("feature/setup_automations") ? configs.notifications.email.maintenance.mailingList : configs.notifications.email.success.mailingList,
					    			body: notificationtTemplates.email
					} catch (err) {
				        echo err.getMessage()
				    }
				}
				else if (notificationKey == "slack" && configs.notifications.slack.success != null) {
					try {
						slackSend	teamDomain: configs.notifications.slack.success.teamDomain,
									tokenCredentialId: configs.notifications.slack.success.tokenCredentialId,
									channel: configs.notifications.slack.success.channel,
									color: "good",
									message: notificationtTemplates.slack					
					} catch (err) {
				        echo err.getMessage()
				    }
				}
				else if (notificationKey == "jira" && configs.notifications.jira.success != null && env.jiraKeys != null) {
					try {
						def jiraKeysObj = readJSON text: env.jiraKeys
						jiraKeysObj.keySet().each{ jiraKey ->
							jiraAddComment  idOrKey: jiraKey,
											site: configs.jiraConfigs.jiraSite, 
											auditLog: false,
											input: [ body: notificationtTemplates.jira ]					
						}
					} catch (err) {
				        echo err.getMessage()
				    }
				}
			}
		}
	}
}

/*****************************************
* Sends the pipeline maintenance email notification
****************************************/
def sendMaintenanceNotification(net.sf.json.JSONObject configs) {
	def notificationtTemplates = [
  		email: "",
  		slack: ""
  	]
  			
  	if (configs.notifications.email != null && configs.notifications.email.maintenance != null) {
  		notificationtTemplates.email = readFile(configs.notifications.email.maintenance.templatePath)
  	}
  	if (configs.notifications.slack != null && configs.notifications.slack.maintenance != null) {
  		notificationtTemplates.slack = readFile(configs.notifications.slack.maintenance.templatePath)
  	}

	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_REPO", nullToEmpty("$GIT_URL").substring("$GIT_URL".lastIndexOf('/') + 1).replaceAll(".git", ""))
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_BRANCH", "$GIT_BRANCH")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_GIT_COMMIT", "$GIT_COMMIT")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_RESULT", "UNSTABLE")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_DURATION", "${currentBuild.durationString.replace(' and counting', '')}")
	notificationtTemplates = replacePlaceholderInTemplates(notificationtTemplates, "PLACEHOLDER_EXECUTION_URL", "$BUILD_URL")

	if (configs != null && configs.notifications != null ) {
		configs.notifications.keySet().each{ notificationKey ->
			if (notificationKey != "configs") {
				if (nullToEmpty(configs.notifications[notificationKey].filePath) != "") {
					writeFile   file: configs.notifications[notificationKey].filePath, text: nullToEmpty(notificationtTemplates[notificationKey])
				}
				
				if (notificationKey == "email" && configs.notifications.email.maintenance != null) {
					try {
					    emailext 	subject: configs.notifications.email.maintenance.subject,
					    			to: configs.notifications.email.maintenance.mailingList,
					    			body: notificationtTemplates.email
					} catch (err) {
				        echo err.getMessage()
				    }
				}
				else if (notificationKey == "slack" && configs.notifications.slack.maintenance != null) {
					try {
						slackSend	teamDomain: configs.notifications.slack.maintenance.teamDomain,
									tokenCredentialId: configs.notifications.slack.maintenance.tokenCredentialId,
									channel: configs.notifications.slack.maintenance.channel,
									color: "danger",
									message: notificationtTemplates.slack					
					} catch (err) {
				        echo err.getMessage()
				    }
				}
			}
		}
	}
}

/*****************************************
* Replace a placeholder by a value in a 
* map of templates
****************************************/
def replacePlaceholderInTemplates(java.util.LinkedHashMap templates, placeholder = '', value = '') {
	templates.keySet().each{ templateKey ->
		templates[templateKey] = templates[templateKey].replaceAll(placeholder, value)
	}
	return templates
}

/*****************************************
* Replace row placeholders in a 
* map of templates
****************************************/
def replaceRowsPlaceholdersInTemplates(templates, rowPlaceholder, rowsData, transformClosure) {
	templates.keySet().each{ templateKey ->
		def originalTemplate = templates[templateKey]
		def rowTemplateSpecs = findEmailRowTemplate(originalTemplate, rowPlaceholder)
		
		if (rowTemplateSpecs != null) {
			def contentBuilder = ""<< originalTemplate.substring(0, originalTemplate.indexOf(rowPlaceholder + "_START"))
			def rowContextAdded = false

			if (rowsData != null && (rowsData instanceof Collection || rowsData.getClass().isArray())) {
				rowsData.each { rowData ->
					def rowContent = transformClosure(rowTemplateSpecs.rowTemplate, rowData, templateKey)
					if (rowContent != null) {
						contentBuilder <<= rowContent
						rowContextAdded = true
					}
				}
			}
			
			if (!rowContextAdded) {
				contentBuilder <<= transformClosure(rowTemplateSpecs.rowTemplate, null, templateKey)
			}
			
			contentBuilder <<= originalTemplate.substring(originalTemplate.indexOf(rowPlaceholder + "_END") + (rowPlaceholder + "_END").length())
			templates[templateKey] = contentBuilder.toString()
		}
	}
	return templates
}

/*****************************************
* Searched in the email template for a
* specific row template delimmited by the
* placeholder provided as input
****************************************/
def findEmailRowTemplate(emailTemplate = '', placeholder = '') {
	if (emailTemplate == null || placeholder == null) {
		return null
	}

	def indexOfPlaceholderStart = emailTemplate.indexOf(placeholder + "_START")
	def indexOfPlaceholderEnd = emailTemplate.indexOf(placeholder + "_END")

	if (indexOfPlaceholderStart == -1 || indexOfPlaceholderEnd == -1) {
		return null
	}

	def placeholderStartLength = (placeholder + "_START").length()
	def placeholderEndLength = (placeholder + "_END").length()
	return [
		rowsPlaceholder : emailTemplate.substring(indexOfPlaceholderStart, indexOfPlaceholderEnd + placeholderEndLength),
		rowTemplate : emailTemplate.substring(indexOfPlaceholderStart + placeholderStartLength, indexOfPlaceholderEnd)
	]
}


/*****************************************
* Returns an empty string if a null
* value is passed as input
****************************************/
def nullToEmpty(value = '') {
	return value ? value : ""
}

/*****************************************
* Archive in job result all log
* files in root path
****************************************/
def archiveLogsAndEmail() {
	def configs = getConfigs()

	archiveFiles("*.log")
	if (configs != null && configs.notifications != null ) {
		configs.notifications.keySet().each{ notificationKey ->
			if (notificationKey != "configs" && nullToEmpty(configs.notifications[notificationKey].filePath) != "") {
				archiveFiles(configs.notifications[notificationKey].filePath)
			}
		}
	}
}

/*****************************************
* Archive in job result files that 
* match pattern
****************************************/
def archiveFiles(pattern = '') {
	try {
		echo "Archiving files matching $pattern"
		archiveArtifacts artifacts: pattern, fingerprint: false
	} catch (err) {
        echo err.getMessage()
    }
}

/*****************************************
* Identifies if sonar reset should be done
****************************************/
def isToResetSonarAnalyses() {
	def configs = getConfigs()
	return 	configs.sonarConfigs != null && 
			configs.sonarConfigs.url != null &&
			!configs.sonarConfigs.resetSonar.skipBranches.contains("$GIT_BRANCH".replaceAll("origin/", "")) 
}

/*****************************************
* Logic reset sonar analysis
****************************************/
def resetSonarAnalyses() {
	def configs = getConfigs()
	def buildConfigs = configs.buildConfigs

	//Remove sonar project to recreate it based in $configs.sonarConfigs.resetSonar.resetBranch
	buildConfigs.each{ buildConfig ->
		if (buildConfig.enabled && buildConfig.sonarEnabled) {
			def projectKeyToDelete = "${buildConfig.key}-" + sh(returnStdout: true, script: "echo `$configs.sonarConfigs.projectKey`").trim()
			withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: configs.sonarConfigs.resetSonar.adminCredentials, usernameVariable: 'SONAR_RESET_SONAR_ADMIN_CREDENTIALS_USR', passwordVariable: 'SONAR_RESET_SONAR_ADMIN_CREDENTIALS_PSW']]) {
				sh 'curl --insecure -s -u ${SONAR_RESET_SONAR_ADMIN_CREDENTIALS_USR}:${SONAR_RESET_SONAR_ADMIN_CREDENTIALS_PSW} -X POST ' + configs.sonarConfigs.url + '/api/projects/delete?project=' + projectKeyToDelete
			}
		}
	}

    setupOriginRWRemote(configs.sonarConfigs.resetSonar.gitCredentials)

	//Store current commit in temp-branch
	sh "rm -Rf .git/hooks && \
		git branch -D temp-branch | true && \
		git checkout -b temp-branch"

	retry(3) {
		sh "git fetch origin-rw $configs.sonarConfigs.resetSonar.resetBranch:$configs.sonarConfigs.resetSonar.resetBranch && \
			git checkout -f $configs.sonarConfigs.resetSonar.resetBranch"
	}
	
	//Run base analysis
	executeBuilds("Reset Sonar for ", "sonar-reset-", true)

	//Wait for base analysis to end
	buildConfigs.each{ buildConfig ->
		if (buildConfig.enabled && buildConfig.sonarEnabled) {
			if (sh(returnStdout: true, script: "cat 'sonar-reset-${buildConfig.key}.result'").contains("PASSED")) {
				waitForSonarAnalysis(sh(returnStdout: true, script: buildConfig.sonarTaskUrl))
		    }
		}
	}

	//Return to original branch
	sh "rm -Rf .git/hooks && \
		git checkout . && \
		git checkout -f temp-branch"
}

/*****************************************
* Waits for Sonar analysis to end
****************************************/
def waitForSonarAnalysis(ceTaskUrl = '') {
	if (ceTaskUrl == null || ceTaskUrl == "") {
		return ""
	}

	int maxFailedAttempts = 120;
	int secondsBetweenAttempts = 10

	int failedAttempts = 0;
	echo "Waiting for sonar task results..."

	while (failedAttempts < maxFailedAttempts) {
		sh "curl --insecure -s -o ./ceTaskResult.json $ceTaskUrl"
		def ceTaskResult = readJSON file: "./ceTaskResult.json"
		if (ceTaskResult != null && ceTaskResult.task != null && ceTaskResult.task.status != "IN_PROGRESS" && ceTaskResult.task.status != "PENDING") {
			if (ceTaskResult.task.status != "SUCCESS") {
				echo ceTaskResult.toString()
				sh "echo 'Error processing sonar analysis.' && exit 1"
			}
			return ceTaskResult.task.analysisId
		}
		else {
		    failedAttempts += 1
		    if (failedAttempts < maxFailedAttempts) {
				echo "Sonar task is still in progress. Retry #" + failedAttempts.toString() + " in " + secondsBetweenAttempts.toString() + " seconds..."
		    	sh "sleep " + secondsBetweenAttempts.toString()
		    }
		}
	}
	sh "echo 'Error trying to get sonar quality gate results.' && exit 1"
}

/*****************************************
* Gathers the release notes and place
* them in email body
****************************************/
def replaceReleaseNotesPlaceholders(java.util.LinkedHashMap templates) {
	def compareHeadTo = ""
	def compareMethod = ".."
	def configs = getConfigs()
	if (isToResetSonarAnalyses()) {
		compareHeadTo = "$configs.sonarConfigs.resetSonar.resetBranch"
		templates = replacePlaceholderInTemplates(templates, "PLACEHOLDER_NEW_COMMITS_MESSAGE", " not yet in $configs.sonarConfigs.resetSonar.resetBranch")
	}
	else if (isToUpdateVersion()) {
		def commitOfPreviousVersion = findCommitOfPreviousVersion(configs.publishTagPath)
		if (commitOfPreviousVersion != null) {
			compareHeadTo = commitOfPreviousVersion.commitId
			compareMethod = "..."
			templates = replacePlaceholderInTemplates(templates, "PLACEHOLDER_NEW_COMMITS_MESSAGE", " since version $commitOfPreviousVersion.previousVersion")
		}
		else {
			templates = replacePlaceholderInTemplates(templates, "PLACEHOLDER_NEW_COMMITS_MESSAGE", "")
		}
	}
	else {
		def gitBranch = nullToEmpty(env.NOTIFICATION_GIT_BRANCH).replaceAll("origin/", "")
		try {
			def previousExecutionCommit = sh(returnStdout: true, script: "git rev-list -n 1 refs/tags/$configs.executionControl.tagPath/$gitBranch").trim()
			if (nullToEmpty(previousExecutionCommit) != "") {
				compareHeadTo = previousExecutionCommit
			}
		} catch (err) {
	    }
		
		setupOriginRWRemote(configs.executionControl.gitCredentials)
		sh "git tag -d \$(git tag -l) && git fetch --tags --no-recurse-submodules origin-rw"
		try {
			sh "git push --no-verify -f --delete origin-rw tag $configs.executionControl.tagPath/$gitBranch"
		} catch (err) {
	    }
		try {
			sh "git tag -f $configs.executionControl.tagPath/$gitBranch && git push --no-verify origin-rw $configs.executionControl.tagPath/$gitBranch"
		} catch (err) {
	    }
		
		compareMethod = "..."
		templates = replacePlaceholderInTemplates(templates, "PLACEHOLDER_NEW_COMMITS_MESSAGE", " since previous review")
	}

	sh "rm -rf ./newCommits.json && touch ./newCommits.json"
	if (compareHeadTo != "") {
		//Format "hash #@# author #@# date #@# message"
		sh "git log --no-merges --pretty=format:\"%h #@# %cn #@# %ci #@# %s ##@@##\" ${compareHeadTo}${compareMethod}HEAD >> ./newCommits.json || true"
	}
	def gitCommits = readFile("newCommits.json")

	return replaceRowsPlaceholdersInTemplates(templates, "PLACEHOLDER_NEW_COMMITS_ROW", gitCommits.split("##@@##"), { rowTemplate, gitCommit, templateKey ->
		if (nullToEmpty(gitCommit).trim() != "") {
			def gitCommitDetails = gitCommit.split(" #@# ")
			if (gitCommitDetails.size() > 3) {
				def commitMessage = java.util.regex.Matcher.quoteReplacement(gitCommitDetails[3])
				if (templateKey == "email") {
					env.commitMessages = nullToEmpty(env.commitMessages) + "##@@##" + java.util.regex.Matcher.quoteReplacement(gitCommitDetails[0]) + " #@# " + commitMessage
				}
				return rowTemplate.replaceAll('PLACEHOLDER_NEW_COMMITS_ROW_SUMMARY', commitMessage)
								  .replaceAll('PLACEHOLDER_NEW_COMMITS_ROW_AUTHOR', java.util.regex.Matcher.quoteReplacement(gitCommitDetails[1]))
			}
		}
		return ""
	});
}

/*****************************************
* Gathers the JIRA keys and place
* them in email body
****************************************/
def replaceJIRAPlaceholders(java.util.LinkedHashMap templates, result, net.sf.json.JSONObject configs) {
	def jiraKeys = [:]
	def transitionsConfigsPerInitStatus = configs.jiraConfigs[result.toLowerCase()] != null ? configs.jiraConfigs[result.toLowerCase()].transitionsConfigsPerInitStatus : null 

	//Condition to try to find jiras
	if (configs.jiraConfigs != null && configs.jiraConfigs.lookForJiraKeysConfig != null && configs.jiraConfigs.jiraKeyRegex != null) {
		//Condition to try to find jiras in branch name
		if (configs.jiraConfigs.lookForJiraKeysConfig.lookInBranchName != null && configs.jiraConfigs.lookForJiraKeysConfig.lookInBranchName.enabled == true) {
			//Condition to filter branches
			if (nullToEmpty(configs.jiraConfigs.lookForJiraKeysConfig.lookInBranchName.filterRegex) == "" || "$GIT_BRANCH".find(configs.jiraConfigs.lookForJiraKeysConfig.lookInBranchName.filterRegex) != null) {
				"$GIT_BRANCH".findAll(configs.jiraConfigs.jiraKeyRegex).each{ jiraKey ->
					jiraKeys = putJiraInMapIfValid(jiraKeys, jiraKey, "source branch name", transitionsConfigsPerInitStatus, configs)
				}
			}
		}
		//Condition to try to find jiras in commit messages
		if (configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages != null && configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages.enabled == true) {
			//Condition to filter commit messages
			if (nullToEmpty(configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages.filterRegex) == "" || "$GIT_BRANCH".find(configs.jiraConfigs.lookForJiraKeysConfig.lookInCommitMessages.filterRegex) != null) {
				nullToEmpty(env.commitMessages).split("##@@##").each{ commitDetails ->
					def commitDetailsAux = commitDetails.split(" #@# ")
					if (commitDetailsAux.size() == 2) {
						def commitHash = commitDetailsAux[0]
						def commitMessage = commitDetailsAux[1]
						commitMessage.findAll(configs.jiraConfigs.jiraKeyRegex).each{ jiraKey ->
							jiraKeys = putJiraInMapIfValid(jiraKeys, jiraKey, "commit message of " + commitHash, transitionsConfigsPerInitStatus, configs)
						}
					}
				}
			}
		}
	}
	echo "JIRA Details: " + groovy.json.JsonOutput.toJson(jiraKeys)
	env.jiraKeys = groovy.json.JsonOutput.toJson(jiraKeys)
	return replaceRowsPlaceholdersInTemplates(templates, "PLACEHOLDER_JIRA_LIST", jiraKeys.keySet(), { rowTemplate, jiraKey ->
		if (jiraKey == null) {
			return ""
		}
		def jiraData = jiraKeys[jiraKey]
		def jiraURL = ""
		def jiraFoundIn = ""
		def transitionsTitle = "No transitions performed"
		def transitionsError = "No error performing transitions"
		def jiraTransitions = []
				
		if (jiraData != null) {
			jiraURL = jiraData.url
			jiraFoundIn = jiraData.foundIn
			if (jiraData.transitionApplied != null) {
				transitionsTitle = (jiraData.transitionApplied.error ? "❌ " : "✔ ") + jiraData.transitionApplied.name
				transitionsError = jiraData.transitionApplied.errorMessage
				jiraTransitions = jiraData.transitionApplied.transitions
			}
		}
		
		rowTemplate = rowTemplate.replaceAll('PLACEHOLDER_JIRA_KEY', jiraKey)
	  			   	 			 .replaceAll('PLACEHOLDER_JIRA_URL', jiraURL)
	  			   	 			 .replaceAll('PLACEHOLDER_JIRA_FOUND_IN', jiraFoundIn)
	  			   	 			 .replaceAll('PLACEHOLDER_JIRA_TRANSITIONS_TITLE', transitionsTitle)
	  			   	 			 .replaceAll('PLACEHOLDER_JIRA_TRANSITIONS_ERROR', transitionsError)

  		def foundError = false
		return replaceRowsPlaceholdersInTemplates([ template: rowTemplate ], "PLACEHOLDER_JIRA_TRANSITIONS", jiraTransitions, { rowSubTemplate, transitionName ->
			if (transitionName != null) {
				foundError = foundError || transitionName.equals(jiraData.transitionApplied.errorIn)
				return rowSubTemplate.replaceAll('PLACEHOLDER_JIRA_TRANSITION_NAME', (foundError ? "❌ " : "✔ ") + transitionName)
			}
			return ""
		}).template
	});
}


/*****************************************
* Returns the commit id of the
* previous version
****************************************/
def putJiraInMapIfValid(jiraKeys, jiraKey, foundIn, transitionsConfigsPerInitStatus, net.sf.json.JSONObject configs) {
	if (jiraKeys[jiraKey] == null) {
		try {
			def jiraIssue = jiraGetIssue idOrKey: jiraKey,
							site: configs.jiraConfigs.jiraSite,
							failOnError: false
			if (jiraIssue != null && jiraIssue.data != null) {
				jiraKeys.put(jiraKey, [
				    foundIn: foundIn,
                    url: nullToEmpty(configs.jiraConfigs.jiraSite) + "/browse/" + jiraKey,
                    transitionApplied: jiraTryToApplyTransitions(jiraKey, jiraIssue.data, transitionsConfigsPerInitStatus, configs) 
                ])
			}
		} catch (err) {
	        echo err.getMessage()
	    }
	}
	return jiraKeys
}


/*****************************************
* Returns the commit id of the
* previous version
****************************************/
def jiraTryToApplyTransitions(jiraKey, jiraData, transitionsConfigsPerInitStatus, net.sf.json.JSONObject configs) {
	def output = null
	def jiraIssueStatus = jiraData.fields.status.id 

	if (jiraIssueStatus != null && transitionsConfigsPerInitStatus != null && transitionsConfigsPerInitStatus[jiraIssueStatus] != null) {
		output = [
            name: transitionsConfigsPerInitStatus[jiraIssueStatus].name,
            error: false,
            errorIn: "",
            errorMessage: "No error performing transitions",
            transitions: transitionsConfigsPerInitStatus[jiraIssueStatus].transitions.collect{ it -> it.name }
        ]
		transitionsConfigsPerInitStatus[jiraIssueStatus].transitions.each{ transitionData ->
			try {
				if (!output.error) {
					echo "Trying to apply transition: " + groovy.json.JsonOutput.toJson(transitionData)
					jiraTransitionIssue idOrKey: jiraKey,
										site: configs.jiraConfigs.jiraSite,
										auditLog: true,
										failOnError: true,
										input: transitionData.data
				}
			} catch (err) {
				output.error = true
				output.errorIn = transitionData.name
				output.errorMessage = err.getMessage() 
			}
		}
	}
	
	return output
}


/*****************************************
* Identifies if a new version reset 
* should generated
****************************************/
def isToUpdateVersion() {
	def configs = getConfigs()
	return 	configs.generateVersion != null && configs.generateVersion.enabled
}

/*****************************************
* Setup origin-rw remote
****************************************/
def setupOriginRWRemote(def gitCredentials = '') {
	def configs = getConfigs()
	//Logic to add no-password remote
	def gitURLWithoutProtocol = sh(returnStdout: true, script: 'git config remote.origin.url').trim().replaceFirst('^(http[s]?://www\\.|http[s]?://|www\\.)','').replaceFirst('([/]?)$','')
	sh 'git remote rm origin-rw | true'
	sh "git remote add origin-rw ${GIT_PROTOCOL}://${gitURLWithoutProtocol}"
	withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: gitCredentials, usernameVariable: 'SONAR_RESET_GIT_CREDENTIALS_USR', passwordVariable: 'SONAR_RESET_GIT_CREDENTIALS_PSW']]) {
		sh 'echo "' + env.GIT_PROTOCOL + '://' + java.net.URLEncoder.encode("${SONAR_RESET_GIT_CREDENTIALS_USR}", "UTF-8") + ':${SONAR_RESET_GIT_CREDENTIALS_PSW}@' + gitURLWithoutProtocol + '" > "' + env.WORKSPACE + '/.git/.git-credentials"'
	}
	sh "git config credential.helper \"store --file='$WORKSPACE/.git/.git-credentials'\""
}

/*****************************************
* Returns the commit id of the
* previous version
****************************************/
def findCommitOfPreviousVersion(versionTagPath = '') {
	def versionsToPublish = versionsToPublish()
	def tagsToIgnore = ""<<""
	versionsToPublish.each { versionToPublish -> 
		tagsToIgnore <<= " | grep -v refs/tags/$versionTagPath/$versionToPublish"
	}
	def previousVersion = sh(returnStdout: true, script: "git for-each-ref --sort=creatordate --format '%(refname)' refs/tags/$versionTagPath" + tagsToIgnore.toString() + " | tail -n 1").trim()
	if (previousVersion != null && previousVersion.length() > ("refs/tags/" + versionTagPath).length()) {
		previousVersion = previousVersion.substring(("refs/tags/" + versionTagPath).length() + 1)

		return [
	        commitId : sh(returnStdout: true, script: "git rev-list -n 1 refs/tags/$versionTagPath/$previousVersion").trim(),
	        previousVersion : previousVersion
	    ]
	}
	
	return null
}

/*****************************************
* Returns the commit id of the
* last success build
****************************************/
def findCommitOfLastSuccessBuild() {
	def commitId = ""
	def buildNumber = ""
	def build = currentBuild
	def firstBuild = true

	while(build != null && commitId == "") {
		if (!firstBuild && build.result == 'SUCCESS') {
			build.changeSets.each { changeLog ->
			    if (changeLog.items != null) {
			    	changeLog.items.each { changeLogItem ->
			    		echo changeLogItem.getCommitId()
			    		if (changeLogItem.getCommitId() != null) {
			    			commitId = changeLogItem.getCommitId()
			    			buildNumber = build.number.toString()
			    		}
			    	}
			    }
			}
		}
		firstBuild = false
		build = build.previousBuild
	}
	return [
        commitId : commitId,
        buildNumber : buildNumber
    ]
}

/*****************************************
* Gathers the sonar results and place
* them in email body
****************************************/
def replaceSonarResultsPlaceholders(buildConfig, notificationBody = '', templateKey) {
	def configs = getConfigs()
	def sonarQualityGateResult = "<span style=\\\"color:black;\\\">💤 NOT AVAILABLE</span>"
	def sonarProjectKey = ""
	def forceNotAvailable = false
	try {
		if (buildConfig.sonarEnabled) {
			sonarProjectKey = sh(returnStdout: true, script: buildConfig.sonarProjectKey)
		}
	} catch (err) {
		forceNotAvailable = true
        echo err.getMessage()
    }

	if (buildConfig.sonarEnabled && nullToEmpty(sonarProjectKey) != "" && sh(returnStdout: true, script: "cat '${buildConfig.key}.result'").contains("PASSED")) {
		notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_URL_TEXT", "full analysis report")
		notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_URL", (nullToEmpty(configs.notifications.configs.sonarBaselineURL) + nullToEmpty(sonarProjectKey)).trim())

		def analysisId = waitForSonarAnalysis(sh(returnStdout: true, script: buildConfig.sonarTaskUrl))

		sh "curl --insecure -s -o ./qualityGateResult.json $configs.sonarConfigs.url/api/qualitygates/project_status?analysisId=$analysisId"
		def qualityGateResult = readJSON file: "./qualityGateResult.json"
		if (qualityGateResult == null || qualityGateResult.projectStatus == null || qualityGateResult.projectStatus.status != "OK") {
			sh "echo 'Sonar quality gate FAILED.'" // && exit 1"
		}
		else {
			echo "Sonar quality gate results are OK."
		}

		def sonarMetrics = getSonarProjectMetrics(	sonarProjectKey,
				        							"new_violations,new_blocker_violations,new_critical_violations,new_technical_debt,new_code_smells,new_coverage,new_duplicated_lines_density,violations,blocker_violations,critical_violations,sqale_index,code_smells,coverage,tests,duplicated_lines_density,duplicated_blocks")
		//Sonar mettrics
		if (sonarMetrics != null) {
			sonarMetrics.each { sonarMetric ->
				notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_" + sonarMetric.metricKey.toUpperCase() + "_SUFFIX", sonarMetric.value)
				if (sonarMetric.metricKey == "QUALITY_GATE") {
					sonarQualityGateResult = sonarMetric.value
				}
			}
		}
		
		def qualityCheckTemplateSpecs = findEmailRowTemplate(notificationBody, "PLACEHOLDER_QUALITY_CHECK")
		if (qualityCheckTemplateSpecs != null) {
			if (templateKey == "slack" || templateKey == "jira") {
				sonarQualityGateResult = sonarQualityGateResult.replaceAll("<.*?>", "")
			}
			def qualityCheckBuilder = qualityCheckTemplateSpecs.rowTemplate
												.replaceAll("PLACEHOLDER_QUALITY_CHECK_URL", (nullToEmpty(configs.notifications.configs.sonarBaselineURL) + nullToEmpty(sonarProjectKey)).trim())
												.replaceAll("PLACEHOLDER_QUALITY_CHECK_NAME", "Sonar Analysis")
												.replaceAll("PLACEHOLDER_QUALITY_CHECK_RESULT", sonarQualityGateResult)
			def notificationBodyAux = ""<<""
			notificationBodyAux <<= notificationBody.substring(0, notificationBody.indexOf("PLACEHOLDER_QUALITY_CHECK_START"))
			notificationBodyAux <<= qualityCheckBuilder.toString() + "PLACEHOLDER_QUALITY_CHECK_START" + qualityCheckTemplateSpecs.rowTemplate + "PLACEHOLDER_QUALITY_CHECK_END"
			notificationBodyAux <<= notificationBody.substring(notificationBody.indexOf("PLACEHOLDER_QUALITY_CHECK_END") + "PLACEHOLDER_QUALITY_CHECK_END".length())
			
			notificationBody = notificationBodyAux.toString()
		}
	}
	else {
		if (buildConfig.sonarEnabled) {
			def qualityCheckTemplateSpecs = findEmailRowTemplate(notificationBody, "PLACEHOLDER_QUALITY_CHECK")
			if (qualityCheckTemplateSpecs != null) {
				if (templateKey == "slack" || templateKey == "jira") {
					sonarQualityGateResult = sonarQualityGateResult.replaceAll("<.*?>", "")
				}
				def qualityCheckBuilder = qualityCheckTemplateSpecs.rowTemplate
						.replaceAll("PLACEHOLDER_QUALITY_CHECK_URL", "#")
						.replaceAll("PLACEHOLDER_QUALITY_CHECK_NAME", "Sonar Analysis")
						.replaceAll("PLACEHOLDER_QUALITY_CHECK_RESULT", sonarQualityGateResult)
				def notificationBodyAux = ""<<""
				notificationBodyAux <<= notificationBody.substring(0, notificationBody.indexOf("PLACEHOLDER_QUALITY_CHECK_START"))
				notificationBodyAux <<= qualityCheckBuilder.toString() + "PLACEHOLDER_QUALITY_CHECK_START" + qualityCheckTemplateSpecs.rowTemplate + "PLACEHOLDER_QUALITY_CHECK_END"
				notificationBodyAux <<= notificationBody.substring(notificationBody.indexOf("PLACEHOLDER_QUALITY_CHECK_END") + "PLACEHOLDER_QUALITY_CHECK_END".length())
				notificationBody = notificationBodyAux.toString()
			}
		}
		
		notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_URL_TEXT", "")
		notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_URL", "#")
		if (!buildConfig.sonarEnabled) {
			notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_QUALITY_GATE_SUFFIX", "<span style=\\\"color:black;\\\">💤 NOT APPLICABLE</span>")
		}
		else if (forceNotAvailable) {
			notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_QUALITY_GATE_SUFFIX", "<span style=\\\"color:black;\\\">💤 NOT AVAILABLE</span>")
		}
		else {
			notificationBody = notificationBody.replaceAll("PLACEHOLDER_SONAR_QUALITY_GATE_SUFFIX", "<span style=\\\"color:black;\\\">💤 SKIPPED</span>")
		}
	}
	notificationBody = notificationBody.replaceAll(/PLACEHOLDER_SONAR_(.*?)_SUFFIX/, "-")

	return notificationBody
}

/*****************************************
* Get sonar project metricks
****************************************/
def getSonarProjectMetrics(projectKey = '', metricKeys = '') {
	def output = []
	def configs = getConfigs()
			
	sh "curl --insecure -s -o ./projectMetrics.json $configs.sonarConfigs.url/api/measures/component?metricKeys=$metricKeys\\&component=$projectKey"
	def projectMetrics = readJSON file: "./projectMetrics.json"
	echo projectMetrics.toString()
	if (projectMetrics != null && projectMetrics.component != null && projectMetrics.component.measures != null) {
		java.text.DecimalFormat df = new java.text.DecimalFormat("#.##")
		projectMetrics.component.measures.each { measure ->
			def value = "-"
			if (measure.value != null) {
				output << [metricKey: measure.metric, value: measure.value]
			}
			else if(measure.periods != null) {
				double totalValue = 0
				measure.periods.each { period ->
					if (period.value.isNumber()) {
				    	totalValue += (period.value as Double)
				    }
				}
				output << [metricKey: measure.metric, value: df.format(totalValue)]
			}
		}
	}

	def qualityGateResult = readJSON file: "./qualityGateResult.json"
	if (qualityGateResult != null) {
		echo qualityGateResult.toString()
	}

	if (qualityGateResult == null || qualityGateResult.projectStatus == null || qualityGateResult.projectStatus.status != "OK") {
		output << [metricKey: "QUALITY_GATE", value: "<span style='color:black;'>❌ FAILED</span>"]
	}
	else {
		output << [metricKey: "QUALITY_GATE", value: "<span style='color:black;'>✔ PASSED</span>"]
	}

	return output
}

/*****************************************
* Executes the pipeline house keeping
****************************************/
def execHouseKeeping() {
	sh "docker ps --filter status=dead --filter status=exited -aq | xargs docker rm -v | true"
	sh "docker images --no-trunc | grep '<none>' | awk '{ print \$3 }' | xargs -r docker rmi | true"
}

/*****************************************
* To enable load in other pipelines
****************************************/
return this;