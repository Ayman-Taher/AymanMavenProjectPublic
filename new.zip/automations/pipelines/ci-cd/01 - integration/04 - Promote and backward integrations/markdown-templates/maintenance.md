There was a problem running a integration pipeline.  
More detail in <PLACEHOLDER_EXECUTION_URL|Automation log>.


*Execution details:*
🔹 Result: PLACEHOLDER_EXECUTION_RESULT
🔹 Duration: PLACEHOLDER_EXECUTION_DURATION
🔹 <PLACEHOLDER_EXECUTION_URL|Automation log>