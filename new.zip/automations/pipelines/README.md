Continuous Automation Framework
====================

***

## What is Continuous Automation?

Continuous Automation is the practice of automating __every aspect__ of an application�s lifecycle. 

e.g.: planning, estimations, monitoring, build, test, delivery, etc... 

***

## Methodology

Detect, Correct and Automate.

![ ](https://image.ibb.co/dj8nqp/Untitled.jpg)

***

## What is Continuous Automation Framework?

It's a set of tools and methodologies that aims to make Automation a practice in Celfocus.

Main principles:

* __Standardize__ how automation is done;

* __Generalize__ to be easily reused in multiple components, projects and even architectures;

* __Centralize__ and create manuals so everyone can consult, understand and contribute.

***

## Technology and Methodology

+ Application where automation is maintained:
	* __Jenkins__ is a self-contained, open source automation server which can be used to automate all sorts of tasks;
+ Automation Script:
	* __Jenkins Pipeline__ provides an extensible set of tools for modeling simple-to-complex orchestrations "as code" via the [Pipeline domain-specific language (DSL) syntax][https://jenkins.io/doc/book/pipeline/syntax]. The definition of a Jenkins Pipeline is written into a text file called a __Jenkinsfile__. 
+ Automation runtime environment:
	* A __Docker container__ image is a lightweight, stand-alone, executable package of a piece of software that includes everything needed to run it: code, runtime, system tools, system libraries, settings, etc...
	
***
	
## Getting Started

* Install __docker__ (https://docs.docker.com/install/linux/docker-ce/centos/) 
```shell
		#Example in CentOS:
		$ sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
		$ sudo yum install docker-ce
		$ sudo systemctl start docker
		$ sudo systemctl enable docker
```

* Change __partition/disk used to store docker images__ by replacing the /var/lib/docker folder with a symbolic link
```shell
		#Example in CentOS:
		$ mkdir -p /opt/app/docker
		$ mv /var/lib/docker /var/lib/docker_bck
		$ ln -s /opt/app/docker /var/lib/docker
```

* Install __docker compose__ (https://docs.docker.com/compose/install/)
```shell
		#Example in CentOS:
		$ sudo curl -L https://github.com/docker/compose/releases/download/1.22.0/docker-compose-$(uname -s)-$(uname -m) -o /usr/local/bin/docker-compose
```

* Copy __Jenkins__ docker configuration from __docker-base-images/jenkins/docker-compose.yml__ and follow instructions in __docker-base-images/jenkins/README.md__

* Look for pipeline in __automations__ folder and follow instructions in the respective __README.md__ file

***
	
## Useful links

* https://support.cloudbees.com/hc/en-us/articles/115000053051-How-to-Trigger-Multibranch-Jobs-from-Bitbucket-Server-